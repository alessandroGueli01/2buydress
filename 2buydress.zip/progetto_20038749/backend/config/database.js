const { Sequelize } = require('sequelize');
const path = require('path');

// Definisce il percorso del file del database SQLite nella cartella principale del progetto
const storagePath = path.resolve(__dirname, '../../database.sqlite');

let sequelize;

// Se esiste la variabile DATABASE_URL (tipica di Heroku/Render/Railway), usa Postgres
if (process.env.DATABASE_URL) {
  sequelize = new Sequelize(process.env.DATABASE_URL, {
    dialect: 'postgres',
    protocol: 'postgres',
    logging: false,
    dialectOptions: process.env.NODE_ENV === 'production' ? {
      ssl: {
        require: true,
        rejectUnauthorized: false // Necessario per molte connessioni cloud gestite
      }
    } : {}
  });
} else {
  // Altrimenti usa SQLite per lo sviluppo locale
  sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: storagePath,
    logging: false,
  });
}

const connectDB = async () => {
  try {
    await sequelize.authenticate();
    // Messaggio di log dinamico in base al dialetto utilizzato
    console.log(`✅ Connessione a ${sequelize.getDialect()} stabilita con successo.`);
    // Sincronizza i modelli con il database.
    // `force: false` non cancellerà i dati esistenti.
    await sequelize.sync({ force: false });
    console.log('🔄 Modelli sincronizzati con il database.');
  } catch (error) {
    console.error('❌ Impossibile connettersi al database:', error);
    process.exit(1);
  }
};

module.exports = { sequelize, connectDB };
