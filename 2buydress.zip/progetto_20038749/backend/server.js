const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config({ path: path.resolve(__dirname, '../.env') });
const { sequelize, connectDB } = require('./config/database');
const rateLimit = require('express-rate-limit'); 

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Configurazione fondamentale per servire le immagini caricate
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Definisci il percorso della cartella public
const publicPath = path.join(__dirname, '../public');

// Serve i file statici del frontend dalla cartella 'public'
app.use(express.static(publicPath));

// Rate Limiter per le API di autenticazione
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minuti
  max: 10, // Limita ogni IP a 10 richieste per finestra (windowMs)
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Troppe richieste da questo IP, riprova tra 15 minuti.' }
});

// API Routes - Devono essere definite PRIMA della rotta catch-all
app.use('/api/auth', authLimiter, require('./routes/auth'));
app.use('/api/listings', require('./routes/listings'));
app.use('/api/users', require('./routes/users'));
app.use('/api/chat', require('./routes/chat'));
app.use('/api/reviews', require('./routes/reviews'));
app.use('/api/favorites', require('./routes/favorites'));
app.use('/api/orders', require('./routes/orders'));
app.use('/api/payments', require('./routes/payments')); 
app.use('/api/admin', require('./routes/admin'));
app.use('/api/reports', require('./routes/reports'));

// Rotta Catch-all: per qualsiasi altra richiesta GET che non è un'API,
// serve la pagina principale. Questo permette il refresh su pagine interne.
// DEVE essere una delle ultime rotte definite.
app.get('*', (req, res) => res.sendFile(path.join(publicPath, 'index.html')));

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!', error: err.message, stack: err.stack });
});

if (require.main === module) {
  const startServer = async () => {
    try {
      await connectDB();
      app.listen(PORT, () => {
        console.log(`🚀 Server running on http://localhost:${PORT}`);
      });
    } catch (error) {
      console.error('❌ Impossibile avviare il server:', error);
      process.exit(1);
    }
  };
  startServer();
}

module.exports = app;
