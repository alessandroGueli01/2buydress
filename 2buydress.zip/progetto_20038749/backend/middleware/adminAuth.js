const jwt = require('jsonwebtoken');
const { User } = require('../models');

module.exports = async function (req, res, next) {
  // 1. Ottieni il token dall'header
  const token = req.header('Authorization')?.replace('Bearer ', '');

  if (!token) {
    return res.status(401).json({ message: 'Nessun token, autorizzazione negata.' });
  }

  try {
    // 2. Verifica il token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded.user;

    // 3. Verifica che l'utente sia un amministratore
    const user = await User.findByPk(req.user.id);
    if (!user || !user.is_admin) {
      return res.status(403).json({ message: 'Accesso negato. Richiesti privilegi di amministratore.' });
    }

    next();
  } catch (err) {
    res.status(401).json({ message: 'Token non valido.' });
  }
};