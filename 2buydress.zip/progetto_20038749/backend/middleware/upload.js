const multer = require('multer');
const path = require('path');
const fs = require('fs');

/**
 * Crea un middleware di upload configurabile.
 * @param {string} subfolder - La sottocartella in 'uploads' dove salvare i file (es. 'listings', 'avatars').
 * @returns {import('multer').Multer} L'istanza di multer configurata.
 */
const createUploader = (subfolder) => {
  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadPath = path.join(__dirname, `../uploads/${subfolder}`);
      fs.mkdirSync(uploadPath, { recursive: true }); // Crea la cartella se non esiste
      cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, `${subfolder.slice(0, -1)}-${uniqueSuffix}${path.extname(file.originalname)}`);
    }
  });

  const fileFilter = (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|webp/;
    const mimetype = allowedTypes.test(file.mimetype);
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());

    if (mimetype && extname) {
      return cb(null, true);
    }
    cb(new Error('Errore: Sono permesse solo immagini (jpeg, jpg, png, gif, webp).'));
  };

  const upload = multer({
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // Limite di 5MB
    fileFilter: fileFilter
  });

  return upload;
};

module.exports = createUploader;