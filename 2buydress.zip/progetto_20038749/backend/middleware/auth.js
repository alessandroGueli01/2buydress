const jwt = require('jsonwebtoken');
const { User } = require('../models');

module.exports = async (req, res, next) => {
  console.log(`[AUTH MIDDLEWARE] Triggered for: ${req.method} ${req.originalUrl}`);
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      console.log('[AUTH MIDDLEWARE] No token found. Denying access.');
      return res.status(401).json({ message: 'Accesso negato. Token non fornito.' });
    }

    console.log('[AUTH MIDDLEWARE] Token found. Verifying...');
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    console.log(`[AUTH MIDDLEWARE] Token decoded for user ID: ${decoded.user.id}. Fetching user from DB...`);
    const user = await User.findByPk(decoded.user.id);
    
    if (!user) {
      console.log(`[AUTH MIDDLEWARE] User with ID ${decoded.user.id} not found in DB. Denying access.`);
      return res.status(401).json({ message: 'Utente associato al token non trovato.' });
    }

    console.log(`[AUTH MIDDLEWARE] User ${user.name} found. Attaching to request and calling next().`);
    req.user = user;
    next();
  } catch (error) {
    console.error('[AUTH MIDDLEWARE] Error caught:', error.message);
    return res.status(401).json({ message: 'Token non valido o scaduto.' });
  }
};
