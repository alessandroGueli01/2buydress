const path = require('path');
// Carica le variabili d'ambiente prima di ogni altra cosa
require('dotenv').config({ path: path.resolve(__dirname, '../../.env') });

const { sequelize } = require('../config/database');
const { User, Listing, Review } = require('../models');

/**
 * Popola il database con dati di prova.
 */
const seedDatabase = async () => {
  try {
    console.log('Connecting to the database...');
    // --- MODIFICA CRUCIALE: force: true ---
    // Questo cancella TUTTO il database e lo ricrea pulito.
    await sequelize.sync({ force: true });
    console.log('🔄 Database resettato (tabelle ricreate). Avvio del seeding...');

    // --- 1. Crea Utenti (Venditore e Acquirente) ---
    // Usiamo findOrCreate per creare gli utenti solo se non esistono già.
    // Questo evita errori se lo script viene eseguito più volte e permette di mantenere gli utenti creati manualmente.
    const [user, userCreated] = await User.findOrCreate({
      where: { email: 'testuser1@example.com' },
      defaults: {
        name: 'Test User 1',
        password: 'password123', // L'hook del modello si occuperà di fare l'hash
        bio: 'Sono un utente di prova per testare la piattaforma 2buydress.',
        location: 'Milano, IT',
        is_admin: true, // Rendiamo il primo utente admin per testare la dashboard
        salesCount: 0,
        purchasesCount: 0
      }
    });

    const [buyer, buyerCreated] = await User.findOrCreate({
      where: { email: 'buyer@example.com' },
      defaults: {
        name: 'Mario Rossi',
        password: 'password123',
        bio: 'Amo la moda vintage!',
        location: 'Roma, IT',
        addressLine1: 'Via Roma 1',
        city: 'Roma',
        postalCode: '00100',
        country: 'IT', // Usa il codice ISO a 2 lettere per la validazione
        salesCount: 0,
        purchasesCount: 0
      }
    });

    if (userCreated) console.log(`✅ Admin "${user.name}" created.`);
    if (buyerCreated) console.log(`✅ Buyer "${buyer.name}" created.`);

    // --- 2. Crea Annunci ---
    // Annuncio 1: Attivo
    const [listing, listingCreated] = await Listing.findOrCreate({
      where: { title: 'Giacca di Jeans di Prova' },
      defaults: {
        description: 'Questa è una giacca di prova per testare il seeding del database.',
        price: 5000, // 50.00 EUR in centesimi
        category: 'Abbigliamento',
        brand: 'SeedBrand',
        size: 'L',
        condition: 'Come nuovo',
        photos: ['https://loremflickr.com/600/600/fashion,denim,jacket?lock=100'],
        sellerId: user.id, // Collega l'annuncio all'utente creato
        status: 'active',
        shippingCost: 500
      }
    });

    if (listingCreated) console.log(`✅ Active Listing created.`);

    // --- 2.1 Generazione Annunci Casuali (Popolamento Catalogo) ---
    const categories = ['Abbigliamento', 'Scarpe', 'Accessori', 'Borse'];
    const brands = ['Zara', 'H&M', 'Nike', 'Adidas', 'Gucci', 'Vintage', 'Levi\'s', 'Uniqlo'];
    const conditions = ['Come nuovo', 'Ottimo', 'Buono'];
    const sizes = ['XS', 'S', 'M', 'L', 'XL'];

    // Usiamo template di prodotti più realistici con parole chiave per le immagini
    const productTemplates = [
      { title: 'T-shirt Bianca in Cotone', category: 'Abbigliamento', brand: 'Uniqlo', keyword: 'white t-shirt' },
      { title: 'Felpa con Cappuccio Grigia', category: 'Abbigliamento', brand: 'H&M', keyword: 'gray hoodie' },
      { title: 'Camicia in Lino Azzurra', category: 'Abbigliamento', brand: 'Zara', keyword: 'blue linen shirt' },
      { title: 'Jeans Slim Fit Blu Scuro', category: 'Abbigliamento', brand: 'Levi\'s', keyword: 'dark blue jeans' },
      { title: 'Maglione in Lana a Collo Alto', category: 'Abbigliamento', brand: 'Benetton', keyword: 'wool turtleneck sweater' },
      { title: 'Top in Seta Nero', category: 'Abbigliamento', brand: 'Gap', keyword: 'black silk top' },
      { title: 'Pantaloni Chino Beige', category: 'Abbigliamento', brand: 'Carhartt', keyword: 'beige chino pants' },
      { title: 'Giacca a Vento Impermeabile', category: 'Abbigliamento', brand: 'Nike', keyword: 'waterproof windbreaker' },
      { title: 'Vestito Estivo a Fiori', category: 'Abbigliamento', brand: 'Mango', keyword: 'floral summer dress' },
      { title: 'Gonna a Pieghe Nera', category: 'Abbigliamento', brand: 'Bershka', keyword: 'black pleated skirt' },
      { title: 'Blusa Elegante Bianca', category: 'Abbigliamento', brand: 'Massimo Dutti', keyword: 'white elegant blouse' },
      { title: 'Cappotto Classico in Panno', category: 'Abbigliamento', brand: 'Max Mara', keyword: 'classic wool coat' },
      { title: 'Giacca di Jeans Vintage', category: 'Abbigliamento', brand: 'Lee', keyword: 'vintage denim jacket' },
      { title: 'Pantaloni Sportivi Neri', category: 'Abbigliamento', brand: 'Adidas', keyword: 'black sport pants' },
      { title: 'Cardigan in Cashmere', category: 'Abbigliamento', brand: 'Falconeri', keyword: 'cashmere cardigan' },
      { title: 'Abito da Sera Lungo', category: 'Abbigliamento', brand: 'Pronovias', keyword: 'long evening gown' },
    ];

    // Controlla quanti annunci attivi ci sono già per evitare di aggiungerne all'infinito
    const activeListingsCount = await Listing.count({ where: { status: 'active' } });

    // Numero desiderato di annunci attivi nel catalogo
    const activeListingsTarget = 5;

    if (activeListingsCount < activeListingsTarget) {
      const numToGenerate = activeListingsTarget - activeListingsCount;
      console.log(`🎲 Generating ${numToGenerate} random listings...`);
      for (let i = 0; i < numToGenerate; i++) {
        const template = productTemplates[Math.floor(Math.random() * productTemplates.length)];
        const selectedTemplate = template; // Tutti i template sono ora di abbigliamento
        const condition = conditions[Math.floor(Math.random() * conditions.length)];
        // Sostituiamo gli spazi con virgole per i tag di loremflickr (es. "summer dress" -> "summer,dress")
        const photoKeyword = selectedTemplate.keyword.replace(/\s+/g, ',');

        const numPhotos = Math.floor(Math.random() * 3) + 1;
        // Usiamo loremflickr per immagini reali. Il parametro 'lock' assicura che l'immagine rimanga stabile.
        const photos = Array.from({ length: numPhotos }, (_, j) => `https://loremflickr.com/600/600/fashion,clothing,${photoKeyword}?lock=${i * 10 + j}`);
        
        await Listing.create({
          title: `${template.title} (${condition})`,
          description: `Descrizione generata automaticamente per ${selectedTemplate.title}. Ottima occasione, in condizione ${condition.toLowerCase()}.`,
          price: Math.floor(Math.random() * 20000) + 1000,
          category: selectedTemplate.category,
          brand: selectedTemplate.brand,
          size: sizes[Math.floor(Math.random() * sizes.length)],
          condition: condition,
          photos: photos,
          sellerId: user.id, 
          status: 'active',
          shippingCost: 500
        });
      } 
      console.log(`✅ ${numToGenerate} random listings created.`);
    } 
    else {
      console.log('✅ Database already has enough active listings. Skipping random generation.');
    }

    // --- 3. Crea una Recensione ---
    const [review, reviewCreated] = await Review.findOrCreate({
      where: { authorId: buyer.id, targetId: user.id },
      defaults: {
        authorId: buyer.id,
        targetId: user.id,
        rating: 5,
        comment: 'Venditore eccellente! Spedizione veloce e oggetto come da descrizione.'
      }
    });
      
    if (reviewCreated) {
      user.rating = 5.0;
      user.reviewCount = 1;
      await user.save();
      console.log(`✅ Review created for seller "${user.name}".`);
    }

    console.log('\nSeeding finished successfully!');

  } catch (error) {
    console.error('❌ Errore durante il seeding. L\'operazione è stata interrotta.');
    console.error('Dettagli errore:', error); // Stampa l'errore completo per il debug
    process.exit(1);
  } finally {
    console.log('Closing database connection...');
    await sequelize.close();
  }
};

seedDatabase();