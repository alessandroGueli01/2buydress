const { sequelize } = require('../config/database');
const { User, Listing } = require('../models');

async function populateImages() {
  console.log('🔄 Inizio popolamento immagini...');
  
  try {
    // Assicura che il database sia connesso e le tabelle esistano
    await sequelize.authenticate();
    await sequelize.sync();

    // 1. Aggiorna gli avatar degli utenti
    const users = await User.findAll();
    console.log(`👥 Trovati ${users.length} utenti. Aggiornamento avatar...`);
    
    for (const user of users) {
      // Genera un avatar con le iniziali dell'utente e colori casuali
      // Esempio: Alessandro Gueli -> AG su sfondo colorato
      const avatarUrl = `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=random&color=fff&size=256&bold=true`;
      
      user.avatar = avatarUrl;
      await user.save();
    }
    console.log('✅ Avatar utenti aggiornati.');

    // 2. Aggiorna le foto degli annunci
    const listings = await Listing.findAll();
    console.log(`📦 Trovati ${listings.length} annunci. Aggiornamento foto...`);

    for (const listing of listings) {
      // Genera immagini placeholder professionali con il titolo dell'annuncio
      // Esempio: "Giacca Pelle" -> Immagine grigia con scritto "Giacca Pelle"
      const photo1 = `https://placehold.co/800x800/2c3e50/ffffff?text=${encodeURIComponent(listing.title)}`;
      const photo2 = `https://placehold.co/800x800/e74c3c/ffffff?text=Dettaglio+${encodeURIComponent(listing.brand || 'Foto')}`;
      const photo3 = `https://placehold.co/800x800/ecf0f1/2c3e50?text=Retro`;
      
      // Aggiorna l'array delle foto
      listing.photos = [photo1, photo2, photo3];
      await listing.save();
    }
    console.log('✅ Foto annunci aggiornate.');
    
    console.log('🎉 Operazione completata! Ora il tuo progetto è pieno di colori.');
    process.exit(0);
  } catch (error) {
    console.error('❌ Errore durante il popolamento:', error);
    process.exit(1);
  }
}

populateImages();