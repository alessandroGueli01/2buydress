const { sequelize } = require('../config/database');
const { User, Listing, Order } = require('../models');

async function seedUserStats() {
  // Leggi gli argomenti da terminale
  const targetEmail = process.argv[2];
  const salesTarget = parseInt(process.argv[3]) || 0; 
  const purchasesTarget = parseInt(process.argv[4]) || 0; 

  if (!targetEmail) {
    console.error('❌ Errore: Specifica l\'email dell\'utente.');
    console.error('👉 Uso: node scripts/seed_user_stats.js tua@email.com [num_vendite] [num_acquisti]');
    process.exit(1);
  }

  console.log(`🚀 Inizio generazione dati per: ${targetEmail}`);
  console.log(`🎯 Obiettivo: ${salesTarget} Vendite, ${purchasesTarget} Acquisti`);

  try {
    await sequelize.authenticate();

    // 1. Trova l'utente target
    const user = await User.findOne({ where: { email: targetEmail } });
    if (!user) {
      console.error('❌ Utente non trovato!');
      process.exit(1);
    }

    // 2. Crea o trova un "Partner Demo" (l'utente che comprerà/venderà con te)
    const [partner] = await User.findOrCreate({
      where: { email: 'demo_partner@example.com' },
      defaults: {
        name: 'Cliente Demo',
        password: 'password_dummy', // Non verrà usata
        bio: 'Account generato per demo',
        location: 'Milano'
      }
    });

    // 3. Genera VENDITE (Tu vendi, Partner compra)
    console.log('📦 Generazione vendite...');
    for (let i = 0; i < salesTarget; i++) {
      // Crea annuncio venduto
      const listing = await Listing.create({
        title: `Capo Vintage #${i + 1}`,
        description: 'Articolo venduto durante la demo.',
        price: Math.floor(Math.random() * 5000) + 1000, // Tra 10€ e 60€
        category: 'Donna',
        brand: 'Zara',
        size: 'M',
        condition: 'Ottimo',
        shippingCost: 500,
        sellerId: user.id,
        status: 'sold', // Importante: stato venduto
        photos: ['https://loremflickr.com/500/500/fashion,clothes?lock=' + (i + 100)]
      });

      // Crea ordine completato
      await Order.create({
        buyerId: partner.id,
        sellerId: user.id,
        listingId: listing.id,
        amount: listing.price + listing.shippingCost,
        status: 'delivered'
      });
    }

    // 4. Genera ACQUISTI (Partner vende, Tu compri)
    console.log('🛍️  Generazione acquisti...');
    for (let i = 0; i < purchasesTarget; i++) {
      // Crea annuncio del partner
      const listing = await Listing.create({
        title: `Acquisto Demo #${i + 1}`,
        description: 'Articolo acquistato per test.',
        price: Math.floor(Math.random() * 8000) + 2000, // Tra 20€ e 100€
        category: 'Uomo',
        brand: 'Nike',
        size: 'L',
        condition: 'Nuovo',
        shippingCost: 500,
        sellerId: partner.id,
        status: 'sold',
        photos: ['https://loremflickr.com/500/500/fashion,shoes?lock=' + (i + 200)]
      });

      // Crea ordine tuo
      await Order.create({
        buyerId: user.id,
        sellerId: partner.id,
        listingId: listing.id,
        amount: listing.price + listing.shippingCost,
        status: 'delivered'
      });
    }

    // Aggiorna contatori se necessario (opzionale, dipende dalla logica del tuo DB)
    // user.reviewCount = ...; 
    // await user.save();

    console.log('✅ Fatto! Il profilo ora ha lo storico richiesto.');
    process.exit(0);

  } catch (error) {
    console.error('❌ Errore:', error);
    process.exit(1);
  }
}

seedUserStats();