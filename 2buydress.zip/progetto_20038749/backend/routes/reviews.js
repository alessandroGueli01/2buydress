const express = require('express');
const router = express.Router();
const { Review, User, Notification } = require('../models');
const auth = require('../middleware/auth');
const { body, validationResult } = require('express-validator');

/**
 * @route   POST /api/reviews
 * @desc    Crea una recensione per un utente
 * @access  Private
 */
router.post(
  '/',
  [
    auth,
    body('targetId', 'ID utente destinatario obbligatorio').isInt(),
    body('rating', 'Il rating deve essere tra 1 e 5').isInt({ min: 1, max: 5 }),
    body('comment', 'Il commento è opzionale ma deve essere una stringa').optional().isString()
  ],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { targetId, rating, comment } = req.body;
    const authorId = req.user.id;

    if (parseInt(targetId) === authorId) {
      return res.status(400).json({ message: 'Non puoi recensirti da solo.' });
    }

    try {
      // 1. Verifica che l'utente target esista
      const targetUser = await User.findByPk(targetId);
      if (!targetUser) {
        return res.status(404).json({ message: 'Utente destinatario non trovato.' });
      }

      // 2. Crea la recensione
      const review = await Review.create({
        authorId,
        targetId,
        rating,
        comment
      });

      // 3. Aggiorna le statistiche dell'utente (Rating medio e conteggio)
      const reviews = await Review.findAll({ where: { targetId } });
      const totalRating = reviews.reduce((acc, curr) => acc + curr.rating, 0);
      const averageRating = totalRating / reviews.length;

      targetUser.rating = parseFloat(averageRating.toFixed(1)); // Arrotonda a 1 decimale
      targetUser.reviewCount = reviews.length;
      await targetUser.save();

      // 4. Crea notifica per l'utente che ha ricevuto la recensione
      const authorUser = await User.findByPk(authorId, { attributes: ['name'] });
      await Notification.create({
        recipientId: targetUser.id,
        senderId: authorId,
        type: 'new_review',
        content: {
          message: `${authorUser?.name || 'Un utente'} ti ha lasciato una recensione da ${rating}/5.`
        }
      });

      res.status(201).json(review);
    } catch (error) {
      next(error);
    }
  }
);

/**
 * @route   GET /api/reviews/user/:userId
 * @desc    Ottiene tutte le recensioni di un utente specifico
 * @access  Public
 */
router.get('/user/:userId', async (req, res, next) => {
  try {
    const { userId } = req.params;

    const reviews = await Review.findAll({
      where: { targetId: userId },
      include: [
        {
          model: User,
          as: 'author', // Assicurati di aver definito l'associazione in models/index.js
          attributes: ['id', 'name', 'avatar']
        }
      ],
      order: [['createdAt', 'DESC']]
    });

    res.json(reviews);
  } catch (error) {
      next(error);
  }
});

module.exports = router;