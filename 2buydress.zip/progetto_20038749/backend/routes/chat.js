const express = require('express');
const { Op } = require('sequelize');
const { sequelize } = require('../config/database');
const { Conversation, Message, User, Listing, Notification } = require('../models');
const auth = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/chat/conversations
// @desc    Ottiene le conversazioni dell'utente
// @access  Private
router.get('/conversations', auth, async (req, res, next) => {
  try {
    const user = await User.findByPk(req.user.id);
    const conversations = await user.getConversations({
      include: [
        {
          model: User,
          as: 'participants',
          attributes: ['id', 'name', 'avatar'],
          through: { attributes: [] } // Non includere i dati della tabella ponte
        },
        {
          model: Listing,
          as: 'listing',
          attributes: ['id', 'title', 'photos']
        },
        // Includiamo l'ultimo messaggio di ogni conversazione
        {
          model: Message,
          as: 'messages',
          order: [['createdAt', 'DESC']],
          limit: 1,
          include: [{ model: User, as: 'sender', attributes: ['id', 'name'] }]
        }
      ],
      order: [['lastMessageAt', 'DESC']]
    });

    // Rinominiamo 'messages' in 'lastMessage' per compatibilità con il frontend
    // Usiamo Promise.all per gestire le query asincrone del conteggio
    const formattedConversations = await Promise.all(conversations.map(async (conv) => {
      const plainConv = conv.toJSON();
      plainConv.lastMessage = plainConv.messages ? plainConv.messages[0] : null;
      delete plainConv.messages;

      // Conta i messaggi non letti dove il destinatario è l'utente corrente
      plainConv.unreadCount = await Message.count({
        where: {
          conversationId: conv.id,
          senderId: { [Op.ne]: req.user.id }, // Messaggi NON inviati da me
          isRead: false
        }
      });

      return plainConv;
    }));

    res.json({ conversations: formattedConversations });
  } catch (error) {
    next(error);
  }
});

// @route   POST /api/chat/conversations
// @desc    Crea o trova una conversazione esistente
// @access  Private
router.post('/conversations', auth, async (req, res, next) => {
  try {
    const { listingId, otherUserId } = req.body;
    const currentUserId = req.user.id;

    // Transazione per garantire l'atomicità dell'operazione
    const result = await sequelize.transaction(async (t) => {
      // 1. Cerca una conversazione esistente per questo annuncio e questi due utenti
      const existingConversation = await Conversation.findOne({
        where: { listingId },
        include: [{
          model: User,
          as: 'participants',
          where: { id: { [Op.in]: [currentUserId, otherUserId] } },
          through: { attributes: [] }
        }],
        transaction: t
      });

      // Filtra per assicurarsi che ci siano ESATTAMENTE due partecipanti
      if (existingConversation && existingConversation.participants.length === 2) {
        return existingConversation;
      }

      // 2. Se non esiste, crea una nuova conversazione
      const newConversation = await Conversation.create({
        listingId,
        lastMessageAt: new Date() // Imposta una data per farla apparire in cima
      }, { transaction: t });

      // 3. Aggiungi i partecipanti alla conversazione
      await newConversation.addParticipants([currentUserId, otherUserId], { transaction: t });

      return newConversation;
    });

    // Popola i dati necessari per il frontend dopo la transazione
    const finalConversation = await Conversation.findByPk(result.id, {
      include: [
        { model: User, as: 'participants', attributes: ['id', 'name', 'avatar'] },
        { model: Listing, as: 'listing', attributes: ['id', 'title', 'photos'] }
      ]
    });

    res.status(201).json(finalConversation);
  } catch (error) {
    next(error);
  }
});

// @route   GET /api/chat/conversations/:id/messages
// @desc    Ottiene i messaggi di una conversazione
// @access  Private
router.get('/conversations/:id/messages', auth, async (req, res, next) => {
  try {
    const conversation = await Conversation.findByPk(req.params.id);
    if (!conversation) return res.status(404).json({ message: 'Conversazione non trovata' });
    
    // Controlla se l'utente è un partecipante
    const isParticipant = await conversation.hasParticipant(req.user.id);
    if (!isParticipant) {
      return res.status(403).json({ message: 'Non autorizzato' });
    }

    const messages = await Message.findAll({
      where: { conversationId: req.params.id },
      include: [{ model: User, as: 'sender', attributes: ['id', 'name', 'avatar'] }],
      order: [['createdAt', 'ASC']]
    });

    res.json({ messages });
  } catch (error) {
    next(error);
  }
});

// @route   POST /api/chat/conversations/:id/messages
// @desc    Invia un messaggio
// @access  Private
router.post('/conversations/:id/messages', auth, async (req, res, next) => {
  try {
    const { content, type = 'text' } = req.body;
    const conversationId = req.params.id;
    const senderId = req.user.id;

    const conversation = await Conversation.findByPk(conversationId);
    if (!conversation) return res.status(404).json({ message: 'Conversazione non trovata' });

    const isParticipant = await conversation.hasParticipant(senderId);
    if (!isParticipant) return res.status(403).json({ message: 'Non autorizzato' });

    const message = await Message.create({ conversationId, senderId, content, type });

    // Aggiorna il timestamp dell'ultimo messaggio per l'ordinamento
    await conversation.update({ lastMessageAt: message.createdAt });

    // --- CREA NOTIFICA PER NUOVO MESSAGGIO ---
    try {
      // Trova tutti i partecipanti alla conversazione
      const participants = await conversation.getParticipants({ attributes: ['id'] });
      // Per ogni partecipante che NON è il mittente, crea una notifica
      for (const participant of participants) {
        if (participant.id !== senderId) {
          await Notification.create({
            recipientId: participant.id,
            senderId: senderId,
            listingId: conversation.listingId,
            type: 'new_message',
            content: {
              message: `Hai un nuovo messaggio da ${req.user.name}.`,
              conversationId: conversation.id,
            },
          });
        }
      }
    } catch (notificationError) {
      console.error('Errore durante la creazione della notifica per il nuovo messaggio:', notificationError);
    }

    // Popola i dati del mittente per la risposta
    const finalMessage = await Message.findByPk(message.id, {
      include: [{ model: User, as: 'sender', attributes: ['id', 'name', 'avatar'] }]
    });

    res.status(201).json({ message: finalMessage });
  } catch (error) {
    next(error);
  }
});

// @route   PATCH /api/chat/conversations/:id/read
// @desc    Segna tutti i messaggi di una conversazione come letti
// @access  Private
router.patch('/conversations/:id/read', auth, async (req, res, next) => {
  try {
    const conversationId = req.params.id;
    const userId = req.user.id;

    // 1. Verifica che l'utente sia un partecipante della conversazione
    const conversation = await Conversation.findByPk(conversationId);
    if (!conversation) {
      return res.status(404).json({ message: 'Conversazione non trovata.' });
    }
    const isParticipant = await conversation.hasParticipant(userId);
    if (!isParticipant) {
      return res.status(403).json({ message: 'Non sei autorizzato a modificare questa conversazione.' });
    }

    // 2. Aggiorna tutti i messaggi non letti in questa conversazione che non sono stati inviati dall'utente stesso
    await Message.update(
      { isRead: true, readAt: new Date() },
      { where: { conversationId: conversationId, senderId: { [Op.ne]: userId }, isRead: false } }
    );

    res.status(200).json({ message: 'Messaggi segnati come letti.' });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
