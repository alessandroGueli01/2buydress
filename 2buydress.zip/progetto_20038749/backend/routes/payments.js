const express = require('express');
const { sequelize } = require('../config/database');
const { Listing, Order, Notification, User } = require('../models');
const auth = require('../middleware/auth');
const sendEmail = require('../utils/sendEmail');

const router = express.Router();

/**
 * @route   POST /api/payments/pay
 * @desc    Simula un pagamento e crea l'ordine istantaneamente
 * @access  Private
 */
router.post('/pay', auth, async (req, res, next) => {
  const { listingId } = req.body;
  
  if (!listingId) {
    return res.status(400).json({ message: 'ID annuncio mancante.' });
  }

  // Fix: Recuperiamo l'utente completo dal DB per avere l'indirizzo di spedizione
  const buyer = await User.findByPk(req.user.id);
  if (!buyer) {
    return res.status(404).json({ message: 'Utente non trovato.' });
  }

  // Aggiungiamo un controllo di sicurezza lato server per l'indirizzo
  if (!buyer.addressLine1 || !buyer.city || !buyer.postalCode || !buyer.country) {
    return res.status(400).json({ message: 'Indirizzo di spedizione incompleto. Per favore, aggiorna il tuo profilo.' });
  }

  // Avvia una transazione database gestita (ACID)
  const t = await sequelize.transaction();

  try {
    // 1. Trova l'annuncio e bloccalo (lock) per evitare doppi acquisti simultanei
    const listing = await Listing.findByPk(listingId, { 
      // Rimuoviamo l'include per evitare problemi di lock su tabelle unite
      lock: true,
      transaction: t
    });

    if (!listing) {
      await t.rollback();
      return res.status(404).json({ message: 'Annuncio non trovato.' });
    }
    if (listing.status !== 'active') {
      await t.rollback();
      return res.status(400).json({ message: 'Questo articolo non è più disponibile.' });
    }
    if (listing.sellerId === buyer.id) {
      await t.rollback();
      return res.status(400).json({ message: 'Non puoi acquistare un tuo stesso articolo.' });
    }

    // 2. Aggiorna lo stato dell'annuncio
    listing.status = 'sold';
    await listing.save({ transaction: t });

    // 3. Crea l'ordine
    const shippingCost = listing.shippingCost || 0;

    const order = await Order.create({
      listingId: listing.id,
      buyerId: buyer.id,
      sellerId: listing.sellerId,
      amount: listing.price + shippingCost,
      shippingCost: shippingCost,
      shippingAddress: {
        addressLine1: buyer.addressLine1,
        city: buyer.city,
        postalCode: buyer.postalCode,
        country: buyer.country,
      },
      status: 'paid',
      transactionId: `SIM-${Date.now()}-${Math.floor(Math.random() * 1000)}`, // Genera un ID transazione finto
    }, { transaction: t });

    // --- INCREMENTO CONTATORI UTENTE ---
    await User.increment('purchasesCount', { by: 1, where: { id: buyer.id }, transaction: t });
    await User.increment('salesCount', { by: 1, where: { id: listing.sellerId }, transaction: t });

    await t.commit();

    // 4. Operazioni post-transazione (Notifiche ed Email)
    // Non blocchiamo la risposta per queste operazioni
    Notification.create({
      recipientId: listing.sellerId,
      senderId: buyer.id,
      listingId: listing.id,
      type: 'item_sold',
      content: { message: `Il tuo articolo "${listing.title}" è stato venduto!` }
    }).catch(err => console.error('Errore notifica:', err));

    // --- SIMULAZIONE LOGISTICA ---
    simulateShipping(order.id, buyer.id, listing.sellerId, listing.title);

    res.status(201).json({ success: true, order });

  } catch (error) {
    await t.rollback();
    next(error);
  }
});

// Funzione helper per simulare il cambio di stato (Spedizione automatica)
const simulateShipping = (orderId, buyerId, sellerId, listingTitle) => {
  // Attende 10 secondi (10000 ms) prima di "spedire"
  setTimeout(async () => {
    try {
      const order = await Order.findByPk(orderId);
      // Procedi solo se l'ordine è ancora nello stato 'paid'
      if (order && order.status === 'paid') {
        order.status = 'shipped';
        order.courier = 'Corriere 2BuyDress (Simulato)';
        order.trackingCode = 'TRK-' + Math.random().toString(36).substr(2, 9).toUpperCase();
        await order.save();

        console.log(`[SIMULAZIONE] Ordine #${orderId} passato a stato SHIPPED.`);

        // Invia notifica all'acquirente
        await Notification.create({
          recipientId: buyerId,
          senderId: sellerId,
          listingId: order.listingId,
          type: 'order_update', 
          content: { message: `Buone notizie! Il tuo ordine "${listingTitle}" è stato spedito. Tracking: ${order.trackingCode}` }
        });
      }
    } catch (error) {
      console.error('[SIMULAZIONE] Errore durante la spedizione automatica:', error);
    }
  }, 10000);
};

module.exports = router;