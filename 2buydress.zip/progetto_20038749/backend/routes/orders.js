const express = require('express');
const router = express.Router();
const { Order, Listing, User, Notification } = require('../models');
const auth = require('../middleware/auth');
const sendEmail = require('../utils/sendEmail');

/**
 * @route   GET /api/orders/:id
 * @desc    Ottiene i dettagli di un ordine
 * @access  Private (Solo Buyer o Seller)
 */
router.get('/:id', auth, async (req, res, next) => {
  try {
    const order = await Order.findByPk(req.params.id, {
      include: [
        { model: Listing, as: 'listing' },
        { model: User, as: 'buyer', attributes: ['id', 'name', 'email'] },
        { model: User, as: 'seller', attributes: ['id', 'name', 'email'] }
      ]
    });

    if (!order) return res.status(404).json({ message: 'Ordine non trovato' });

    // Controllo permessi
    if (order.buyerId !== req.user.id && order.sellerId !== req.user.id && !req.user.is_admin) {
      return res.status(403).json({ message: 'Accesso negato' });
    }

    res.json(order);
  } catch (error) {
    next(error);
  }
});

/**
 * @route   PUT /api/orders/:id/ship
 * @desc    Il venditore segna l'ordine come spedito e aggiunge tracking
 * @access  Private (Solo Seller)
 */
router.put('/:id/ship', auth, async (req, res, next) => {
  const { courier, trackingCode } = req.body;

  try {
    const order = await Order.findByPk(req.params.id, {
      include: [{ model: User, as: 'buyer' }, { model: Listing, as: 'listing' }]
    });

    if (!order) return res.status(404).json({ message: 'Ordine non trovato' });
    if (order.sellerId !== req.user.id) return res.status(403).json({ message: 'Solo il venditore può spedire l\'ordine' });
    if (order.status !== 'paid') return res.status(400).json({ message: `L'ordine non è nello stato corretto per essere spedito (stato attuale: ${order.status})` });

    order.status = 'shipped';
    order.courier = courier;
    order.trackingCode = trackingCode;
    await order.save();

    // Notifica al Buyer
    await Notification.create({
      recipientId: order.buyerId,
      senderId: req.user.id,
      listingId: order.listingId,
      type: 'order_shipped',
      content: { message: `Il tuo ordine "${order.listing.title}" è stato spedito!`, trackingCode: trackingCode || 'N/A' }
    });

    try {
      await sendEmail({
        email: order.buyer.email,
        subject: 'Il tuo ordine è in viaggio!',
        message: `Ciao ${order.buyer.name},\n\nIl venditore ha spedito il tuo pacco.\nCorriere: ${courier}\nTracking: ${trackingCode}\n\nA presto!`
      });
    } catch (e) { console.error(e); }

    res.json(order);
  } catch (error) {
    next(error);
  }
});

/**
 * @route   PUT /api/orders/:id/receive
 * @desc    L'acquirente conferma la ricezione
 * @access  Private (Solo Buyer)
 */
router.put('/:id/receive', auth, async (req, res, next) => {
  try {
    if (!req.params.id) {
      return res.status(400).json({ message: 'ID ordine mancante' });
    }

    // Fix: Includiamo il Listing per poter accedere al titolo nella notifica
    const order = await Order.findByPk(req.params.id, {
      include: [{ model: Listing, as: 'listing' }]
    });
    if (!order) return res.status(404).json({ message: 'Ordine non trovato' });
    if (order.buyerId !== req.user.id) return res.status(403).json({ message: 'Solo l\'acquirente può confermare la ricezione' });
    if (order.status !== 'shipped') return res.status(400).json({ message: 'L\'ordine non è nello stato corretto per essere contrassegnato come ricevuto.' });

    order.status = 'delivered';
    await order.save();

    // Notifica il venditore che l'articolo è stato consegnato
    await Notification.create({
      recipientId: order.sellerId,
      senderId: req.user.id,
      listingId: order.listingId,
      type: 'order_delivered',
      content: { message: `L'articolo "${order.listing.title}" è stato consegnato all'acquirente. Il pagamento sarà presto elaborato.` }
    });

    res.json({ message: 'Ordine completato', order });
  } catch (error) { next(error); }
});

module.exports = router;