const express = require('express');
const { Notification, User, Listing } = require('../models');
const auth = require('../middleware/auth');

const router = express.Router();

// @route   GET /api/notifications
// @desc    Ottiene le notifiche per l'utente loggato
// @access  Private
router.get('/', auth, async (req, res, next) => {
  try {
    const notifications = await Notification.findAll({
      where: { recipientId: req.user.id },
      order: [['createdAt', 'DESC']],
      include: [
        { model: User, as: 'sender', attributes: ['id', 'name', 'avatar'] },
        { model: Listing, as: 'listing', attributes: ['id', 'title', 'photos'] }
      ]
    });

    res.json(notifications);
  } catch (error) {
    next(error);
  }
});

// @route   PATCH /api/notifications/read-all
// @desc    Segna tutte le notifiche come lette
// @access  Private
router.patch('/read-all', auth, async (req, res, next) => {
  try {
    await Notification.update(
      { isRead: true, readAt: new Date() },
      { where: { recipientId: req.user.id, isRead: false } }
    );

    res.status(200).json({ message: 'Tutte le notifiche sono state segnate come lette.' });
  } catch (error) {
    next(error);
  }
});

// @route   PATCH /api/notifications/:id/read
// @desc    Segna una singola notifica come letta
// @access  Private
router.patch('/:id/read', auth, async (req, res, next) => {
  try {
    const notification = await Notification.findOne({
      where: {
        id: req.params.id,
        recipientId: req.user.id,
      },
    });

    if (!notification) {
      return res.status(404).json({ message: 'Notifica non trovata.' });
    }

    if (!notification.isRead) {
      notification.isRead = true;
      notification.readAt = new Date();
      await notification.save();
    }

    res.json(notification);
  } catch (error) {
    next(error);
  }
});

module.exports = router;