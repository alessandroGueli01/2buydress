const express = require('express');
const router = express.Router();

// @route   POST /api/webhook
// @desc    Endpoint disabilitato (modalità simulazione)
router.post('/', (req, res) => {
  res.status(200).json({ message: 'Webhook non attivo in modalità simulazione.' });
});

module.exports = router;