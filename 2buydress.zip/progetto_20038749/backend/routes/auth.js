const express = require('express');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const { body, validationResult } = require('express-validator');
const { User } = require('../models');
const auth = require('../middleware/auth');
const sendEmail = require('../utils/sendEmail');

const router = express.Router();

// Rate Limiter per le rotte di autenticazione per prevenire attacchi brute-force
const authLimiter = rateLimit({
	windowMs: 15 * 60 * 1000, // 15 minuti
	max: 10, // Limita ogni IP a 10 richieste per finestra (su login, register, etc.)
	standardHeaders: true, // Invia header standard `RateLimit-*`
	legacyHeaders: false, // Disabilita gli header `X-RateLimit-*`
  message: { message: 'Troppi tentativi da questo IP, riprova tra 15 minuti.' },
});


// Middleware di validazione per la registrazione
const validateRegistration = [
  body('name', 'Il nome è obbligatorio').not().isEmpty().trim().escape(),
  body('email', 'Per favore, inserisci un\'email valida').isEmail().normalizeEmail(),
  body('password', 'La password deve essere di almeno 6 caratteri').isLength({ min: 6 })
];

// @route   POST /api/auth/register
// @desc    Registra un nuovo utente
// @access  Public
router.post('/register', [authLimiter, ...validateRegistration], async (req, res, next) => {
  // Controlla i risultati della validazione
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { name, email, password } = req.body;

    // 1. Controlla se l'utente esiste già
    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      return res.status(400).json({ message: 'Un utente con questa email esiste già.' });
    }

    // 2. Crea il nuovo utente. L'hook 'beforeSave' nel modello si occuperà dell'hashing.
    const user = await User.create({ name, email, password });

    // 3. Crea il token JWT
    const payload = { user: { id: user.id } }; // Usiamo l'ID di Sequelize
    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '7d' });

    // 4. Invia la risposta con token e dati utente (il toJSON rimuoverà la password)
    res.status(201).json({
      message: 'Registrazione completata con successo!',
      token,
      user: user.toJSON()
    });

  } catch (error) {
    // Se la validazione di Sequelize fallisce (es. password corta), invia un errore 400
    if (error.name === 'SequelizeValidationError') {
      const messages = error.errors.map(e => e.message).join(', ');
      return res.status(400).json({ message: messages });
    }
    next(error); // Passa ad altri errori al middleware di gestione
  }
});

// @route   POST /api/auth/login
// @desc    Autentica l'utente e ottiene il token
// @access  Public
router.post('/login', authLimiter, async (req, res, next) => {
  try {
    const { email, password } = req.body;

    // 1. Trova l'utente tramite email.
    // Usiamo .unscoped() per bypassare il defaultScope del modello User,
    // che per sicurezza nasconde la password. Per il login, abbiamo bisogno di recuperarla.
    const user = await User.unscoped().findOne({ where: { email } });
    if (!user) {
      return res.status(401).json({ message: 'Credenziali non valide.' });
    }

    // 2. Confronta la password usando il metodo del modello
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Credenziali non valide.' });
    }

    // NUOVO CONTROLLO: Verifica se l'utente è sospeso
    if (user.is_suspended) {
      return res.status(403).json({ message: 'Il tuo account è stato sospeso. Contatta il supporto per maggiori informazioni.' });
    }

    // 3. Crea e invia il token JWT
    const payload = { user: { id: user.id } };
    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '7d' });

    res.json({
      token,
      user: user.toJSON()
    });

  } catch (error) {
    next(error);
  }
});

// @route   GET /api/auth/me
// @desc    Ottiene i dati dell'utente loggato
// @access  Private
router.get('/me', auth, async (req, res, next) => {
  try {
    // req.user.id è impostato dal middleware di autenticazione JWT
    // Usiamo findByPk (Find by Primary Key) che è ottimizzato per cercare tramite ID
    const user = await User.findByPk(req.user.id);

    if (!user) {
      return res.status(404).json({ message: 'Utente non trovato.' });
    }

    res.json(user.toJSON());

  } catch (error) {
    next(error);
  }
});

// @route   POST /api/auth/forgot-password
// @desc    Invia un'email per il reset della password
// @access  Public
router.post('/forgot-password', authLimiter, async (req, res, next) => {
  try {
    // 1. Trova l'utente tramite email
    const user = await User.findOne({ where: { email: req.body.email } });
    if (!user) {
      // Per sicurezza, non riveliamo se l'utente esiste o meno
      return res.status(200).json({ message: 'Se l\'utente esiste, riceverà un\'email per il reset della password.' });
    }

    // 2. Genera il token di reset
    const resetToken = user.createPasswordResetToken();
    await user.save({ validate: false }); // Salva il token e la scadenza nel DB

    // 3. Crea l'URL di reset e invia l'email
    // Assicurati di avere FRONTEND_URL nel tuo file .env
    const resetURL = `${process.env.FRONTEND_URL}/reset-password/${resetToken}`;

    const message = `Hai dimenticato la password? Invia una richiesta PATCH con la tua nuova password a: ${resetURL}.\nSe non hai richiesto tu il reset, ignora questa email.`;

    await sendEmail({
      email: user.email,
      subject: 'Reset della password (valido per 10 minuti)',
      message,
    });

    res.status(200).json({ message: 'Se l\'utente esiste, riceverà un\'email per il reset della password.' });

  } catch (error) {
    // In caso di errore, resetta i campi del token per sicurezza
    if (req.user) {
      req.user.passwordResetToken = null;
      req.user.passwordResetExpires = null;
      await req.user.save({ validate: false });
    }
    next(error);
  }
});

// @route   PATCH /api/auth/reset-password/:token
// @desc    Resetta la password dell'utente
// @access  Public
router.patch('/reset-password/:token', authLimiter, async (req, res, next) => {
  try {
    // 1. Hash del token ricevuto per confrontarlo con quello nel DB
    const hashedToken = crypto
      .createHash('sha256')
      .update(req.params.token)
      .digest('hex');

    // 2. Trova l'utente con quel token e controlla che non sia scaduto
    const user = await User.findOne({
      where: {
        passwordResetToken: hashedToken,
        passwordResetExpires: { [require('sequelize').Op.gt]: Date.now() },
      },
    });

    if (!user) {
      return res.status(400).json({ message: 'Token non valido o scaduto.' });
    }

    // 3. Imposta la nuova password
    // L'hook 'beforeSave' si occuperà dell'hashing
    user.password = req.body.password;
    user.passwordResetToken = null;
    user.passwordResetExpires = null;
    await user.save();

    // 4. Effettua il login automatico creando un nuovo JWT
    const payload = { user: { id: user.id } };
    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '7d' });

    res.json({
      message: 'Password aggiornata con successo!',
      token,
      user: user.toJSON()
    });

  } catch (error) {
    // Gestisce errori di validazione della password (es. troppo corta)
    if (error.name === 'SequelizeValidationError') {
      return res.status(400).json({ message: error.errors.map(e => e.message).join(', ') });
    }
    next(error);
  }
});

module.exports = router;
