const express = require('express');
const path = require('path');
const multer = require('multer');
const fs = require('fs');
const { body, validationResult } = require('express-validator');

const { User, Listing, Order } = require('../models');
const createUploader = require('../middleware/upload');
const auth = require('../middleware/auth');

const router = express.Router();

// --- Configurazione Multer per l'upload dell'avatar ---
const avatarStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(__dirname, '../uploads/avatars');
    fs.mkdirSync(uploadPath, { recursive: true });
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = req.user.id + '-' + Date.now();
    cb(null, 'avatar-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const avatarUpload = createUploader('avatars').single('avatar');

// @route   GET /api/users/:id
// @desc    Ottiene il profilo pubblico di un utente
// @access  Public
router.get('/:id', async (req, res, next) => {
  try {
    const user = await User.findByPk(req.params.id, {
      // Seleziona solo i campi pubblici per sicurezza
      attributes: ['name', 'avatar', 'bio', 'location', 'rating', 'reviewCount', 'createdAt']
    });

    if (!user) {
      return res.status(404).json({ message: 'Utente non trovato.' });
    }
    res.json(user);
  } catch (error) {
    next(error);
  }
});

// @route   GET /api/users/:userId/listings
// @desc    Ottiene gli annunci di un utente specifico
// @access  Public
router.get('/:userId/listings', async (req, res, next) => {
  try {
    const { status } = req.query;
    const where = { sellerId: req.params.userId };
    if (status) {
      where.status = status;
    }

    const { count, rows } = await Listing.findAndCountAll({
      where,
      order: [['createdAt', 'DESC']],
      // Aggiunta per includere i dati del venditore, per coerenza con le altre API
      include: [{
        model: User,
        as: 'seller',
        attributes: ['id', 'name', 'avatar']
      }]
    });

    res.json({
      listings: rows,
      totalDocs: count
    });
  } catch (error) {
    next(error);
  }
});

// @route   GET /api/users/me/orders
// @desc    Ottiene gli acquisti e le vendite dell'utente loggato
// @access  Private
router.get('/me/orders', auth, async (req, res, next) => {
  try {
    const userId = req.user.id;

    // Ottiene gli ordini dove l'utente è l'acquirente
    const purchases = await Order.findAll({
      where: { buyerId: userId },
      include: [{
        model: Listing,
        as: 'listing',
        attributes: ['id', 'title', 'photos']
      }, {
        model: User,
        as: 'seller',
        attributes: ['id', 'name']
      }],
      order: [['createdAt', 'DESC']]
    });

    // Ottiene gli ordini dove l'utente è il venditore
    const sales = await Order.findAll({
      where: { sellerId: userId },
      include: [{
        model: Listing,
        as: 'listing',
        attributes: ['id', 'title', 'photos']
      }, {
        model: User,
        as: 'buyer',
        attributes: ['id', 'name']
      }],
      order: [['createdAt', 'DESC']]
    });

    res.json({ purchases, sales });
  } catch (error) {
    next(error);
  }
});

// @route   GET /api/users/me/favorites
// @desc    Ottiene gli annunci preferiti dell'utente loggato
// @access  Private
router.get('/me/favorites', auth, async (req, res, next) => {
  try {
    const user = await User.findByPk(req.user.id);
    if (!user) {
      return res.status(404).json({ message: 'Utente non trovato.' });
    }

    // `getFavoriteListings` è un altro metodo magico di Sequelize.
    // Popoliamo anche i dati del venditore per ogni annuncio.
    const favoriteListings = await user.getFavoriteListings({
      include: [{
        model: User,
        as: 'seller',
        attributes: ['id', 'name', 'avatar']
      }],
      order: [['createdAt', 'DESC']]
    });

    res.json(favoriteListings);
  } catch (error) {
    next(error);
  }
});

// @route   PUT /api/users/profile
// @desc    Aggiorna il profilo dell'utente loggato
// @access  Private
router.put('/profile', [
  auth,
  body('name').notEmpty().withMessage('Il nome è obbligatorio').trim().escape(),
  body('bio').optional().trim().escape(),
  body('location').optional().trim().escape(),
  body('addressLine1').optional().trim().escape(),
  body('city').optional().trim().escape(),
  body('postalCode').optional().trim().escape(),
  body('country').optional().trim().escape(),
], async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    if (!req.user) return res.status(401).json({ message: 'Autenticazione richiesta.' });

    const { name, bio, location, addressLine1, city, postalCode, country } = req.body;
    const user = await User.findByPk(req.user.id);

    // L'utente viene già trovato dal middleware auth, ma questo è un controllo di sicurezza aggiuntivo
    if (!user) return res.status(404).json({ message: 'Utente non trovato.' });

    await user.update({ name, bio, location, addressLine1, city, postalCode, country });

    res.json(user);
  } catch (error) {
    next(error);
  }
});

// @route   PUT /api/users/avatar
// @desc    Aggiorna l'avatar dell'utente loggato
// @access  Private
router.put('/avatar', [auth, avatarUpload], async (req, res, next) => {
  if (!req.user) return res.status(401).json({ message: 'Autenticazione richiesta.' });

  try {
    if (!req.file) {
      return res.status(400).json({ message: 'Nessun file caricato.' });
    }

    const user = await User.findByPk(req.user.id);
    if (!user) {
      return res.status(404).json({ message: 'Utente non trovato.' });
    }

    // Se c'era un avatar precedente, cancellalo dal filesystem
    if (user.avatar) {
      const oldAvatarPath = path.join(__dirname, '..', user.avatar);
      if (fs.existsSync(oldAvatarPath)) {
        fs.unlinkSync(oldAvatarPath);
      }
    }

    const avatarUrl = `/uploads/avatars/${req.file.filename}`;
    await user.update({ avatar: avatarUrl });

    res.json(user);
  } catch (error) {
    next(error);
  }
});

module.exports = router;