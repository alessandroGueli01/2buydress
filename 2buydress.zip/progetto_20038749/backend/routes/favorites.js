const express = require('express');
const router = express.Router();
const { Favorite, Listing, User } = require('../models');
const auth = require('../middleware/auth'); // Middleware per l'autenticazione

/**
 * @route   GET /api/favorites
 * @desc    Ottiene tutti gli annunci preferiti dell'utente loggato
 * @access  Private
 */
router.get('/', auth, async (req, res, next) => {
  const userId = req.user.id;

  try {
    const favorites = await Favorite.findAll({
      where: { userId },
      include: [
        {
          model: Listing,
          // Includi anche i dati del venditore
          include: [
            { model: User, 
              as: 'seller',
              attributes: ['id', 'name', 'avatar'] }
          ]
        }
      ],
      order: [['createdAt', 'DESC']] // Ordina per i più recenti aggiunti
    });

    // Estrai solo i dati degli annunci per una risposta più pulita
    const favoriteListings = favorites.map(fav => fav.Listing);

    res.json(favoriteListings);
  } catch (error) {
    console.error("Errore nel recuperare i preferiti:", error);
    next(error);
  }
});

/**
 * @route   POST /api/favorites
 * @desc    Aggiunge un annuncio ai preferiti dell'utente loggato
 * @access  Private
 */
router.post('/', auth, async (req, res, next) => {
  const { listingId } = req.body;
  const userId = req.user.id;

  if (!listingId) {
    return res.status(400).json({ message: 'ID annuncio mancante.' });
  }

  try {
    // Controlla che l'annuncio esista e che l'utente non stia aggiungendo ai preferiti un proprio annuncio
    const listing = await Listing.findByPk(listingId);
    if (!listing) {
      return res.status(404).json({ message: 'Annuncio non trovato.' });
    }
    if (listing.userId === userId) {
      return res.status(400).json({ message: 'Non puoi aggiungere ai preferiti un tuo annuncio.' });
    }

    const [favorite, created] = await Favorite.findOrCreate({
      where: { userId, listingId },
      defaults: { userId, listingId }
    });

    if (!created) {
      return res.status(409).json({ message: 'Questo annuncio è già nei tuoi preferiti.' });
    }

    res.status(201).json(favorite);
  } catch (error) {
    console.error("Errore nell'aggiungere l'annuncio ai preferiti:", error);
    next(error);
  }
});

/**
 * @route   DELETE /api/favorites/:listingId
 * @desc    Rimuove un annuncio dai preferiti
 * @access  Private
 */
router.delete('/:listingId', auth, async (req, res, next) => {
  const { listingId } = req.params;
  const userId = req.user.id;

  try {
    const result = await Favorite.destroy({
      where: { userId, listingId }
    });

    if (result === 0) {
      return res.status(404).json({ message: 'Annuncio non trovato nei preferiti.' });
    }

    res.status(204).send(); // No Content
  } catch (error) {
    console.error("Errore nel rimuovere l'annuncio dai preferiti:", error);
    next(error);
  }
});

module.exports = router;