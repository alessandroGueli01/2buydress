const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const { Listing, User, Notification } = require('../models');
const auth = require('../middleware/auth');
const { Op } = require('sequelize');
const { body, validationResult } = require('express-validator');

// --- Configurazione Multer per l'upload delle foto degli annunci ---
const listingPhotoStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(__dirname, '../uploads/listings');
    // Usiamo la versione asincrona con callback per essere più robusti e non bloccare l'event loop.
    fs.mkdir(uploadPath, { recursive: true }, (err) => {
      if (err) {
        console.error(`[DIAGNOSTIC] Fallimento creazione cartella di upload: ${uploadPath}`, err);
        return cb(err); // Passa l'errore a Multer, che lo passerà al nostro gestore.
      }
      cb(null, uploadPath);
    });
  },
  filename: (req, file, cb) => {
    // Crea un nome file univoco per evitare sovrascritture
    // Se stiamo creando un nuovo annuncio, req.params.id non esiste, usiamo 'new'
    const id = req.params.id || 'new';
    const uniqueSuffix = id + '-' + Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'listing-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: listingPhotoStorage,
  limits: { fileSize: 1024 * 1024 * 5 }, // Limite di 5MB per file
  fileFilter: (req, file, cb) => {
    // Accetta solo immagini
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Formato file non supportato! Sono permesse solo immagini.'), false);
    }
  }
});

const photosUpload = upload.array('photos', 10);

// Middleware wrapper per Multer per una gestione degli errori più esplicita.
// Questo cattura errori silenziosi (es. permessi) che bloccavano la richiesta.
const handleUpload = (req, res, next) => {
  console.log(`[DIAGNOSTIC] Avvio middleware 'handleUpload' per ${req.method} ${req.originalUrl}`);
  photosUpload(req, res, function (err) {
    if (err) {
      console.error('[DIAGNOSTIC] Errore catturato da Multer:', err);
      if (err instanceof multer.MulterError) {
        return res.status(400).json({ message: `Errore nel caricamento file: ${err.message}` });
      }
      // Per qualsiasi altro errore (es. permessi del filesystem)
      return res.status(500).json({ message: `Errore interno del server durante il caricamento: ${err.message}` });
    }
    console.log(`[DIAGNOSTIC] Middleware 'handleUpload' completato con successo.`);
    next();
  });
};
 
/**
 * @route   GET /api/listings
 * @desc    Ottiene tutti gli annunci pubblici (attivi)
 * @access  Public
 */
router.get('/', async (req, res, next) => {
  const { q, search, minPrice, maxPrice, condition, category, brand, sort, page = 1, limit = 10 } = req.query; 
  const searchQuery = q || search; // Supporta sia 'q' che 'search' come parametro

  // Calcola l'offset per la paginazione
  const offset = (parseInt(page, 10) - 1) * parseInt(limit, 10);
  const parsedLimit = parseInt(limit, 10);

  try {
    const whereClause = {
      // Mostra sempre e solo gli annunci attivi.
      status: 'active'
    };

    // Aggiungi filtro di ricerca testuale su titolo e descrizione
    if (searchQuery) {
      whereClause[Op.or] = [
        { title: { [Op.like]: `%${searchQuery}%` } },
        { description: { [Op.like]: `%${searchQuery}%` } },
        { brand: { [Op.like]: `%${searchQuery}%` } } // Cerca anche nel brand
      ];
    }
    // Aggiungi filtro per il prezzo (ricorda che è in centesimi)
    if (minPrice || maxPrice) {
      whereClause.price = {};
      if (minPrice) {
        // Maggiore o uguale a minPrice
        whereClause.price[Op.gte] = parseInt(minPrice, 10);
      }
      if (maxPrice) {
        // Minore o uguale a maxPrice
        whereClause.price[Op.lte] = parseInt(maxPrice, 10);
      }
    }

    // Aggiungi filtro per la condizione
    if (condition) {
      whereClause.condition = condition;
    }

    // Aggiungi filtro per la categoria
    if (category) {
      whereClause.category = category;
    }

    // Aggiungi filtro per il brand specifico (ricerca parziale)
    if (brand) {
      whereClause.brand = { [Op.like]: `%${brand}%` };
    }

    // Logica di ordinamento dinamico
    let order = [['createdAt', 'DESC']];
    if (sort === 'price_asc') order = [['price', 'ASC']];
    if (sort === 'price_desc') order = [['price', 'DESC']];
    if (sort === 'oldest') order = [['createdAt', 'ASC']];

    // Ottieni il conteggio totale degli annunci
    const totalCount = await Listing.count({
      where: whereClause
    });

    const listings = await Listing.findAll({ // Recupera gli annunci paginati
      where: whereClause,
      include: [
        {
          model: User,
          as: 'seller',
          attributes: ['id', 'name', 'rating', 'reviewCount'] // Includi solo i dati pubblici del venditore
        }
      ],
      order: order,
      // Aggiungi paginazione
      limit: parsedLimit,
      offset: offset
    });

    // Calcola il numero totale di pagine
    const totalPages = Math.ceil(totalCount / parsedLimit);

    res.json({
      listings: listings,
      pagination: { currentPage: parseInt(page), totalPages: totalPages, totalItems: totalCount }
    });
  } catch (error) {
    console.error("Errore nel recuperare gli annunci:", error);
    next(error);
  }
});

/**
 * @route   GET /api/listings/brands
 * @desc    Ottiene la lista dei brand disponibili
 * @access  Public
 */
router.get('/brands', async (req, res, next) => {
  try {
    const brands = await Listing.findAll({
      attributes: ['brand'],
      where: { status: 'active' },
      group: ['brand'],
      order: [['brand', 'ASC']]
    });
    // Restituisce un array semplice di stringhe, filtrando eventuali null
    res.json(brands.map(b => b.brand).filter(b => b));
  } catch (error) {
    console.error("Errore nel recupero dei brand:", error);
    next(error);
  }
});

/**
 * @route   GET /api/listings/:id
 * @desc    Ottiene i dettagli di un singolo annuncio
 * @access  Public
 */
router.get('/:id', async (req, res, next) => {
  try {
    const listingId = req.params.id;

    const listing = await Listing.findByPk(listingId, {
      include: [
        {
          model: User,
          as: 'seller',
          // Seleziona solo i campi pubblici del venditore
          attributes: ['id', 'name', 'avatar', 'bio', 'location', 'rating', 'reviewCount', 'createdAt']
        }
      ]
    });

    if (!listing) {
      return res.status(404).json({ message: 'Annuncio non trovato.' });
    }

    // Non incrementare le visite se il proprietario sta guardando il suo stesso annuncio
    // (Questo richiede autenticazione, per ora lo incrementiamo sempre)
    // In futuro, con l'auth opzionale, si potrebbe fare un controllo.
    listing.increment('views');

    res.json(listing);

  } catch (error) {
    console.error("Errore nel recuperare il dettaglio dell'annuncio:", error);
    next(error); // Passa all'error handler
  }
});

/**
 * @route   POST /api/listings
 * @desc    Crea un nuovo annuncio
 * @access  Private
 */
router.post(
  '/',
  [
    auth, // Middleware di autenticazione
    handleUpload, // Middleware custom per gestire l'upload con logging degli errori
    // Middleware di validazione
    body('title', 'Il titolo è obbligatorio').not().isEmpty().trim(),
    body('description', 'La descrizione è obbligatoria').not().isEmpty().trim(),
    body('price', 'Il prezzo deve essere un numero valido').isNumeric(), // Accettiamo anche stringhe numeriche/float
    body('category', 'La categoria è obbligatoria').not().isEmpty(),
    body('size', 'La taglia è obbligatoria').not().isEmpty(),
    body('condition', 'La condizione è obbligatoria').not().isEmpty(),
  ],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      // Se la validazione fallisce, i file sono già stati caricati da Multer.
      // Li cancelliamo per evitare di lasciare file orfani sul server.
      if (req.files) {
        req.files.forEach(file => fs.unlink(file.path, err => {
          if (err) console.error(`Errore nella pulizia del file ${file.path}:`, err);
        }));
      }
      return res.status(400).json({ errors: errors.array() });
    }

    console.log('[DIAGNOSTIC] Inizio creazione annuncio.');
    console.log('[DIAGNOSTIC] Dati ricevuti (body):', req.body);
    console.log('[DIAGNOSTIC] File ricevuti (files):', req.files);
    console.log('[DIAGNOSTIC] Utente (da token):', req.user);

    try {
      const { title, description, category, brand, size, condition } = req.body;
      const sellerId = req.user.id;

      // Convertiamo il prezzo da Euro (come inviato dal form) a Centesimi (come salvato nel DB)
      const price = Math.round(parseFloat(req.body.price) * 100);
      const shippingCost = req.body.shippingCost ? Math.round(parseFloat(req.body.shippingCost) * 100) : 0;

      // Gestione delle foto caricate
      const photos = req.files ? req.files.map(file => `/uploads/listings/${file.filename}`) : [];

      const newListing = await Listing.create({
        title,
        description,
        price,
        category,
        brand,
        size,
        condition,
        shippingCost,
        photos, // Salviamo l'array dei percorsi delle immagini
        sellerId,
        status: 'active' // L'annuncio è subito attivo
      });

      console.log(`[DIAGNOSTIC] Annuncio con ID ${newListing.id} creato con successo nel DB.`);
      res.status(201).json(newListing);
    } catch (error) {
      // Se si verifica un errore durante la creazione del listing nel DB,
      // dobbiamo cancellare i file che sono stati comunque caricati.
      console.error('[DIAGNOSTIC] Errore durante il salvataggio dell\'annuncio nel database:', error);
      if (req.files) {
        req.files.forEach(file => fs.unlink(file.path, (err) => {
          if (err) console.error(`Errore nella pulizia del file ${file.path}:`, err);
        }));
      }
      next(error);
    }
  }
);

/**
 * @route   PUT /api/listings/:id
 * @desc    Modifica un annuncio esistente
 * @access  Private
 */
router.put(
  '/:id',
  [
    auth,
    handleUpload, // Usa il wrapper anche qui per consistenza
    body('title', 'Il titolo non può essere vuoto').optional().notEmpty(),
    body('price', 'Il prezzo deve essere un numero valido').optional().isNumeric(),
  ],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      // Se ci sono errori di validazione, puliamo i file appena caricati per non lasciare spazzatura
      if (req.files) {
        req.files.forEach(file => fs.unlink(file.path, err => {
          if (err) console.error(`Errore nella pulizia del file ${file.path}:`, err);
        }));
      }
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      const listing = await Listing.findByPk(req.params.id);

      if (!listing) {
        return res.status(404).json({ message: 'Annuncio non trovato.' });
      }

      if (listing.sellerId !== req.user.id) {
        return res.status(403).json({ message: 'Non hai i permessi per modificare questo annuncio.' });
      }

      // Aggiorna i campi di testo
      const allowedUpdates = ['title', 'description', 'category', 'brand', 'size', 'condition'];
      const updates = {};
      for (const key of allowedUpdates) {
        if (req.body[key] !== undefined) {
          updates[key] = req.body[key];
        }
      }

      // Aggiorna prezzo e spedizione (convertendo in centesimi)
      if (req.body.price !== undefined) {
        updates.price = Math.round(parseFloat(req.body.price) * 100);
      }
      if (req.body.shippingCost !== undefined) {
        updates.shippingCost = Math.round(parseFloat(req.body.shippingCost) * 100);
      }

      // Gestione foto
      let currentPhotos = listing.photos || [];
      // Rimuovi le foto specificate
      if (req.body.photosToRemove) {
        try {
          const photosToRemove = JSON.parse(req.body.photosToRemove);
          currentPhotos = currentPhotos.filter(p => !photosToRemove.includes(p));
          // Cancella fisicamente i file rimossi
          photosToRemove.forEach(photoUrl => {
            const filePath = path.join(__dirname, '..', photoUrl);
            if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
          });
        } catch (e) { console.error("Errore nel parsing di photosToRemove:", e); }
      }
      // Aggiungi le nuove foto
      const newPhotos = req.files ? req.files.map(file => `/uploads/listings/${file.filename}`) : [];
      updates.photos = [...currentPhotos, ...newPhotos];

      await listing.update(updates);

      res.json(listing);
    } catch (error) {
      next(error);
    }
  }
);

/**
 * @route   DELETE /api/listings/:id
 * @desc    Cancella (archivia) un annuncio
 * @access  Private
 */
router.delete('/:id', auth, async (req, res, next) => {
  try {
    const listing = await Listing.findByPk(req.params.id);

    // 1. Controlla se l'annuncio esiste
    if (!listing) {
      return res.status(404).json({ message: 'Annuncio non trovato.' });
    }

    // 2. CONTROLLO CRUCIALE: Verifica che l'utente sia il proprietario dell'annuncio
    if (listing.sellerId !== req.user.id) {
      return res.status(403).json({ message: 'Non hai i permessi per cancellare questo annuncio.' });
    }

    // 3. Esegui un "soft delete" impostando lo stato ad 'archived'
    // Questo lo rimuove dalla vista pubblica ma lo mantiene nel database.
    listing.status = 'archived';
    await listing.save();

    // Invia una risposta 204 No Content, standard per le richieste DELETE andate a buon fine.
    res.status(204).send();

  } catch (error) {
    next(error);
  }
});

/**
 * @route   POST /api/listings/:id/photos
 * @desc    Aggiunge foto a un annuncio
 * @access  Private
 */
router.post('/:id/photos', [auth, handleUpload], async (req, res, next) => {
  try {
    const listing = await Listing.findByPk(req.params.id);

    if (!listing) {
      return res.status(404).json({ message: 'Annuncio non trovato.' });
    }

    // CONTROLLO DI SICUREZZA: solo il proprietario può aggiungere foto
    if (listing.sellerId !== req.user.id) {
      return res.status(403).json({ message: 'Non hai i permessi per modificare questo annuncio.' });
    }

    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ message: 'Nessun file caricato.' });
    }

    // Estrai i percorsi dei file caricati e aggiungili all'array esistente
    // Salviamo il percorso relativo per servirlo staticamente
    const photoUrls = req.files.map(file => `/uploads/listings/${file.filename}`);
    const updatedPhotos = [...listing.photos, ...photoUrls];

    // Aggiorna l'annuncio con il nuovo array di foto
    await listing.update({ photos: updatedPhotos });

    res.json(listing);
  } catch (error) {
    next(error);
  }
});

/**
 * @route   POST /api/listings/:id/favorite
 * @desc    Aggiunge un annuncio ai preferiti dell'utente
 * @access  Private
 */
router.post('/:id/favorite', auth, async (req, res, next) => {
  try {
    const listing = await Listing.findByPk(req.params.id);
    if (!listing) {
      return res.status(404).json({ message: 'Annuncio non trovato.' });
    }

    const user = await User.findByPk(req.user.id);

    // Il metodo `addFavoriteListing` è generato automaticamente da Sequelize
    // grazie all'associazione `belongsToMany`.
    await user.addFavoriteListing(listing);

    // --- CREA NOTIFICA ---
    // Invia una notifica al venditore, ma solo se non sta mettendo "mi piace" al suo stesso annuncio
    if (listing.sellerId !== user.id) {
      await Notification.create({
        recipientId: listing.sellerId,
        senderId: user.id,
        listingId: listing.id,
        type: 'new_favorite',
        content: {
          message: `${user.name} ha aggiunto il tuo articolo "${listing.title}" ai preferiti.`,
        },
      });
    }
    // ---------------------

    res.status(200).json({ message: 'Annuncio aggiunto ai preferiti.' });
  } catch (error) {
    // Gestisce il caso in cui il preferito esista già (errore di vincolo univoco)
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(200).json({ message: 'Annuncio già nei preferiti.' });
    }
    next(error);
  }
});

/**
 * @route   DELETE /api/listings/:id/favorite
 * @desc    Rimuove un annuncio dai preferiti dell'utente
 * @access  Private
 */
router.delete('/:id/favorite', auth, async (req, res, next) => {
  try {
    const listing = await Listing.findByPk(req.params.id);
    if (!listing) {
      return res.status(404).json({ message: 'Annuncio non trovato.' });
    }

    const user = await User.findByPk(req.user.id);

    // Anche `removeFavoriteListing` è generato da Sequelize.
    const result = await user.removeFavoriteListing(listing);

    if (result === 0) {
      return res.status(404).json({ message: 'Questo annuncio non era tra i tuoi preferiti.' });
    }

    res.status(200).json({ message: 'Annuncio rimosso dai preferiti.' });
  } catch (error) {
    next(error);
  }
});

module.exports = router;