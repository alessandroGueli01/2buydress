const express = require('express');
const router = express.Router();
const { Report, User, Listing } = require('../models');
const auth = require('../middleware/auth');
const adminAuth = require('../middleware/adminAuth');
const { Op } = require('sequelize');
 
/**
 * @route   POST /api/reports
 * @desc    Crea una nuova segnalazione per un annuncio o un utente
 * @access  Private
 */
router.post('/', auth, async (req, res, next) => {
  const { targetType, targetId, reason } = req.body;
  const reporterId = req.user.id;

  // 1. Validazione dell'input
  if (!targetType || !targetId || !reason) {
    return res.status(400).json({ message: 'Tutti i campi (targetType, targetId, reason) sono obbligatori.' });
  }

  if (!['listing', 'user'].includes(targetType)) {
    return res.status(400).json({ message: "Il tipo di segnalazione può essere solo 'listing' o 'user'." });
  }

  try {
    // 2. Verifica che l'entità da segnalare esista e che l'utente non stia segnalando se stesso
    if (targetType === 'listing') {
      const listing = await Listing.findByPk(targetId);
      if (!listing) {
        return res.status(404).json({ message: 'Annuncio non trovato.' });
      }
    } else if (targetType === 'user') {
      if (parseInt(targetId, 10) === reporterId) {
        return res.status(400).json({ message: 'Non puoi segnalare te stesso.' });
      }
      const user = await User.findByPk(targetId);
      if (!user) {
        return res.status(404).json({ message: 'Utente non trovato.' });
      }
    }

    // 3. Creazione della segnalazione
    const report = await Report.create({
      reporterId,
      targetType,
      targetId,
      reason,
      status: 'pending' // Lo stato iniziale è sempre in attesa di revisione
    });

    res.status(201).json({ message: 'Segnalazione inviata con successo. Grazie per il tuo contributo.', report });

  } catch (error) {
    console.error("Errore nella creazione della segnalazione:", error);
    next(error);
  }
});

/**
 * @route   GET /api/reports
 * @desc    Ottiene tutte le segnalazioni (con filtri opzionali per stato)
 * @access  Admin
 */
router.get('/', adminAuth, async (req, res, next) => {
  const { status } = req.query; // Filtra per /api/reports?status=pending

  try {
    const whereClause = {};
    if (status && ['pending', 'resolved', 'rejected'].includes(status)) {
      whereClause.status = status;
    }

    const reports = await Report.findAll({
      where: whereClause,
      include: [
        { model: User, as: 'reporter', attributes: ['id', 'name', 'email'] }
      ],
      order: [['createdAt', 'DESC']]
    });

    res.json(reports);
  } catch (error) {
    console.error("Errore nel recuperare le segnalazioni:", error);
    next(error);
  }
});

/**
 * @route   PUT /api/reports/:id
 * @desc    Aggiorna lo stato di una segnalazione
 * @access  Admin
 */
router.put('/:id', adminAuth, async (req, res, next) => {
  const { status } = req.body;
  const { id } = req.params;

  if (!status || !['resolved', 'rejected'].includes(status)) {
    return res.status(400).json({ message: "Lo stato può essere solo 'resolved' o 'rejected'." });
  }

  try {
    const report = await Report.findByPk(id);
    if (!report) {
      return res.status(404).json({ message: 'Segnalazione non trovata.' });
    }

    report.status = status;
    await report.save();

    res.json({ message: 'Stato della segnalazione aggiornato con successo.', report });
  } catch (error) {
    console.error("Errore nell'aggiornare la segnalazione:", error);
    next(error);
  }
});

module.exports = router;