const express = require('express');
const router = express.Router();
const { User, Listing, Order } = require('../models');
const adminAuth = require('../middleware/adminAuth');

/**
 * @route   GET /api/admin/stats
 * @desc    Ottiene statistiche generali della piattaforma
 * @access  Admin
 */
router.get('/stats', adminAuth, async (req, res, next) => {
  try {
    const userCount = await User.count();
    const listingCount = await Listing.count();
    const activeListingCount = await Listing.count({ where: { status: 'active' } });
    
    // Se il modello Order esiste (usato in payments.js)
    const orderCount = Order ? await Order.count() : 0;

    res.json({
      users: userCount,
      listings: {
        total: listingCount,
        active: activeListingCount
      },
      orders: orderCount
    });
  } catch (error) {
    next(error);
  }
});

/**
 * @route   PUT /api/admin/users/:id/suspend
 * @desc    Sospende o riattiva un utente (Ban/Unban)
 * @access  Admin
 */
router.put('/users/:id/suspend', adminAuth, async (req, res, next) => {
  try {
    const user = await User.findByPk(req.params.id);

    if (!user) {
      return res.status(404).json({ message: 'Utente non trovato.' });
    }

    if (user.is_admin) {
      return res.status(403).json({ message: 'Non puoi sospendere un altro amministratore.' });
    }

    // Inverte lo stato di sospensione
    user.is_suspended = !user.is_suspended;
    await user.save();

    const statusMsg = user.is_suspended ? 'sospeso' : 'riattivato';
    
    // Opzionale: Qui potresti invalidare i token attivi dell'utente se usassi Redis o una blacklist

    res.json({ 
      message: `Utente ${user.name} ${statusMsg} con successo.`,
      user: {
        id: user.id,
        is_suspended: user.is_suspended
      }
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;