const nodemailer = require('nodemailer');

const sendEmail = async (options) => {
  // 1. Crea un transporter (il servizio che invierà l'email, es. Gmail, Mailtrap)
  // Per un progetto reale, usa variabili d'ambiente!
  // Per testare, puoi usare un servizio come Mailtrap.io
  const transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: process.env.EMAIL_PORT,
    auth: {
      user: process.env.EMAIL_USERNAME,
      pass: process.env.EMAIL_PASSWORD,
    },
  });

  // 2. Definisci le opzioni dell'email
  const mailOptions = {
    from: '2BuyDress Support <support@2buydress.com>',
    to: options.email,
    subject: options.subject,
    text: options.message,
    // html: opzionale, per email formattate
  };

  // 3. Invia l'email
  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Errore durante l\'invio dell\'email:', error);
    throw new Error('Impossibile inviare l\'email di reset password.');
  }
};

module.exports = sendEmail;