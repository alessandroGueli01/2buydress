const { DataTypes, Model } = require('sequelize');

module.exports = (sequelize) => {
  class Review extends Model {}

  Review.init({
    rating: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        min: 1,
        max: 5
      }
    },
    comment: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    authorId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    targetId: { // L'ID dell'utente che riceve la recensione (il venditore)
      type: DataTypes.INTEGER,
      allowNull: false
    }
  }, {
    sequelize,
    modelName: 'Review',
  });

  return Review;
};