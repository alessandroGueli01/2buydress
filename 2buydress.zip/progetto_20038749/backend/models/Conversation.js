const { DataTypes, Model } = require('sequelize');

module.exports = (sequelize) => {
  class Conversation extends Model {}

  Conversation.init({
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    listingId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    status: {
      type: DataTypes.STRING,
      defaultValue: 'active',
      validate: {
        isIn: [['active', 'archived', 'blocked']]
      }
    },
    lastMessageAt: {
      type: DataTypes.DATE
    }
  }, {
    sequelize,
    modelName: 'Conversation',
    timestamps: true
  });

  return Conversation;
};
