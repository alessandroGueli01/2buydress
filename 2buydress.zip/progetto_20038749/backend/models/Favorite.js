const { Model } = require('sequelize');

module.exports = (sequelize) => {
  class Favorite extends Model {}

  Favorite.init({
    // Le colonne `userId` e `listingId` verranno create automaticamente
    // da Sequelize quando definiamo l'associazione `belongsToMany`.
    // Questo modello serve solo come definizione della tabella "ponte".
  }, {
    sequelize,
    modelName: 'Favorite',
    timestamps: true,
    updatedAt: false,
  });

  return Favorite;
};