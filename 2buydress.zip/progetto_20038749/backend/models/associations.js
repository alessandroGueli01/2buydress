function defineAssociations(db) {
  const { User, Listing, Review, Favorite, Conversation, Message, ConversationParticipant, Notification, Order } = db;
  console.log('🔗 Defining model associations...');

  // --- User & Listing (Uno-a-Molti) ---
  // Un utente (venditore) può avere molti annunci.
  User.hasMany(Listing, {
    foreignKey: 'sellerId',
    as: 'listings' // Potremo usare `include: 'listings'`
  });
  // Ogni annuncio appartiene a un solo utente (venditore).
  Listing.belongsTo(User, {
    foreignKey: 'sellerId',
    as: 'seller' // Potremo usare `include: 'seller'`
  });

  // --- User & Review (Uno-a-Molti, due volte) ---
  // Un utente (autore) può scrivere molte recensioni.
  User.hasMany(Review, { foreignKey: 'authorId', as: 'writtenReviews' });
  Review.belongsTo(User, { foreignKey: 'authorId', as: 'author' });

  // Un utente (target) può ricevere molte recensioni.
  User.hasMany(Review, { foreignKey: 'targetId', as: 'receivedReviews' });
  Review.belongsTo(User, { foreignKey: 'targetId', as: 'target' });

  // --- User & Listing (Preferiti, Molti-a-Molti) ---
  // Un utente può avere molti annunci preferiti, e un annuncio può essere nei preferiti di molti utenti.
  // Sequelize creerà una tabella 'Favorites' per gestire questa relazione.
  User.belongsToMany(Listing, {
    through: Favorite,
    as: 'favoriteListings'
  });
  Listing.belongsToMany(User, {
    through: Favorite,
    as: 'favoritedBy'
  });

  // --- Chat Associations ---

  // Conversation & Listing (Uno-a-Molti)
  Listing.hasMany(Conversation, { foreignKey: 'listingId', as: 'conversations' });
  Conversation.belongsTo(Listing, { foreignKey: 'listingId', as: 'listing' });

  // Conversation & Message (Uno-a-Molti)
  Conversation.hasMany(Message, { foreignKey: 'conversationId', as: 'messages' });
  Message.belongsTo(Conversation, { foreignKey: 'conversationId', as: 'conversation' });

  // User & Message (Uno-a-Molti)
  User.hasMany(Message, { foreignKey: 'senderId', as: 'sentMessages' });
  Message.belongsTo(User, { foreignKey: 'senderId', as: 'sender' });

  // User & Conversation (Partecipanti, Molti-a-Molti)
  User.belongsToMany(Conversation, {
    through: ConversationParticipant,
    as: 'conversations'
  });
  Conversation.belongsToMany(User, {
    through: ConversationParticipant,
    as: 'participants'
  });

  // --- Notification Associations ---
  // Un utente può ricevere molte notifiche
  User.hasMany(Notification, { foreignKey: 'recipientId', as: 'notifications' });
  Notification.belongsTo(User, { foreignKey: 'recipientId', as: 'recipient' });

  // Un utente può "inviare" (causare) molte notifiche
  User.hasMany(Notification, { foreignKey: 'senderId', as: 'sentNotifications' });
  Notification.belongsTo(User, { foreignKey: 'senderId', as: 'sender' });

  // Una notifica può essere legata a un annuncio
  Listing.hasMany(Notification, { foreignKey: 'listingId', as: 'notifications' });
  Notification.belongsTo(Listing, { foreignKey: 'listingId', as: 'listing' });

  // --- Order Associations ---
  // Un ordine appartiene a un acquirente (User)
  User.hasMany(Order, { foreignKey: 'buyerId', as: 'purchases' });
  Order.belongsTo(User, { foreignKey: 'buyerId', as: 'buyer' });

  // Un ordine appartiene a un venditore (User)
  User.hasMany(Order, { foreignKey: 'sellerId', as: 'sales' });
  Order.belongsTo(User, { foreignKey: 'sellerId', as: 'seller' });

  // Un ordine è legato a un annuncio (Listing)
  Listing.hasOne(Order, { foreignKey: 'listingId', as: 'order' });
  Order.belongsTo(Listing, { foreignKey: 'listingId', as: 'listing' });

  console.log('✅ Associations defined.');
}

module.exports = defineAssociations;