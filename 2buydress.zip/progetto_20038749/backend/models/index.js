const { sequelize } = require('../config/database');
const fs = require('fs');
const path = require('path');

const db = {};

// Leggi tutti i file nella cartella corrente (models)
fs.readdirSync(__dirname)
  .filter(file => {
    // Filtra per file JavaScript, escludendo se stesso (index.js) e il file delle associazioni
    return (file.indexOf('.') !== 0) && (file !== 'index.js') && (file !== 'associations.js') && (file.slice(-3) === '.js');
  })
  .forEach(file => {
    // Importa la funzione del modello e la chiama con l'istanza di sequelize
    const model = require(path.join(__dirname, file))(sequelize);
    // Aggiunge il modello inizializzato all'oggetto db
    db[model.name] = model;
  });

// Chiama la funzione per definire le associazioni dopo che tutti i modelli sono stati caricati
const defineAssociations = require('./associations');
defineAssociations(db);

// Aggiungi l'istanza di sequelize all'oggetto db
db.sequelize = sequelize;

// Esporta l'oggetto db che contiene tutti i modelli inizializzati
module.exports = db;