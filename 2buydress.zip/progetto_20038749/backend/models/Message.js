const { DataTypes, Model } = require('sequelize');

module.exports = (sequelize) => {
  class Message extends Model {}

  Message.init({
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    content: {
      type: DataTypes.TEXT,
      allowNull: false,
      validate: {
        len: [1, 1000]
      }
    },
    type: {
      type: DataTypes.STRING,
      defaultValue: 'text',
      validate: {
        isIn: [['text', 'image', 'offer']]
      }
    },
    isRead: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    readAt: {
      type: DataTypes.DATE
    },
    conversationId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    senderId: {
      type: DataTypes.INTEGER,
      allowNull: false
    }
  }, {
    sequelize,
    modelName: 'Message',
    timestamps: true
  });

  return Message;
};
