const { Model } = require('sequelize');

module.exports = (sequelize) => {
  class ConversationParticipant extends Model {}

  ConversationParticipant.init({
    // Le colonne `userId` e `conversationId` verranno create automaticamente
    // da Sequelize quando definiamo l'associazione `belongsToMany`.
  }, {
    sequelize,
    modelName: 'ConversationParticipant',
    timestamps: false,
  });

  return ConversationParticipant;
};