const { DataTypes, Model } = require('sequelize');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

module.exports = (sequelize) => {
  class User extends Model {
    // Metodo per confrontare la password fornita con quella hashata nel DB
    async comparePassword(candidatePassword) {
      return bcrypt.compare(candidatePassword, this.password);
    }

    // Metodo per generare il token di reset della password
    createPasswordResetToken() {
      // 1. Crea un token semplice (non hashato)
      const resetToken = crypto.randomBytes(32).toString('hex');

      // 2. Hasha il token e salvalo nel database
      this.passwordResetToken = crypto
        .createHash('sha256')
        .update(resetToken)
        .digest('hex');

      // 3. Imposta una scadenza (es. 10 minuti da adesso)
      this.passwordResetExpires = Date.now() + 10 * 60 * 1000;

      // 4. Restituisci il token semplice (non hashato) da inviare via email
      return resetToken;
    }
  }

  User.init({
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: {
        isEmail: true,
      },
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        len: [6, 255], // La password deve essere di almeno 6 caratteri
      },
    },
    avatar: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    bio: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    location: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    addressLine1: DataTypes.STRING,
    city: DataTypes.STRING,
    postalCode: DataTypes.STRING,
    country: DataTypes.STRING,
    rating: {
      type: DataTypes.FLOAT,
      defaultValue: 0,
    },
    reviewCount: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
    },
    salesCount: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      allowNull: false,
    },
    purchasesCount: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      allowNull: false,
    },
    is_admin: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    is_suspended: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    // Campi per il reset della password
    passwordResetToken: DataTypes.STRING,
    passwordResetExpires: DataTypes.DATE,
  }, {
    sequelize,
    modelName: 'User',
    // Aggiungi hooks per l'hashing automatico della password
    hooks: {
      beforeSave: async (user, options) => {
        // Esegui l'hashing solo se la password è stata modificata
        if (user.changed('password')) {
          const salt = await bcrypt.genSalt(10);
          user.password = await bcrypt.hash(user.password, salt);
        }
      },
    },
    // Rimuovi la password e altri campi sensibili dalle risposte JSON
    defaultScope: {
      attributes: { exclude: ['password', 'passwordResetToken', 'passwordResetExpires'] },
    },
  });

  return User;
};