const { DataTypes, Model } = require('sequelize');

module.exports = (sequelize) => {
  class Listing extends Model {}

  Listing.init({
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    title: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    price: {
      type: DataTypes.INTEGER, // Memorizziamo in centesimi
      allowNull: false,
      validate: {
        min: 0
      }
    },
    currency: {
      type: DataTypes.STRING(3),
      defaultValue: 'EUR',
      validate: {
        isIn: [['EUR', 'USD']]
      }
    },
    category: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        isIn: [['Abbigliamento', 'Scarpe', 'Accessori', 'Borse']]
      }
    },
    brand: {
      type: DataTypes.STRING
    },
    size: {
      type: DataTypes.STRING,
      allowNull: false
    },
    condition: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        isIn: [['Nuovo con etichette', 'Come nuovo', 'Ottimo', 'Buono', 'Usato']]
      }
    },
    photos: {
      type: DataTypes.JSON,
      allowNull: false,
      defaultValue: []
    },
    status: {
      type: DataTypes.STRING,
      defaultValue: 'active',
      validate: {
        isIn: [['active', 'sold', 'archived', 'removed']]
      }
    },
    views: {
      type: DataTypes.INTEGER,
      defaultValue: 0
    },
    shippingCost: {
      type: DataTypes.INTEGER, // In centesimi, come il prezzo
      allowNull: false,
      defaultValue: 0,
      validate: {
        min: 0
      }
    },
    attributes: {
      type: DataTypes.JSON,
      defaultValue: {}
    },
    sellerId: {
      type: DataTypes.INTEGER,
      allowNull: false
    }
  }, {
    sequelize,
    modelName: 'Listing',
    timestamps: true,
    indexes: [
      { fields: ['sellerId', 'status'] },
      { fields: ['category'] },
      { fields: ['price'] }
    ]
  });

  return Listing;
};
