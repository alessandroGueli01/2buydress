const request = require('supertest');
const app = require('./backend/server'); // Correzione della sintassi e del percorso
const { sequelize } = require('./backend/config/database'); // Aggiunto import mancante
const { User } = require('./backend/models');

// Prima che tutti i test in questo file vengano eseguiti...
beforeAll(async () => {
  // Sincronizziamo il database, forzando il reset per avere un ambiente pulito.
  // NOTA: Questo cancellerà tutti i dati! Usare un DB di test separato in produzione.
  await sequelize.sync({ force: true });

  // Creiamo un utente di prova direttamente nel database.
  await User.create({
    name: 'Test User',
    email: 'test@example.com',
    password: 'password123' // L'hook del modello si occuperà dell'hashing
  });
});

// Raggruppiamo i test relativi agli endpoint di autenticazione
describe('Auth API Endpoints (/api/auth)', () => {

  // --- Test per il Login ---
  it('POST /login -> should login a registered user and return a JWT token', async () => {
    const response = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'test@example.com',
        password: 'password123'
      });

    // Verifichiamo che la risposta sia corretta
    expect(response.statusCode).toEqual(200);
    expect(response.body).toHaveProperty('token'); // Deve contenere un token
    expect(response.body).toHaveProperty('user'); // Deve contenere i dati utente
    expect(response.body.user.email).toBe('test@example.com');
    expect(response.body.user.password).toBeUndefined(); // La password non deve mai essere restituita
  });

  // Test per il login con password errata
  it('POST /login -> should return 401 for wrong password', async () => {
    const response = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'test@example.com',
        password: 'wrongpassword'
      });

    expect(response.statusCode).toEqual(401);
    expect(response.body.message).toBe('Credenziali non valide.');
  });

  // Test per il login con utente non esistente
  it('POST /login -> should return 401 for non-existent user', async () => {
    const response = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'nouser@example.com',
        password: 'password123'
      });

    expect(response.statusCode).toEqual(401);
    expect(response.body.message).toBe('Credenziali non valide.');
  });

  // --- Test per la Registrazione ---
  it('POST /register -> should register a new user successfully', async () => {
    const response = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'New User',
        email: 'newuser@example.com',
        password: 'password123'
      });

    expect(response.statusCode).toEqual(201);
    expect(response.body).toHaveProperty('token');
    expect(response.body.user.email).toBe('newuser@example.com');
    
    // Verifica che l'utente sia stato effettivamente salvato nel DB
    const userInDb = await User.findOne({ where: { email: 'newuser@example.com' } });
    expect(userInDb).not.toBeNull();
  });

  it('POST /register -> should return 400 if email already exists', async () => {
    const response = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Another User',
        email: 'test@example.com', // Email già usata nel beforeAll
        password: 'password123'
      });

    expect(response.statusCode).toEqual(400);
    expect(response.body.message).toBe('Un utente con questa email esiste già.');
  });

  it('POST /register -> should return 400 for invalid data (short password)', async () => {
    const response = await request(app)
      .post('/api/auth/register')
      .send({
        name: 'Invalid User',
        email: 'invalid@example.com',
        password: '123' // Password troppo corta
      });

    expect(response.statusCode).toEqual(400);
    expect(response.body).toHaveProperty('errors');
    // Controlliamo che ci sia un errore specifico per il campo password
    const passwordError = response.body.errors.find(e => e.path === 'password');
    expect(passwordError).toBeDefined();
    expect(passwordError.msg).toBe('La password deve essere di almeno 6 caratteri');
  });

});

// Dopo che tutti i test sono stati eseguiti, chiudiamo le connessioni
afterAll(async () => {
  await sequelize.close(); // Chiude la connessione al database
});