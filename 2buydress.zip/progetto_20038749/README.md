# 2buydress

Marketplace universitario per compravendita di abbigliamento second-hand.

## Panoramica

Il progetto e' composto da:

- backend Node.js + Express + Sequelize
- database PostgreSQL
- frontend web (cartella public) servito da Express
- frontend React (cartella frontend) incluso nel repository per evoluzione SPA

Funzionalita' principali:

- autenticazione JWT
- pubblicazione e gestione annunci
- acquisto simulato e gestione ordini
- chat tra utenti
- recensioni e rating
- notifiche (messaggi, preferiti, vendite, recensioni)



### Runtime e server

- Node.js
- Express
- CORS
- express-rate-limit

### Database e ORM

- PostgreSQL
- Sequelize
- pg
- pg-hstore

### Sicurezza e auth

- jsonwebtoken
- bcryptjs
- express-validator
- dotenv

### Upload e comunicazioni

- multer
- nodemailer

### Utility

- uuid

### Dipendenze di sviluppo

- nodemon
- jest
- supertest

## Prerequisiti

- Node.js 20+
- npm 10+
- PostgreSQL 14+ in esecuzione locale

## Installazione



1. Installa le dipendenze:

```bash
npm install
```

2. Crea/aggiorna il file `.env` in root (esempio):

```env
DATABASE_URL="postgresql://<utente_postgres>:<password>@localhost:5432/2buydress"
PORT=3000
JWT_SECRET="inserisci-una-chiave-lunga-e-casuale"
```

3. Crea il database PostgreSQL (se non esiste):

```bash
createdb 2buydress
```

4. Popola il database con dati demo:

```bash
npm run seed
```

5. Avvia il server:

```bash
npm start
```

6. Apri l'app nel browser:

```text
http://localhost:3000
```

## Script npm

- `npm start`: avvio backend (`node backend/server.js`)
- `npm run dev`: avvio sviluppo con nodemon
- `npm run seed`: reset e seed database
- `npm run populate-images`: popolamento immagini aggiuntive
- `npm test`: test con Jest

## Struttura Principale

```text
backend/
  config/         configurazione database
  controllers/    controller applicativi
  middleware/     auth, upload, admin auth
  models/         modelli Sequelize e associazioni
  routes/         API REST
  scripts/        script seed e utility
  server.js       entry point backend

public/
  pages/          pagine HTML
  scripts/        logica frontend vanilla JS
  styles/         CSS

frontend/
  src/            frontend React (componenti e pagine)
```

## Note Importanti Per Il Progetto Universitario

- Prezzi salvati in centesimi nel DB.
- Upload immagini salvati in locale in `backend/uploads`.
- Notifiche generate su eventi principali (es. nuova recensione, vendita).
- I contatori profilo sono dinamici e basati su dati reali.

## Troubleshooting

### Errore autenticazione PostgreSQL (`28P01`)

- Verifica `DATABASE_URL` in `.env`.
- Controlla utente/password con:

```bash
psql "postgresql://<utente>:<password>@localhost:5432/postgres" -c "select current_user;"
```

### Porta 3000 occupata

- Cambia `PORT` in `.env`, poi riavvia.

### Reset completo dati demo

- Esegui di nuovo:

```bash
npm run seed
```

## Demo

Video demo: https://youtu.be/hEh9ad0FxKI

## utenti

admin
testuser@example.com
password123

