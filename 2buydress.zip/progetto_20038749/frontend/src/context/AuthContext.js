import React, { createContext, useState, useContext, useEffect } from 'react';

// 1. Creiamo il contesto
const AuthContext = createContext(null);

// 2. Creiamo il "Provider", un componente che fornirà i dati a tutta l'app
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // Controlla il localStorage all'avvio dell'app per vedere se l'utente è già loggato
  useEffect(() => {
    const storedToken = localStorage.getItem('authToken');
    const storedUser = localStorage.getItem('user');

    if (storedToken && storedUser) {
      setToken(storedToken);
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false); // Finito di caricare lo stato iniziale
  }, []);

  // Funzione per effettuare il login
  const login = (userData, userToken) => {
    localStorage.setItem('authToken', userToken);
    localStorage.setItem('user', JSON.stringify(userData));
    setUser(userData);
    setToken(userToken);
  };

  // Funzione per effettuare il logout
  const logout = () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
    setUser(null);
    setToken(null);
  };

  // I valori che vogliamo rendere disponibili a tutta l'app
  const value = {
    user,
    token,
    isAuthenticated: !!token, // Un booleano per sapere facilmente se l'utente è loggato
    isLoading,
    login,
    logout,
  };

  // Il Provider "avvolge" i componenti figli (la nostra app)
  // e fornisce loro i valori definiti sopra.
  // Non mostriamo nulla finché non abbiamo controllato il localStorage.
  return (
    <AuthContext.Provider value={value}>
      {!isLoading && children}
    </AuthContext.Provider>
  );
};

// 3. Creiamo un "Hook" personalizzato per usare facilmente il contesto
export const useAuth = () => {
  return useContext(AuthContext);
};