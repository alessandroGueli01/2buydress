import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const EditProfilePage = () => {
  const { user, token, login } = useAuth(); // Usiamo 'login' per aggiornare lo stato globale dell'utente
  const navigate = useNavigate();

  const [name, setName] = useState('');
  const [bio, setBio] = useState('');
  const [location, setLocation] = useState('');
  const [addressLine1, setAddressLine1] = useState('');
  const [city, setCity] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [country, setCountry] = useState('');
  const [avatarFile, setAvatarFile] = useState(null);
  const [previewAvatar, setPreviewAvatar] = useState(null);

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  // Pre-compila il form con i dati attuali dell'utente
  useEffect(() => {
    if (user) {
      setName(user.name || '');
      setBio(user.bio || '');
      setLocation(user.location || '');
      setAddressLine1(user.addressLine1 || '');
      setCity(user.city || '');
      setPostalCode(user.postalCode || '');
      setCountry(user.country || '');
      if (user.avatar) {
        const avatarUrl = user.avatar.startsWith('http') ? user.avatar : `http://localhost:5000${user.avatar}`;
        setPreviewAvatar(avatarUrl);
      }
    }
  }, [user]);

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setAvatarFile(file);
      setPreviewAvatar(URL.createObjectURL(file)); // Crea un'anteprima locale
    } else {
      setAvatarFile(null);
      setPreviewAvatar(user.avatar ? `http://localhost:5000${user.avatar}` : null);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setSuccessMessage(null);

    try {
      // 1. Aggiorna i dati testuali del profilo
      const profileResponse = await fetch('http://localhost:5000/api/users/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          name, bio, location, addressLine1, city, postalCode, country
        }),
      });

      const profileData = await profileResponse.json();
      if (!profileResponse.ok) {
        throw new Error(profileData.message || 'Errore nell\'aggiornamento del profilo.');
      }

      let updatedUser = profileData;

      // 2. Se è stato selezionato un nuovo avatar, caricalo
      if (avatarFile) {
        const formData = new FormData();
        formData.append('avatar', avatarFile);

        const avatarResponse = await fetch('http://localhost:5000/api/users/avatar', {
          method: 'PUT',
          headers: {
            'Authorization': `Bearer ${token}`,
          },
          body: formData,
        });

        const avatarData = await avatarResponse.json();
        if (!avatarResponse.ok) {
          throw new Error(avatarData.message || 'Errore nell\'aggiornamento dell\'avatar.');
        }
        updatedUser = avatarData; // L'API dell'avatar restituisce l'utente aggiornato
      }

      // Aggiorna lo stato globale dell'utente nel contesto
      login(updatedUser, token); // Passa l'utente aggiornato e il token esistente
      setSuccessMessage('Profilo aggiornato con successo!');
      navigate('/profile'); // Reindirizza alla pagina del profilo

    } catch (err) {
      setError(err.message);
      console.error('Errore durante l\'aggiornamento del profilo:', err);
    } finally {
      setIsLoading(false);
    }
  };

  if (!user) {
    return <div>Per favore, effettua il login per modificare il tuo profilo.</div>;
  }

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '2rem' }}>
      <h2>Modifica Profilo</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {successMessage && <p style={{ color: 'green' }}>{successMessage}</p>}

      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '1rem' }}>
          <label htmlFor="avatar">Avatar:</label>
          <input type="file" id="avatar" accept="image/*" onChange={handleAvatarChange} />
          {previewAvatar && (
            <img src={previewAvatar} alt="Anteprima Avatar" style={{ width: '100px', height: '100px', borderRadius: '50%', objectFit: 'cover', marginTop: '0.5rem' }} />
          )}
        </div>

        <div style={{ marginBottom: '1rem' }}>
          <label htmlFor="name">Nome:</label>
          <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label htmlFor="bio">Bio:</label>
          <textarea id="bio" value={bio} onChange={(e) => setBio(e.target.value)} rows="4"></textarea>
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label htmlFor="location">Località:</label>
          <input type="text" id="location" value={location} onChange={(e) => setLocation(e.target.value)} />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label htmlFor="addressLine1">Indirizzo:</label>
          <input type="text" id="addressLine1" value={addressLine1} onChange={(e) => setAddressLine1(e.target.value)} />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label htmlFor="city">Città:</label>
          <input type="text" id="city" value={city} onChange={(e) => setCity(e.target.value)} />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label htmlFor="postalCode">CAP:</label>
          <input type="text" id="postalCode" value={postalCode} onChange={(e) => setPostalCode(e.target.value)} />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label htmlFor="country">Paese:</label>
          <input type="text" id="country" value={country} onChange={(e) => setCountry(e.target.value)} />
        </div>

        <button type="submit" disabled={isLoading}>
          {isLoading ? 'Salvataggio...' : 'Salva Modifiche'}
        </button>
      </form>
    </div>
  );
};

export default EditProfilePage;