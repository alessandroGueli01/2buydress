import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const CheckoutPage = () => {
  const { listingId } = useParams();
  const navigate = useNavigate();
  const { token } = useAuth();

  const [listing, setListing] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Stato per il form della carta fittizia
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    const fetchListing = async () => {
      try {
        const response = await fetch(`http://localhost:5000/api/listings/${listingId}`);
        if (!response.ok) {
          throw new Error('Annuncio non trovato.');
        }
        const data = await response.json();
        setListing(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchListing();
  }, [listingId]);

  const handlePayment = async (e) => {
    e.preventDefault();
    setIsProcessing(true);
    setError(null);

    try {
      const response = await fetch('http://localhost:5000/api/payments/simulate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          listingId: listing.id,
          cardNumber,
          cardExpiry,
          cardCvv,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || 'Pagamento fallito.');
      }

      alert('Acquisto completato con successo!');
      navigate(`/profile`); // Reindirizza al profilo dove l'utente vedrà i suoi ordini

    } catch (err) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  if (isLoading) return <div>Caricamento checkout...</div>;
  if (error) return <div style={{ color: 'red' }}>Errore: {error}</div>;
  if (!listing) return <div>Annuncio non trovato.</div>;

  const formatPrice = (priceInCents) => (priceInCents / 100).toFixed(2);
  const totalAmount = listing.price + listing.shippingCost;
  const getImageUrl = (path) => path.startsWith('http') ? path : `http://localhost:5000${path}`;

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '2rem', display: 'flex', gap: '2rem' }}>
      {/* Riepilogo Ordine */}
      <div style={{ flex: 1 }}>
        <h3>Riepilogo Ordine</h3>
        <div style={{ display: 'flex', gap: '1rem', borderBottom: '1px solid #eee', paddingBottom: '1rem' }}>
          <img 
            src={listing.photos.length > 0 ? getImageUrl(listing.photos[0]) : ''} 
            alt={listing.title} 
            style={{ width: '100px', height: '100px', objectFit: 'cover' }} 
          />
          <div>
            <h4>{listing.title}</h4>
            <p>Venditore: {listing.seller.name}</p>
          </div>
        </div>
        <div style={{ borderBottom: '1px solid #eee', padding: '1rem 0' }}>
          <p>Prezzo articolo: {formatPrice(listing.price)} €</p>
          <p>Costo spedizione: {formatPrice(listing.shippingCost)} €</p>
        </div>
        <h4 style={{ marginTop: '1rem' }}>Totale: {formatPrice(totalAmount)} €</h4>
      </div>

      {/* Form di Pagamento */}
      <div style={{ flex: 1 }}>
        <h3>Dati di Pagamento (Simulato)</h3>
        <form onSubmit={handlePayment}>
          <div style={{ marginBottom: '1rem' }}>
            <label>Numero Carta:</label>
            <input type="text" value={cardNumber} onChange={(e) => setCardNumber(e.target.value)} placeholder="1111222233334444" required />
          </div>
          <div style={{ marginBottom: '1rem' }}>
            <label>Scadenza (MM/AA):</label>
            <input type="text" value={cardExpiry} onChange={(e) => setCardExpiry(e.target.value)} placeholder="12/29" required />
          </div>
          <div style={{ marginBottom: '1rem' }}>
            <label>CVV:</label>
            <input type="text" value={cardCvv} onChange={(e) => setCardCvv(e.target.value)} placeholder="123" required />
          </div>
          {error && <p style={{ color: 'red' }}>{error}</p>}
          <button type="submit" disabled={isProcessing}>
            {isProcessing ? 'Pagamento in corso...' : `Paga ${formatPrice(totalAmount)} €`}
          </button>
        </form>
      </div>
    </div>
  );
};

export default CheckoutPage;