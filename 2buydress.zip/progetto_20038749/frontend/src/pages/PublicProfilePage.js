import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import ListingCard from '../components/ListingCard'; // Importa il componente centralizzato

const PublicProfilePage = () => {
  const { id } = useParams(); // Ottiene l'ID dell'utente dall'URL
  const [profileUser, setProfileUser] = useState(null);
  const [userListings, setUserListings] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProfileData = async () => {
      setIsLoading(true);
      setError(null);
      try {
        // Fetch in parallelo per ottimizzare i tempi
        const [profileResponse, listingsResponse] = await Promise.all([
          fetch(`http://localhost:5000/api/users/${id}`),
          fetch(`http://localhost:5000/api/users/${id}/listings?status=active`) // Prendiamo solo gli annunci attivi
        ]);

        if (!profileResponse.ok) {
          throw new Error('Utente non trovato.');
        }
        const profileData = await profileResponse.json();
        setProfileUser(profileData);

        if (listingsResponse.ok) {
          const listingsData = await listingsResponse.json();
          setUserListings(listingsData.listings);
        }

      } catch (err) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };

    fetchProfileData();
  }, [id]); // L'effetto si attiva ogni volta che l'ID nell'URL cambia

  if (isLoading) {
    return <div>Caricamento profilo...</div>;
  }

  if (error) {
    return <div style={{ color: 'red' }}>Errore: {error}</div>;
  }

  if (!profileUser) {
    return <div>Utente non trovato.</div>;
  }

  const getImageUrl = (path) => path.startsWith('http') ? path : `http://localhost:5000${path}`;
  const avatarUrl = profileUser.avatar
    ? getImageUrl(profileUser.avatar)
    : 'https://via.placeholder.com/150.png?text=Avatar';

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', padding: '2rem' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '2rem', marginBottom: '2rem' }}>
        <img src={avatarUrl} alt={profileUser.name} style={{ width: '150px', height: '150px', borderRadius: '50%', objectFit: 'cover' }} />
        <div>
          <h2>{profileUser.name}</h2>
          <p>Bio: {profileUser.bio || 'Nessuna biografia impostata.'}</p>
          <p>Rating: {profileUser.rating.toFixed(1)} ({profileUser.reviewCount} recensioni)</p>
        </div>
      </div>

      <h3>Annunci di {profileUser.name}</h3>
      <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        {userListings.length > 0 ? userListings.map(listing => <ListingCard key={listing.id} listing={listing} />) : <p>Questo utente non ha annunci attivi.</p>}
      </div>
    </div>
  );
};

export default PublicProfilePage;