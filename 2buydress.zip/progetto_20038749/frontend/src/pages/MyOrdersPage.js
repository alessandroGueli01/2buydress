import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router-dom';

const OrderCard = ({ order, type }) => {
  const { listing, buyer, seller } = order;
  const otherParty = type === 'purchase' ? seller : buyer;

  const getImageUrl = (path) => path.startsWith('http') ? path : `http://localhost:5000${path}`;
  const imageUrl = listing.photos && listing.photos.length > 0
    ? getImageUrl(listing.photos[0])
    : 'https://via.placeholder.com/100x100.png?text=No+Image';

  const formatPrice = (priceInCents) => (priceInCents / 100).toFixed(2);

  return (
    <div style={{ border: '1px solid #eee', padding: '1rem', margin: '1rem 0', display: 'flex', gap: '1rem' }}>
      <img src={imageUrl} alt={listing.title} style={{ width: '100px', height: '100px', objectFit: 'cover' }} />
      <div>
        <h4><Link to={`/listings/${listing.id}`}>{listing.title}</Link></h4>
        <p>
          {type === 'purchase' ? `Venduto da: ` : `Acquistato da: `}
          <Link to={`/users/${otherParty.id}`}>{otherParty.name}</Link>
        </p>
        <p>Data ordine: {new Date(order.createdAt).toLocaleDateString('it-IT')}</p>
        <p>Importo totale: <strong>{formatPrice(order.amount)} €</strong></p>
      </div>
    </div>
  );
};

const MyOrdersPage = () => {
  const { token } = useAuth();
  const [purchases, setPurchases] = useState([]);
  const [sales, setSales] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/users/me/orders', {
          headers: { 'Authorization': `Bearer ${token}` },
        });
        if (!response.ok) {
          throw new Error('Errore nel caricamento degli ordini.');
        }
        const data = await response.json();
        setPurchases(data.purchases);
        setSales(data.sales);
      } catch (err) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };

    fetchOrders();
  }, [token]);

  if (isLoading) {
    return <div>Caricamento ordini...</div>;
  }

  if (error) {
    return <div style={{ color: 'red' }}>Errore: {error}</div>;
  }

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', padding: '2rem' }}>
      <h2>I Miei Ordini</h2>

      <div style={{ marginBottom: '3rem' }}>
        <h3>I Miei Acquisti</h3>
        {purchases.length > 0 ? (
          purchases.map(order => <OrderCard key={order.id} order={order} type="purchase" />)
        ) : (
          <p>Non hai ancora effettuato nessun acquisto.</p>
        )}
      </div>

      <div>
        <h3>Le Mie Vendite</h3>
        {sales.length > 0 ? (
          sales.map(order => <OrderCard key={order.id} order={order} type="sale" />)
        ) : (
          <p>Non hai ancora venduto nessun articolo.</p>
        )}
      </div>
    </div>
  );
};

export default MyOrdersPage;