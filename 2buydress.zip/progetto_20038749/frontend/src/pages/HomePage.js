import React, { useState, useEffect, useCallback } from "react";
import { Link, useSearchParams } from "react-router-dom";
import ListingCard from "../components/ListingCard"; // Importa il componente centralizzato

const HomePage = () => {
  const [listings, setListings] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Gestisce i parametri di ricerca nell'URL (es. ?q=vestito&page=2)
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchTerm, setSearchTerm] = useState(searchParams.get('q') || '');
  // Stato per i nuovi filtri
  const [category, setCategory] = useState(searchParams.get('category') || '');
  const [condition, setCondition] = useState(searchParams.get('condition') || '');
  const [brand, setBrand] = useState(searchParams.get('brand') || '');
  const [minPrice, setMinPrice] = useState(searchParams.get('minPrice') ? searchParams.get('minPrice') / 100 : '');
  const [maxPrice, setMaxPrice] = useState(searchParams.get('maxPrice') ? searchParams.get('maxPrice') / 100 : '');
  const [sort, setSort] = useState(searchParams.get('sort') || '');


  const fetchListings = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      // Costruisce la query string basandosi sui parametri dell'URL
      const query = new URLSearchParams(searchParams).toString();
      
      // 1. Chiama l'API per ottenere gli annunci, includendo i filtri
      const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';
      const response = await fetch(`${apiUrl}/listings?${query}`);
      if (!response.ok) {
        throw new Error('Errore nel caricamento degli annunci.');
      }
      const data = await response.json();
      
      // 2. Salva gli annunci e i dati di paginazione nello stato
      setListings(data.listings);
      setPagination(data.pagination);

    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [searchParams]); // La funzione viene ricreata solo se i parametri di ricerca cambiano

  useEffect(() => {
    fetchListings();
  }, [fetchListings]); // L'effetto si attiva quando la funzione fetchListings cambia

  // Sincronizza lo stato locale con i parametri dell'URL (importante per reset e navigazione)
  useEffect(() => {
    setSearchTerm(searchParams.get('q') || '');
    setCategory(searchParams.get('category') || '');
    setCondition(searchParams.get('condition') || '');
    setBrand(searchParams.get('brand') || '');
    setMinPrice(searchParams.get('minPrice') ? searchParams.get('minPrice') / 100 : '');
    setMaxPrice(searchParams.get('maxPrice') ? searchParams.get('maxPrice') / 100 : '');
    setSort(searchParams.get('sort') || '');
  }, [searchParams]);

  const handleSearch = (e) => {
    e.preventDefault();
    setSearchParams(prev => {
      // Imposta o rimuove i parametri in base al valore
      if (searchTerm) prev.set('q', searchTerm); else prev.delete('q');
      if (category) prev.set('category', category); else prev.delete('category');
      if (condition) prev.set('condition', condition); else prev.delete('condition');
      if (brand) prev.set('brand', brand); else prev.delete('brand');
      if (sort) prev.set('sort', sort); else prev.delete('sort');
      // Convertiamo i prezzi in centesimi per l'API
      if (minPrice) prev.set('minPrice', Math.round(parseFloat(minPrice) * 100)); else prev.delete('minPrice');
      if (maxPrice) prev.set('maxPrice', Math.round(parseFloat(maxPrice) * 100)); else prev.delete('maxPrice');

      prev.set('page', '1'); // Resetta alla prima pagina quando si fa una nuova ricerca
      return prev;
    });
  };

  const handleResetFilters = () => {
    setSearchTerm('');
    setCategory('');
    setCondition('');
    setBrand('');
    setMinPrice('');
    setMaxPrice('');
    setSort('');
    setSearchParams({}); // Rimuove tutti i parametri dall'URL
  };

  const handlePageChange = (newPage) => {
    setSearchParams(prev => {
      prev.set('page', newPage.toString());
      return prev;
    });
  };

  // 3. Gestione dei vari stati dell'interfaccia
  if (isLoading) {
    return <div>Caricamento annunci...</div>;
  }

  if (error) {
    return <div style={{ color: 'red' }}>Errore: {error}</div>;
  }

  return (
    <div>
      <h2>Cerca nel nostro catalogo</h2>
      <form onSubmit={handleSearch} style={{ marginBottom: '2rem', border: '1px solid #ddd', padding: '1rem', borderRadius: '8px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem' }}>
          <input
            type="text"
            placeholder="Cosa stai cercando?"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{ padding: '0.5rem' }}
          />
          <select value={category} onChange={(e) => setCategory(e.target.value)} style={{ padding: '0.5rem' }}>
            <option value="">Tutte le categorie</option>
            <option value="Abbigliamento">Abbigliamento</option>
            <option value="Scarpe">Scarpe</option>
            <option value="Accessori">Accessori</option>
            <option value="Borse">Borse</option>
          </select>
          <select value={condition} onChange={(e) => setCondition(e.target.value)} style={{ padding: '0.5rem' }}>
            <option value="">Qualsiasi condizione</option>
            <option value="Nuovo con etichette">Nuovo con etichette</option>
            <option value="Come nuovo">Come nuovo</option>
            <option value="Ottimo">Ottimo</option>
            <option value="Buono">Buono</option>
            <option value="Usato">Usato</option>
          </select>
          <input
            type="text"
            placeholder="Brand (es. Nike)"
            value={brand}
            onChange={(e) => setBrand(e.target.value)}
            style={{ padding: '0.5rem' }}
          />
          <select value={sort} onChange={(e) => setSort(e.target.value)} style={{ padding: '0.5rem' }}>
            <option value="">Ordina per...</option>
            <option value="price_asc">Prezzo: dal più basso</option>
            <option value="price_desc">Prezzo: dal più alto</option>
            <option value="newest">I più recenti</option>
            <option value="oldest">I meno recenti</option>
          </select>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginTop: '1rem' }}>
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <input
              type="number"
              placeholder="Prezzo min (€)"
              value={minPrice}
              onChange={(e) => setMinPrice(e.target.value)}
              style={{ width: '100%', padding: '0.5rem' }}
            />
            <input
              type="number"
              placeholder="Prezzo max (€)"
              value={maxPrice}
              onChange={(e) => setMaxPrice(e.target.value)}
              style={{ width: '100%', padding: '0.5rem' }}
            />
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '1rem' }}>
            <button type="button" onClick={handleResetFilters} style={{ padding: '0.5rem 1rem' }}>Resetta</button>
            <button type="submit" style={{ padding: '0.5rem 1rem', backgroundColor: '#007bff', color: 'white', border: 'none', borderRadius: '4px' }}>Cerca</button>
          </div>
        </div>
      </form>

      <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        {listings.length > 0 ? (
          listings.map(listing => (
            <ListingCard key={listing.id} listing={listing} />
          ))
        ) : (
          <p>Nessun annuncio trovato.</p>
        )}
      </div>

      {pagination && pagination.totalPages > 1 && (
        <div style={{ marginTop: '2rem', textAlign: 'center' }}>
          <button
            onClick={() => handlePageChange(pagination.currentPage - 1)}
            disabled={pagination.currentPage === 1}
          >
            Precedente
          </button>
          <span style={{ margin: '0 1rem' }}>Pagina {pagination.currentPage} di {pagination.totalPages}</span>
          <button
            onClick={() => handlePageChange(pagination.currentPage + 1)}
            disabled={pagination.currentPage === pagination.totalPages}
          >
            Successiva
          </button>
        </div>
      )}
    </div>
  );
};

export default HomePage;