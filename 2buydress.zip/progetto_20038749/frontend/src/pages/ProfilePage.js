import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router-dom';

// Un componente semplice per mostrare un annuncio nella lista del profilo
const UserListingCard = ({ listing }) => {
  const getImageUrl = (path) => path.startsWith('http') ? path : `http://localhost:5000${path}`;
  const imageUrl = listing.photos && listing.photos.length > 0
    ? getImageUrl(listing.photos[0])
    : 'https://via.placeholder.com/150x100.png?text=No+Image';

  return (
    <div style={{ border: '1px solid #eee', padding: '1rem', margin: '0.5rem', display: 'flex', alignItems: 'center', gap: '1rem' }}>
      <img src={imageUrl} alt={listing.title} style={{ width: '100px', height: '100px', objectFit: 'cover' }} />
      <div>
        <h4>{listing.title}</h4>
        <p>Stato: {listing.status}</p>
        <Link to={`/listings/${listing.id}`}>Vedi</Link> | <Link to={`/listings/edit/${listing.id}`}>Modifica</Link>
      </div>
    </div>
  );
};

const ProfilePage = () => {
  const { user, token } = useAuth();
  const [userListings, setUserListings] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Se non c'è un utente loggato, non fare nulla
    if (!user) {
      setIsLoading(false);
      return;
    }

    const fetchUserListings = async () => {
      try {
        // 1. Chiama l'API per ottenere gli annunci dell'utente
        const response = await fetch(`http://localhost:5000/api/users/${user.id}/listings`);
        if (!response.ok) {
          throw new Error('Errore nel caricamento dei tuoi annunci.');
        }
        const data = await response.json();
        setUserListings(data.listings);
      } catch (err) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };

    fetchUserListings();
  }, [user]); // L'effetto si attiva quando l'oggetto 'user' è disponibile

  if (isLoading) {
    return <div>Caricamento profilo...</div>;
  }

  if (!user) {
    return <div>Per favore, effettua il login per vedere il tuo profilo.</div>;
  }

  const getImageUrl = (path) => path.startsWith('http') ? path : `http://localhost:5000${path}`;
  const avatarUrl = user.avatar
    ? getImageUrl(user.avatar)
    : 'https://via.placeholder.com/150.png?text=Avatar';

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', padding: '2rem' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '2rem', marginBottom: '2rem' }}>
        <img src={avatarUrl} alt={user.name} style={{ width: '150px', height: '150px', borderRadius: '50%', objectFit: 'cover' }} />
        <div>
          <h2>{user.name}</h2>
          <p>{user.email}</p>
          <p>Bio: {user.bio || 'Nessuna biografia impostata.'}</p>
          <Link to="/edit-profile">Modifica Profilo</Link> | 
          <Link to="/my-orders" style={{ marginLeft: '0.5rem' }}>I Miei Ordini</Link> |
          <Link to="/favorites" style={{ marginLeft: '0.5rem' }}>Preferiti</Link>
        </div>
      </div>

      <h3>I tuoi annunci</h3>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {userListings.length > 0 ? (
        userListings.map(listing => <UserListingCard key={listing.id} listing={listing} />)
      ) : (
        <p>Non hai ancora pubblicato nessun annuncio. <Link to="/listings/new">Creane uno ora!</Link></p>
      )}
    </div>
  );
};

export default ProfilePage;