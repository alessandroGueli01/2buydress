import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const EditListingPage = () => {
  const { id } = useParams();
  const { token } = useAuth();
  const navigate = useNavigate();

  // State per i campi del form
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    price: '',
    category: 'Abbigliamento',
    brand: '',
    size: '',
    condition: 'Come nuovo',
    shippingCost: '',
  });

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState(null);

  // Carica i dati dell'annuncio esistente
  useEffect(() => {
    const fetchListing = async () => {
      try {
        const response = await fetch(`http://localhost:5000/api/listings/${id}`);
        if (!response.ok) {
          throw new Error('Annuncio non trovato o errore del server.');
        }
        const data = await response.json();
        // Popola il form con i dati esistenti
        setFormData({
          title: data.title,
          description: data.description,
          price: (data.price / 100).toFixed(2), // Converte da centesimi a euro
          category: data.category,
          brand: data.brand || '',
          size: data.size,
          condition: data.condition,
          shippingCost: (data.shippingCost / 100).toFixed(2),
        });
      } catch (err) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchListing();
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    setError(null);

    try {
      const dataToSubmit = {
        ...formData,
        price: Math.round(parseFloat(formData.price) * 100),
        shippingCost: Math.round(parseFloat(formData.shippingCost) * 100),
      };

      const response = await fetch(`http://localhost:5000/api/listings/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(dataToSubmit),
      });

      const responseData = await response.json();
      if (!response.ok) {
        throw new Error(responseData.message || 'Errore durante l\'aggiornamento dell\'annuncio.');
      }

      alert('Annuncio modificato con successo!');
      navigate(`/listings/${id}`);

    } catch (err) {
      setError(err.message);
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) return <div>Caricamento annuncio...</div>;
  if (error) return <div style={{ color: 'red' }}>Errore: {error}</div>;

  return (
    <div style={{ maxWidth: '700px', margin: '0 auto', padding: '2rem' }}>
      <h2>Modifica Annuncio</h2>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '1rem' }}>
          <label>Titolo:</label>
          <input type="text" name="title" value={formData.title} onChange={handleChange} required />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label>Descrizione:</label>
          <textarea name="description" value={formData.description} onChange={handleChange} required rows="5"></textarea>
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label>Prezzo (€):</label>
          <input type="number" name="price" value={formData.price} onChange={handleChange} required step="0.01" min="0" />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label>Costo Spedizione (€):</label>
          <input type="number" name="shippingCost" value={formData.shippingCost} onChange={handleChange} required step="0.01" min="0" />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label>Categoria:</label>
          <select name="category" value={formData.category} onChange={handleChange}>
            <option value="Abbigliamento">Abbigliamento</option>
            <option value="Scarpe">Scarpe</option>
            <option value="Accessori">Accessori</option>
            <option value="Borse">Borse</option>
          </select>
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label>Brand:</label>
          <input type="text" name="brand" value={formData.brand} onChange={handleChange} />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label>Taglia:</label>
          <input type="text" name="size" value={formData.size} onChange={handleChange} required />
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label>Condizione:</label>
          <select name="condition" value={formData.condition} onChange={handleChange}>
            <option value="Nuovo con etichette">Nuovo con etichette</option>
            <option value="Come nuovo">Come nuovo</option>
            <option value="Ottimo">Ottimo</option>
            <option value="Buono">Buono</option>
            <option value="Usato">Usato</option>
          </select>
        </div>
        <p><i>Per modificare le foto, si consiglia di creare un nuovo annuncio.</i></p>
        <button type="submit" disabled={isSaving}>
          {isSaving ? 'Salvataggio...' : 'Salva Modifiche'}
        </button>
      </form>
    </div>
  );
};

export default EditListingPage;