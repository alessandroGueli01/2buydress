import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router-dom';
import ListingCard from '../components/ListingCard'; // Importa il componente centralizzato

const FavoritesPage = () => {
  const { token } = useAuth();
  const [favorites, setFavorites] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchFavorites = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/users/me/favorites', {
          headers: { 'Authorization': `Bearer ${token}` },
        });
        if (!response.ok) {
          throw new Error('Errore nel caricamento dei preferiti.');
        }
        const data = await response.json();
        setFavorites(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };

    fetchFavorites();
  }, [token]);

  if (isLoading) return <div>Caricamento preferiti...</div>;
  if (error) return <div style={{ color: 'red' }}>Errore: {error}</div>;

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '2rem' }}>
      <h2>I Tuoi Preferiti</h2>
      <div style={{ display: 'flex', flexWrap: 'wrap' }}>
        {favorites.length > 0 ? (
          favorites.map(listing => <ListingCard key={listing.id} listing={listing} />)
        ) : (
          <p>Non hai ancora aggiunto nessun annuncio ai preferiti.</p>
        )}
      </div>
    </div>
  );
};

export default FavoritesPage;