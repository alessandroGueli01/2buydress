import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const ListingDetailPage = () => {
  const { id } = useParams(); // Ottiene l'ID dell'annuncio dall'URL
  const navigate = useNavigate();
  const location = useLocation();
  const { isAuthenticated, user, token } = useAuth();

  const [listing, setListing] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isFavorited, setIsFavorited] = useState(false); // Stato per il pulsante preferiti

  useEffect(() => {
    const fetchListingAndFavorites = async () => {
      try {
        // Fetch listing details
        const listingResponse = await fetch(`http://localhost:5000/api/listings/${id}`);
        if (!listingResponse.ok) {
          throw new Error('Annuncio non trovato o errore del server.');
        }
        const listingData = await listingResponse.json();
        setListing(listingData);

        // If authenticated, fetch user's favorites to determine initial isFavorited state
        if (isAuthenticated && user && token) {
          const favoritesResponse = await fetch('http://localhost:5000/api/users/me/favorites', {
            headers: {
              'Authorization': `Bearer ${token}`,
            },
          });
          if (favoritesResponse.ok) {
            const favoritesData = await favoritesResponse.json();
            const isCurrentlyFavorited = favoritesData.some(favListing => favListing.id === listingData.id);
            setIsFavorited(isCurrentlyFavorited);
          } else {
            console.warn('Impossibile caricare i preferiti dell\'utente.');
          }
        }

      } catch (err) {
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };

    fetchListingAndFavorites();
  }, [id, isAuthenticated, user, token]); // Dipendenze per rifetchare se l'ID cambia o lo stato auth cambia

  const handleFavoriteToggle = async () => {
    if (!isAuthenticated) {
      navigate('/login', { state: { from: location } });
      return;
    }

    try {
      const method = isFavorited ? 'DELETE' : 'POST';
      const response = await fetch(`http://localhost:5000/api/listings/${id}/favorite`, {
        method: method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Errore durante l\'operazione sui preferiti.');
      }

      setIsFavorited(!isFavorited);
      alert(isFavorited ? 'Annuncio rimosso dai preferiti.' : 'Annuncio aggiunto ai preferiti!');

    } catch (err) {
      console.error("Errore preferiti:", err);
      alert(`Errore: ${err.message}`);
    }
  };

  const handleContactSeller = async () => {
    if (!isAuthenticated) {
      navigate('/login', { state: { from: location } });
      return;
    }

    if (!listing || !listing.seller) return;

    try {
      // Chiama l'API per creare o trovare la conversazione
      const response = await fetch('http://localhost:5000/api/chat/conversations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          listingId: listing.id,
          otherUserId: listing.seller.id,
        }),
      });

      const conversation = await response.json();
      if (!response.ok) {
        throw new Error(conversation.message || 'Impossibile avviare la chat.');
      }

      // Reindirizza l'utente alla pagina della chat con l'ID della conversazione
      navigate(`/chat/${conversation.id}`);
    } catch (err) {
      console.error('Errore nell\'avvio della chat:', err);
      alert(`Errore: ${err.message}`);
    }
  };

  const handleBuyNow = () => {
    if (!isAuthenticated) {
      navigate('/login', { state: { from: location } });
      return;
    }
    // Logica per procedere all'acquisto simulato
    navigate(`/checkout/${listing.id}`); // Reindirizza alla pagina di checkout
  };

  if (isLoading) {
    return <div>Caricamento annuncio...</div>;
  }

  if (error) {
    return <div style={{ color: 'red' }}>Errore: {error}</div>;
  }

  if (!listing) {
    return <div>Annuncio non trovato.</div>;
  }

  // Helper per formattare il prezzo
  const formatPrice = (priceInCents) => (priceInCents / 100).toFixed(2);

  // Helper per gestire URL immagini (locali vs esterne)
  const getImageUrl = (path) => path.startsWith('http') ? path : `http://localhost:5000${path}`;

  return (
    <div style={{ padding: '2rem', maxWidth: '900px', margin: '0 auto' }}>
      <h2>{listing.title}</h2>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', marginBottom: '1rem' }}>
        {listing.photos && listing.photos.map((photo, index) => (
          <img
            key={index}
            src={getImageUrl(photo)}
            alt={`${listing.title} - ${index + 1}`}
            style={{ width: '200px', height: '200px', objectFit: 'cover', borderRadius: '8px' }}
          />
        ))}
      </div>

      <p><strong>Descrizione:</strong> {listing.description}</p>
      <p><strong>Prezzo:</strong> {formatPrice(listing.price)} €</p>
      <p><strong>Costo Spedizione:</strong> {formatPrice(listing.shippingCost)} €</p>
      <p><strong>Categoria:</strong> {listing.category}</p>
      <p><strong>Brand:</strong> {listing.brand || 'N/A'}</p>
      <p><strong>Taglia:</strong> {listing.size}</p>
      <p><strong>Condizione:</strong> {listing.condition}</p>
      <p><strong>Visualizzazioni:</strong> {listing.views}</p>

      <div style={{ borderTop: '1px solid #eee', paddingTop: '1rem', marginTop: '1rem' }}>
        <h3>Informazioni Venditore</h3>
        {listing.seller ? (
          <>
            <p><strong>Nome:</strong> {listing.seller.name}</p>
            {listing.seller.avatar && (
              <img
                src={getImageUrl(listing.seller.avatar)}
                alt={listing.seller.name}
                style={{ width: '50px', height: '50px', borderRadius: '50%', objectFit: 'cover', marginRight: '0.5rem' }}
              />
            )}
            <p><strong>Rating:</strong> {listing.seller.rating.toFixed(1)} ({listing.seller.reviewCount} recensioni)</p>
            <p><strong>Bio:</strong> {listing.seller.bio || 'Nessuna bio disponibile.'}</p>
            <p><strong>Località:</strong> {listing.seller.location || 'N/A'}</p>
            <Link to={`/users/${listing.seller.id}`}>Vedi Profilo Venditore</Link>
          </>
        ) : (
          <p>Venditore non disponibile.</p>
        )}
      </div>

      <div style={{ marginTop: '2rem', display: 'flex', gap: '1rem' }}>
        <button onClick={handleFavoriteToggle}>
          {isFavorited ? '❤️ Rimuovi dai Preferiti' : '🤍 Aggiungi ai Preferiti'}
        </button>
        {isAuthenticated && user && listing.sellerId !== user.id && ( // Non puoi contattare/comprare il tuo annuncio
          <>
            <button onClick={handleContactSeller}>Contatta Venditore</button>
            <button onClick={handleBuyNow}>Compra Ora</button>
          </>
        )}
      </div>
    </div>
  );
};

export default ListingDetailPage;