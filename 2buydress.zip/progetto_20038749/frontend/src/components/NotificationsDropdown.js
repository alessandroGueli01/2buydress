import React from 'react';
import { Link } from 'react-router-dom';

const NotificationItem = ({ notification, onNotificationClick }) => {
  const getLink = () => {
    switch (notification.type) {
      case 'new_message':
        return `/chat/${notification.content.conversationId}`;
      case 'item_sold':
      case 'new_favorite':
        return `/listings/${notification.listingId}`;
      case 'new_review':
        return '/profile';
      default:
        return '#';
    }
  };

  return (
    <Link to={getLink()} onClick={() => onNotificationClick(notification.id)} style={{ textDecoration: 'none', color: 'inherit' }}>
      <div style={{
        padding: '0.75rem 1rem',
        borderBottom: '1px solid #eee',
        backgroundColor: notification.isRead ? 'white' : '#f0f8ff',
      }}>
        <p style={{ margin: 0 }}>{notification.content.message}</p>
        <small style={{ color: '#666' }}>
          {new Date(notification.createdAt).toLocaleString('it-IT')}
        </small>
      </div>
    </Link>
  );
};

const NotificationsDropdown = ({ notifications, onNotificationClick, onReadAll }) => {
  if (!notifications || notifications.length === 0) {
    return (
      <div style={{ padding: '1rem', textAlign: 'center' }}>
        Nessuna notifica.
      </div>
    );
  }

  return (
    <div style={{
      position: 'absolute',
      top: '100%',
      right: 0,
      width: '350px',
      maxHeight: '400px',
      overflowY: 'auto',
      backgroundColor: 'white',
      border: '1px solid #ccc',
      borderRadius: '8px',
      boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
      zIndex: 1000,
    }}>
      {notifications.map(notif => (
        <NotificationItem key={notif.id} notification={notif} onNotificationClick={onNotificationClick} />
      ))}
      <div style={{ padding: '0.5rem', textAlign: 'center', borderTop: '1px solid #eee' }}>
        <button onClick={onReadAll}>Segna tutte come lette</button>
      </div>
    </div>
  );
};

export default NotificationsDropdown;