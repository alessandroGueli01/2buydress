import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  // Se stiamo ancora caricando lo stato di autenticazione iniziale,
  // mostriamo un messaggio di caricamento per evitare sfarfallii.
  if (isLoading) {
    return <div>Caricamento...</div>;
  }

  // Se l'utente NON è autenticato, lo reindirizziamo alla pagina di login.
  // Salviamo anche la pagina che stava cercando di visitare (`location`)
  // per poterlo reindirizzare lì dopo il login.
  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Se l'utente è autenticato, mostriamo la pagina richiesta.
  return children;
};

export default ProtectedRoute;