import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import NotificationsDropdown from './NotificationsDropdown';
import './components.css'; // Importa il file CSS

const Navbar = () => {
  const { isAuthenticated, user, token, logout } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const fetchNotifications = useCallback(async () => {
    if (!isAuthenticated) return;
    try {
      const response = await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/notifications`, {
        headers: { 'Authorization': `Bearer ${token}` },
      });
      if (response.ok) {
        const data = await response.json();
        setNotifications(data);
        setUnreadCount(data.filter(n => !n.isRead).length);
      }
    } catch (error) {
      console.error("Errore nel caricamento delle notifiche:", error);
    }
  }, [isAuthenticated, token]);

  useEffect(() => {
    fetchNotifications();
    // Imposta un intervallo per aggiornare le notifiche ogni 30 secondi
    const interval = setInterval(fetchNotifications, 30000);
    return () => clearInterval(interval); // Pulisce l'intervallo quando il componente viene smontato
  }, [fetchNotifications]);

  const handleNotificationClick = async (notificationId) => {
    try {
      await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/notifications/${notificationId}/read`, {
        method: 'PATCH',
        headers: { 'Authorization': `Bearer ${token}` },
      });
      // Aggiorna lo stato locale per riflettere il cambiamento
      setNotifications(prev => prev.map(n => n.id === notificationId ? { ...n, isRead: true } : n));
      setUnreadCount(prev => Math.max(0, prev - 1));
      setIsDropdownOpen(false); // Chiude il dropdown dopo il click
    } catch (error) {
      console.error("Errore nel segnare la notifica come letta:", error);
    }
  };

  const handleReadAll = async () => {
    try {
      await fetch(`${process.env.REACT_APP_BACKEND_URL}/api/notifications/read-all`, {
        method: 'PATCH',
        headers: { 'Authorization': `Bearer ${token}` },
      });
      setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
      setUnreadCount(0);
    } catch (error) {
      console.error("Errore nel segnare tutte le notifiche come lette:", error);
    }
  };

  return (
    <nav className="navbar">
      <div>
        <Link to="/" className="navbar-brand">
          2BuyDress
        </Link>
      </div>
      <div>
        {isAuthenticated ? (
          <>
            <span>Ciao, {user.name}!</span>
            <Link to="/profile" style={{ marginLeft: '1rem' }}>Profilo</Link>
            <Link to="/chat" style={{ marginLeft: '1rem' }}>Chat</Link>
            <div style={{ position: 'relative', display: 'inline-block', marginLeft: '1rem' }}>
              <button onClick={() => setIsDropdownOpen(!isDropdownOpen)}>
                🔔
                {unreadCount > 0 && (
                  <span style={{ position: 'absolute', top: '-5px', right: '-5px', background: 'red', color: 'white', borderRadius: '50%', padding: '2px 5px', fontSize: '0.7rem' }}>
                    {unreadCount}
                  </span>
                )}
              </button>
              {isDropdownOpen && (
                <NotificationsDropdown notifications={notifications} onNotificationClick={handleNotificationClick} onReadAll={handleReadAll} />
              )}
            </div>
            <button onClick={logout} style={{ marginLeft: '1rem' }}>Logout</button>
          </>
        ) : (
          <><Link to="/login" style={{ marginRight: '1rem' }}>Login</Link><Link to="/register">Registrati</Link></>
        )}
      </div>
    </nav>
  );
};

export default Navbar;