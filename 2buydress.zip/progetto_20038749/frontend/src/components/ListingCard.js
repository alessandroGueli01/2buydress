import React from 'react';
import { Link } from 'react-router-dom';
import './components.css'; // Importa il file CSS

const ListingCard = ({ listing }) => {
  // Helper per gestire URL immagini (locali vs esterne)
  const getImageUrl = (path) => {
    if (!path || typeof path !== 'string') return 'https://via.placeholder.com/300x200.png?text=Immagine+non+disponibile'; // Placeholder più robusto
    return path.startsWith('http') ? path : `${process.env.REACT_APP_BACKEND_URL || 'http://localhost:3000'}${path}`;
  };

  // Gestione robusta del campo photos (che può arrivare come stringa JSON da SQLite)
  let photosArray = [];
  try {
    if (Array.isArray(listing.photos)) {
      photosArray = listing.photos;
    } else if (typeof listing.photos === 'string') {
      photosArray = JSON.parse(listing.photos);
    }
  } catch (e) {
    console.error("Errore nel parsing delle foto:", e);
    photosArray = [];
  }

  const imageUrl = photosArray.length > 0
    ? getImageUrl(photosArray[0])
    : 'https://via.placeholder.com/300x200.png?text=Nessuna+Immagine';

  return (
    <div className="listing-card">
      <img src={imageUrl} alt={listing.title} style={{ width: '100%', height: '150px', objectFit: 'cover' }} />
      <h4>{listing.title}</h4>
      <p>Prezzo: {(listing.price / 100).toFixed(2)} €</p>
      {/* Assicuriamoci che il venditore sia sempre mostrato se disponibile */}
      {listing.seller && <p>Venditore: {listing.seller.name}</p>}
      <Link to={`/listings/${listing.id}`}>Vedi Dettagli</Link>
    </div>
  );
};

export default ListingCard;