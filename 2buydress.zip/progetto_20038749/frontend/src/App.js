import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Navbar from './components/Navbar';

// Importa tutte le pagine
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import RegistrationPage from './pages/RegistrationPage';
import ListingDetailPage from './pages/ListingDetailPage';
import ProfilePage from './pages/ProfilePage';
import EditProfilePage from './pages/EditProfilePage';
import CreateListingPage from './pages/CreateListingPage'; // Importa la pagina di creazione annuncio
import ChatPage from './pages/ChatPage'; // Importa la pagina della chat
import CheckoutPage from './pages/CheckoutPage'; // Importa la pagina di checkout
import MyOrdersPage from './pages/MyOrdersPage'; // Importa la pagina degli ordini
import FavoritesPage from './pages/FavoritesPage'; // Importa la pagina dei preferiti
import EditListingPage from './pages/EditListingPage'; // Importa la pagina di modifica annuncio
import PublicProfilePage from './pages/PublicProfilePage'; // Importa la pagina del profilo pubblico

function App() {
  return (
    <AuthProvider>
      <Router>
        <Navbar />
        <main style={{ padding: '1rem' }}>
          <Routes>
            {/* --- Rotte Pubbliche --- */}
            <Route path="/" element={<HomePage />} />
            <Route path="/listings/:id" element={<ListingDetailPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegistrationPage />} />
            {/* Rotta per il profilo pubblico di altri utenti */}
            <Route path="/users/:id" element={<PublicProfilePage />} />

            {/* --- Rotte Protette --- */}
            <Route
              path="/profile"
              element={
                <ProtectedRoute>
                  <ProfilePage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/edit-profile"
              element={
                <ProtectedRoute>
                  <EditProfilePage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/listings/new" // Nuova rotta per creare un annuncio
              element={
                <ProtectedRoute>
                  <CreateListingPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/chat"
              element={
                <ProtectedRoute>
                  <ChatPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/chat/:conversationId" // Rotta per aprire una conversazione specifica
              element={
                <ProtectedRoute>
                  <ChatPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/checkout/:listingId" // Rotta per il checkout
              element={
                <ProtectedRoute>
                  <CheckoutPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/listings/edit/:id" // Rotta per modificare un annuncio
              element={
                <ProtectedRoute>
                  <EditListingPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/my-orders" // Rotta per gli ordini
              element={
                <ProtectedRoute>
                  <MyOrdersPage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/favorites" // Rotta per i preferiti
              element={
                <ProtectedRoute>
                  <FavoritesPage />
                </ProtectedRoute>
              }
            />

          </Routes>
        </main>
      </Router>
    </AuthProvider>
  );
}

export default App;