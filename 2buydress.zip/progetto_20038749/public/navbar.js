function setupAuthUI(navbarRoot, isUserLoggedIn) {
  const authContainer = navbarRoot.querySelector('#authContainer');
  const chatLinkContainer = navbarRoot.querySelector('#chatLinkContainer');
  const sellBtnContainer = navbarRoot.querySelector('#sellBtnContainer');

  if (isUserLoggedIn) {
    authContainer.innerHTML = `
      <a class="btn btn-outline-primary btn-sm ms-2" href="/pages/profile.html">
        <i class="bi bi-person-circle"></i> Profilo
      </a>
      <button id="logoutBtn" class="btn btn-danger btn-sm ms-2">
        <i class="bi bi-box-arrow-right"></i> Logout
      </button>
    `;
    chatLinkContainer.style.display = 'block';

    navbarRoot.querySelector('#logoutBtn').addEventListener('click', () => {
      window.API.logout();
      window.location.href = '/index.html';
    });
  } else {
    authContainer.innerHTML = `
      <a class="btn btn-outline-primary btn-sm ms-2" href="/pages/auth.html">
        <i class="bi bi-person"></i> Accedi / Registrati
      </a>
    `;
    if (sellBtnContainer) {
      sellBtnContainer.querySelector('a').href = '/pages/auth.html';
    }
  }
}

function setupSearch(navbarRoot) {
  const searchForm = navbarRoot.querySelector('#searchForm');
  if (searchForm) {
    searchForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const query = e.target.elements.search.value;
      if (query.trim()) {
        window.location.href = `/pages/listing.html?search=${encodeURIComponent(query)}`;
      }
    });
  }
}

async function setupNavbar() {
  const navbarPlaceholder = document.querySelector('div[data-include="navbar"]');
  if (!navbarPlaceholder) return;

  try {
    const response = await fetch('/pages/navbar.html');
    const navbarHTML = await response.text();
    navbarPlaceholder.innerHTML = navbarHTML;

    // Una volta che la navbar è nel DOM, usiamo il suo contenitore come radice
    // per tutte le ricerche successive, migliorando performance e manutenibilità.
    const navbarRoot = navbarPlaceholder;

    const isUserLoggedIn = !!(window.API && window.API.token);

    // Deleghiamo la logica a funzioni specifiche
    setupAuthUI(navbarRoot, isUserLoggedIn);
    setupSearch(navbarRoot);

  } catch (error) {
    console.error('Error loading navbar:', error);
    navbarPlaceholder.innerHTML = '<p class="text-danger text-center">Errore nel caricamento della barra di navigazione.</p>';
  }
}

// Esponiamo la funzione di setup in modo che altri script possano attenderla.
// Creiamo una promise che si risolve quando la navbar è pronta.
window.navbarReady = new Promise(resolve => {
  document.addEventListener('DOMContentLoaded', async () => {
    await setupNavbar();
    resolve();
  });
});