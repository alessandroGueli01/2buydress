window.navbarReady.then(() => {
  // Proteggi la pagina: solo gli utenti loggati possono accedere alla chat.
  if (!requireAuth()) return;

  // Stato dell'applicazione chat
  let conversations = [];
  let activeConversationId = null;
  let pollingInterval = null; // Variabile per gestire l'intervallo di polling
  const currentUser = window.API.user;
  const baseUrl = 'http://localhost:3000';

  // Helper per costruire URL sicuri per gli avatar
  function getSafeAvatarUrl(avatarPath) {
    if (!avatarPath) return '/assets/avatar_placeholder.png';
    if (avatarPath.startsWith('http')) return avatarPath;
    const path = avatarPath.startsWith('/') ? avatarPath : `/${avatarPath}`;
    return `${baseUrl}${path}`;
  }

  // Riferimenti agli elementi del DOM
  const chatListContainer = document.querySelector('.chat-list');
  const chatWindow = document.querySelector('.chat-window');
  const messagesContainer = document.getElementById('messages');
  const chatHeader = document.getElementById('chatHeader');
  const chatForm = document.getElementById('chatForm');
  const messageInput = document.getElementById('messageInput');
  const chatWelcome = document.getElementById('chatWelcome');

  /**
   * Formatta una data in un orario leggibile (es. "10:35").
   * @param {string} dateString - La data in formato stringa.
   * @returns {string} L'orario formattato.
   */
  function formatTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' });
  }

  /**
   * Renderizza la lista delle conversazioni sulla sinistra.
   */
  function renderConversationList() {
    chatListContainer.innerHTML = ''; // Pulisce la lista
    if (conversations.length === 0) {
      chatListContainer.innerHTML = '<p class="p-3 text-muted">Nessuna conversazione trovata.</p>';
      return;
    }

    conversations.forEach(conv => {
      const otherParticipant = conv.participants.find(p => p.id !== currentUser.id);
      if (!otherParticipant) return;

      const el = document.createElement('a');
      el.href = '#';
      el.className = 'list-group-item list-group-item-action';
      el.dataset.conversationId = conv.id;
      if (conv.id === activeConversationId) {
        el.classList.add('active');
      }

      // Badge per i messaggi non letti
      const badgeHtml = conv.unreadCount > 0 
        ? `<span class="badge bg-danger rounded-pill ms-2">${conv.unreadCount}</span>` 
        : '';

      el.innerHTML = `
        <div class="d-flex align-items-center">
          <img src="${getSafeAvatarUrl(otherParticipant.avatar)}" 
               class="rounded-circle me-3" style="width: 40px; height: 40px; flex-shrink: 0; object-fit: cover;">
          <div class="flex-grow-1">
            <div class="d-flex justify-content-between align-items-start">
              <h6 class="mb-0">${otherParticipant.name} ${badgeHtml}</h6>
              <small class="text-muted">${conv.lastMessage ? formatTime(conv.lastMessage.createdAt) : ''}</small>
            </div>
            <p class="mb-0 small text-muted text-truncate">${conv.lastMessage ? conv.lastMessage.content : 'Nessun messaggio'}</p>
          </div>
        </div>
      `;

      el.addEventListener('click', (e) => {
        e.preventDefault();
        loadConversation(conv.id);
      });

      chatListContainer.appendChild(el);
    });
  }

  /**
   * Renderizza i messaggi di una conversazione.
   * @param {Array} messages - La lista dei messaggi.
   */
  function renderMessages(messages) {
    messagesContainer.innerHTML = '';
    messages.forEach(msg => {
      const isCurrentUser = msg.sender.id === currentUser.id;
      const messageEl = document.createElement('div');
      messageEl.className = 'mb-3';
      messageEl.innerHTML = `
        <div class="d-flex ${isCurrentUser ? 'justify-content-end' : 'justify-content-start'}">
          <div class="${isCurrentUser ? 'bg-primary text-white' : 'bg-white'} rounded p-3 shadow-sm" style="max-width: 70%;">
            <p class="mb-1">${msg.content}</p>
            <small class="${isCurrentUser ? 'text-white-50' : 'text-muted'}">${formatTime(msg.createdAt)}</small>
          </div>
        </div>
      `;
      messagesContainer.appendChild(messageEl);
    });
    // Scrolla fino all'ultimo messaggio
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  /**
   * Recupera i nuovi messaggi dal server e aggiorna la UI.
   */
  async function fetchAndRenderNewMessages() {
    if (!activeConversationId) return;

    try {
      // Per ora, ricarichiamo tutti i messaggi per semplicità.
      // In futuro, si potrebbe ottimizzare chiedendo solo i messaggi
      // successivi all'ultimo ricevuto.
      const { messages } = await window.API.getMessages(activeConversationId);
      renderMessages(messages);
    } catch (error) {
      console.warn('Polling per nuovi messaggi fallito:', error);
      // Se c'è un errore (es. token scaduto), fermiamo il polling per non sovraccaricare.
      clearInterval(pollingInterval);
      pollingInterval = null;
    }
  }

  /**
   * Carica e visualizza una conversazione specifica.
   * @param {string} conversationId - L'ID della conversazione da caricare.
   */
  async function loadConversation(conversationId) {
    activeConversationId = conversationId;
    history.pushState(null, '', `/pages/chat.html?conversationId=${conversationId}`);
    renderConversationList(); // Aggiorna la UI per mostrare la selezione attiva

    // Ferma il polling precedente prima di iniziarne uno nuovo
    if (pollingInterval) {
      clearInterval(pollingInterval);
      pollingInterval = null;
    }

    try {
      const conversation = conversations.find(c => c.id === conversationId);
      const otherParticipant = conversation.participants.find(p => p.id !== currentUser.id);

      // --- AGGIORNAMENTO STATO LETTURA ---
      // 1. Aggiornamento Ottimistico UI: Rimuovi il badge rosso localmente
      if (conversation.unreadCount > 0) {
        conversation.unreadCount = 0;
        renderConversationList(); // Ridisegna la lista per far sparire il badge
        // 2. Chiamata API: Segna come letti sul server
        window.API.request(`/chat/conversations/${conversationId}/read`, { method: 'PATCH' }).catch(console.error);
      }

      // Aggiorna l'header della chat
      chatHeader.innerHTML = `
        <div class="d-flex align-items-center">
          <img src="${getSafeAvatarUrl(otherParticipant.avatar)}" class="rounded-circle me-3" style="width: 40px; height: 40px; object-fit: cover;">
          <div>
            <h6 class="mb-0">${otherParticipant.name}</h6>
            <small class="text-muted">Relativo a: ${conversation.listing.title}</small>
          </div>
        </div>
      `;

      // Mostra la finestra della chat e nascondi il messaggio di benvenuto
      chatWelcome.classList.add('d-none');
      chatWindow.classList.remove('d-none');

      // Carica e renderizza i messaggi
      const { messages } = await window.API.getMessages(conversationId);
      renderMessages(messages);

      // Avvia il nuovo polling per questa conversazione (ogni 5 secondi)
      pollingInterval = setInterval(fetchAndRenderNewMessages, 5000);

    } catch (error) {
      console.error('Errore nel caricare la conversazione:', error);
      alert('Impossibile caricare la conversazione.');
    }
  }

  /**
   * Gestisce l'invio di un nuovo messaggio.
   */
  chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const content = messageInput.value.trim();
    if (!content || !activeConversationId) return;

    try {
      // Invia il messaggio all'API
      const { message } = await window.API.sendMessage(activeConversationId, content);
      
      // Aggiungi il nuovo messaggio alla UI (aggiornamento ottimistico)
      const messageEl = document.createElement('div');
      messageEl.className = 'mb-3';
      messageEl.innerHTML = `
        <div class="d-flex justify-content-end">
          <div class="bg-primary text-white rounded p-3 shadow-sm" style="max-width: 70%;">
            <p class="mb-1">${message.content}</p>
            <small class="text-white-50">${formatTime(message.createdAt)}</small>
          </div>
        </div>
      `;
      messagesContainer.appendChild(messageEl);
      messagesContainer.scrollTop = messagesContainer.scrollHeight;
      messageInput.value = '';

      // Aggiorna la lista delle conversazioni per mostrare l'ultimo messaggio
      const conversation = conversations.find(c => c.id === activeConversationId);
      if (conversation) conversation.lastMessage = message;
      renderConversationList();

      // Controllo di sicurezza: mostra la notifica solo se la funzione esiste
      if (typeof window.showNotification === 'function') {
        window.showNotification('Nuovo messaggio inviato!', 'success', 2000);
      }
    } catch (error) {
      console.error('Errore nell\'invio del messaggio:', error);
      alert('Impossibile inviare il messaggio.');
    }
  });

  /**
   * Funzione di inizializzazione della pagina.
   */
  async function init() {
    try {
      const response = await window.API.getConversations();
      conversations = response.conversations;
      renderConversationList();

      // Controlla se c'è un ID di conversazione nell'URL per caricarla direttamente
      const params = new URLSearchParams(window.location.search);
      const conversationIdFromUrl = params.get('conversationId');
      if (conversationIdFromUrl && conversations.some(c => c.id === conversationIdFromUrl)) {
        loadConversation(conversationIdFromUrl);
      }

    } catch (error) {
      console.error('Errore nel caricamento delle conversazioni:', error);
      chatListContainer.innerHTML = '<div class="alert alert-danger">Impossibile caricare le conversazioni.</div>';
    }
  }

  // Avvia l'applicazione chat
  init();

  // Assicurati di fermare il polling quando l'utente lascia la pagina
  window.addEventListener('beforeunload', () => {
    if (pollingInterval) {
      clearInterval(pollingInterval);
    }
  });
});