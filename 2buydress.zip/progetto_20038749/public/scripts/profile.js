// Attendiamo che la navbar (e gli altri script principali) sia pronta
window.navbarReady.then(async () => {
  const profileContainer = document.getElementById('profileContainer');
  const loadingSpinner = document.getElementById('loadingSpinner');

  // Usa la nostra funzione guardia per proteggere la pagina
  if (!requireAuth()) return;

  try {
    // Uso i dati utente già disponibili nel client API, salvati durante il login.
    // Questo evita una chiamata API non necessaria e risolve l'inconsistenza.
    const user = window.API.user;
    if (!user) throw new Error('Dati utente non trovati. Prova a effettuare nuovamente il login.');
    
    // Costruisci l'URL dell'avatar in modo sicuro per evitare immagini rotte
    const baseUrl = 'http://localhost:3000';
    let avatarUrl = '/assets/avatar_placeholder.png';
    if (user.avatar) {
        const path = user.avatar.startsWith('/') ? user.avatar : `/${user.avatar}`;
        avatarUrl = user.avatar.startsWith('http') ? user.avatar : `${baseUrl}${path}`;
    }

    // Popolo i dati del profilo
    document.getElementById('profileAvatar').src = avatarUrl;
    document.getElementById('profileName').textContent = user.name;
    document.getElementById('profileEmail').textContent = user.email;
    document.getElementById('profileBio').textContent = user.bio || 'Nessuna bio inserita.';
    
    const locationText = document.getElementById('profileLocation');
    const locationDisplay = document.getElementById('locationDisplay');
    if (user.location) {
      locationText.textContent = user.location;
    } else {
      locationDisplay.style.display = 'none';
    }
    
    // Popolo il form di modifica
    document.getElementById('nameInput').value = user.name;
    document.getElementById('bioInput').value = user.bio || '';
    document.getElementById('locationInput').value = user.location || '';
    document.getElementById('addressLine1Input').value = user.addressLine1 || '';
    document.getElementById('cityInput').value = user.city || '';
    document.getElementById('postalCodeInput').value = user.postalCode || '';
    document.getElementById('countryInput').value = user.country || '';

    // Gestione aggiornamento profilo
    const profileForm = document.getElementById('profileForm');
    profileForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const updateBtn = profileForm.querySelector('button[type="submit"]');
      updateBtn.disabled = true;
      updateBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Salvataggio...';

      const updatedData = {
        name: document.getElementById('nameInput').value,
        bio: document.getElementById('bioInput').value,
        location: document.getElementById('locationInput').value,
        addressLine1: document.getElementById('addressLine1Input').value,
        city: document.getElementById('cityInput').value,
        postalCode: document.getElementById('postalCodeInput').value,
        country: document.getElementById('countryInput').value,
      };

      try {
        await window.API.updateProfile(updatedData);
        alert('Profilo aggiornato con successo!');
        window.location.reload();
      } catch (error) {
        alert(`Errore: ${error.message}`);
      } finally {
        updateBtn.disabled = false;
        updateBtn.innerHTML = '<i class="bi bi-check-circle"></i> Salva modifiche';
      }
    });

    // Gestione aggiornamento avatar
    const avatarForm = document.getElementById('avatarForm');
    const avatarInput = document.getElementById('avatarInput');
    const avatarPreview = document.getElementById('avatarPreview');
    const avatarModal = new bootstrap.Modal(document.getElementById('avatarModal'));

    // Mostra l'avatar corrente nel modal quando viene aperto
    document.getElementById('avatarModal').addEventListener('show.bs.modal', () => {
      avatarPreview.src = avatarUrl; // Usa l'URL sicuro già calcolato
      avatarInput.value = ''; // Resetta il campo file
    });

    // Aggiorna la preview quando un file viene selezionato
    avatarInput.addEventListener('change', () => {
      const file = avatarInput.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => { avatarPreview.src = e.target.result; };
        reader.readAsDataURL(file);
      }
    });

    avatarForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = avatarForm.querySelector('button[type="submit"]');
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Caricamento...';

      const formData = new FormData();
      formData.append('avatar', avatarInput.files[0]);

      try {
        await window.API.updateAvatar(formData);
        avatarModal.hide();
        window.location.reload(); // Ricarica la pagina per mostrare il nuovo avatar ovunque
      } catch (error) {
        alert(`Errore durante il caricamento: ${error.message}`);
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="bi bi-upload"></i> Carica e salva';
      }
    });

    // Carica e mostra gli annunci
    try { await loadUserContent(user.id); } catch (e) { console.error('Errore caricamento contenuti utente:', e); }
    
    // Inizializza e carica la sezione acquisti (gestita dinamicamente)
    try { await initPurchasesSection(); } catch (e) { console.error('Errore caricamento acquisti:', e); }

    // Inizializza e carica la sezione preferiti
    try { await initFavoritesSection(); } catch (e) { console.error('Errore caricamento preferiti:', e); }


    // Gestione tab
    const triggerTabList = [].slice.call(document.querySelectorAll('#myListingsTab button'));
    triggerTabList.forEach(function (triggerEl) {
      const tabTrigger = new bootstrap.Tab(triggerEl);
      triggerEl.addEventListener('click', function (event) {
        event.preventDefault();
        tabTrigger.show();
      });
    });

  } catch (error) {
    console.error('Errore nel caricamento del profilo:', error);
    profileContainer.innerHTML = `<div class="alert alert-danger">Impossibile caricare il profilo. ${error.message}</div>`;
  } finally {
    loadingSpinner.classList.add('d-none');
    profileContainer.classList.remove('d-none');
  }
}); // Chiusura di window.navbarReady.then()

async function loadUserContent(userId) {
  // Aggiungiamo un controllo di sicurezza: non fare nulla se l'ID non è valido.
  if (!userId) return;

  // Carica annunci
  const activeListings = await window.API.getUserListings(userId, { status: 'active' });
  const soldListings = await window.API.getUserListings(userId, { status: 'sold' });
  renderListings(activeListings.listings, 'active-listings-container');
  renderListings(soldListings.listings, 'sold-listings-container');
  document.getElementById('active-tab').textContent = `Attivi (${activeListings.totalDocs || 0})`;
  document.getElementById('sold-tab').textContent = `Venduti (${soldListings.totalDocs || 0})`;
  
  // Aggiorna anche eventuali contatori statici nella pagina (se presenti nell'HTML)
  const staticActive = document.getElementById('profileActiveCount');
  if (staticActive) staticActive.textContent = activeListings.totalDocs || 0;

  // Carica recensioni
  const reviews = await window.API.getUserReviews(userId);
  renderReviews(reviews, 'reviews-container');
  document.getElementById('reviews-tab').textContent = `Recensioni (${reviews.length || 0})`;

  const staticReviews = document.getElementById('profileReviewsCount');
  if (staticReviews) staticReviews.textContent = reviews.length || 0;
}

function renderListings(listings, containerId) {
  const container = document.getElementById(containerId);
  if (!listings || listings.length === 0) {
    container.innerHTML = '<p class="text-muted">Nessun annuncio in questa categoria.</p>';
    return;
  }

  const listGroup = document.createElement('div');
  listGroup.className = 'list-group';

  listings.forEach(item => {
    const el = document.createElement('a');
    el.href = `/pages/detail.html?id=${item.id}`;
    el.className = 'list-group-item list-group-item-action';
    
    const placeholderUrl = `https://loremflickr.com/500/500/fashion,clothes?lock=${item.id}`;
    // Controllo robusto: assicuriamoci che la foto sia una stringa valida
    let photoUrl = (item.photos && item.photos.length > 0 && typeof item.photos[0] === 'string') ? item.photos[0] : placeholderUrl;
    
    // Fix: Se il percorso è relativo (inizia con /), aggiungiamo l'URL del backend
    const baseUrl = 'http://localhost:3000';
    if (photoUrl.startsWith('http')) {
      // URL assoluto, va bene così
    } else {
      // URL relativo, aggiungiamo base e slash se serve
      const path = photoUrl.startsWith('/') ? photoUrl : `/${photoUrl}`;
      photoUrl = `${baseUrl}${path}`;
    }
    
    // Costruzione sicura del DOM (evita errori con virgolette nei titoli)
    const wrapper = document.createElement('div');
    wrapper.className = 'd-flex align-items-center';

    const img = document.createElement('img');
    img.alt = item.title;
    img.className = 'rounded me-3';
    img.style.cssText = 'width: 60px; height: 60px; object-fit: cover;';
    img.onerror = function() { this.onerror = null; this.src = placeholderUrl; };
    img.src = photoUrl;

    const contentDiv = document.createElement('div');
    contentDiv.className = 'flex-grow-1';
    contentDiv.innerHTML = `
      <h6 class="mb-1">${item.title}</h6>
      <small class="text-muted">Pubblicato il ${new Date(item.createdAt).toLocaleDateString()}</small>
    `;

    const price = document.createElement('strong');
    price.className = 'text-primary';
    price.textContent = new Intl.NumberFormat('it-IT', { style:'currency', currency:'EUR' }).format(item.price/100);

    wrapper.appendChild(img);
    wrapper.appendChild(contentDiv);
    wrapper.appendChild(price);
    
    el.appendChild(wrapper);
    listGroup.appendChild(el);
  });

  container.innerHTML = '';
  container.appendChild(listGroup);
}

function renderReviews(reviews, containerId) {
  const container = document.getElementById(containerId);
  if (!reviews || reviews.length === 0) {
    container.innerHTML = '<p class="text-muted">Nessuna recensione ricevuta per ora.</p>';
    return;
  }

  const reviewList = document.createElement('div');
  reviewList.className = 'list-group list-group-flush';

  reviews.forEach(review => {
    const el = document.createElement('div');
    el.className = 'list-group-item';
    
    let stars = '';
    for (let i = 0; i < 5; i++) {
      stars += `<i class="bi ${i < review.rating ? 'bi-star-fill text-warning' : 'bi-star text-muted'}"></i>`;
    }

    el.innerHTML = `
      <div class="d-flex w-100 justify-content-between">
        <h6 class="mb-1">${review.author ? review.author.name : 'Utente eliminato'}</h6>
        <small class="text-muted">${new Date(review.createdAt).toLocaleDateString()}</small>
      </div>
      <div class="mb-1">${stars}</div>
      <p class="mb-1">${review.comment}</p>
    `;
    reviewList.appendChild(el);
  });

  container.innerHTML = '';
  container.appendChild(reviewList);
}

// --- Funzionalità Acquisti e Recensioni ---

async function initPurchasesSection() {
  // 1. Inietta il Tab "Acquisti" se non esiste
  const tabList = document.getElementById('myListingsTab');
  const tabContent = document.getElementById('myListingsTabContent');
  
  if (tabList && !document.getElementById('purchases-tab')) {
    // Crea il bottone del tab
    const li = document.createElement('li');
    li.className = 'nav-item';
    li.role = 'presentation';
    li.innerHTML = `<button class="nav-link" id="purchases-tab" data-bs-toggle="tab" data-bs-target="#purchases" type="button">Acquisti</button>`;
    
    // Inserisci prima dell'ultimo tab (solitamente "Recensioni")
    tabList.insertBefore(li, tabList.lastElementChild);

    // Crea il contenitore del contenuto
    const div = document.createElement('div');
    div.className = 'tab-pane fade';
    div.id = 'purchases';
    div.role = 'tabpanel';
    div.innerHTML = `
      <div id="purchases-container" class="mt-3">
        <div class="text-center py-4"><div class="spinner-border text-primary"></div></div>
      </div>`;
    tabContent.appendChild(div);
  }

  // 2. Carica i dati
  try {
    // L'API restituisce un oggetto { purchases, sales }. A noi interessano gli acquisti.
    const { purchases } = await window.API.getMyOrders();
    renderOrders(purchases);
    
    const tabBtn = document.getElementById('purchases-tab');
    if (tabBtn) tabBtn.textContent = `Acquisti (${purchases.length || 0})`;

    // Aggiorna anche eventuali contatori statici nella pagina (se presenti nell'HTML)
    const staticPurchases = document.getElementById('profilePurchasesCount');
    if (staticPurchases) staticPurchases.textContent = purchases.length || 0;
  } catch (error) {
    console.error('Errore caricamento acquisti:', error);
    const container = document.getElementById('purchases-container');
    if (container) container.innerHTML = '<div class="alert alert-danger">Impossibile caricare gli acquisti.</div>';
  }
}

function renderOrders(orders) {
  const container = document.getElementById('purchases-container');
  if (!container) return;

  if (!orders || orders.length === 0) {
    container.innerHTML = '<p class="text-muted">Non hai ancora effettuato acquisti.</p>';
    return;
  }

  const listGroup = document.createElement('div');
  listGroup.className = 'list-group';

  orders.forEach(order => {
    const item = order.Listing || order.listing;
    if (!item) return;

    const el = document.createElement('div');
    el.className = 'list-group-item';
    const placeholderUrl = `https://loremflickr.com/500/500/fashion,clothes?lock=${item.id}`;
    // Controllo robusto
    let photoUrl = (item.photos && item.photos.length > 0 && typeof item.photos[0] === 'string') ? item.photos[0] : placeholderUrl;

    // Fix: Se il percorso è relativo (inizia con /), aggiungiamo l'URL del backend
    const baseUrl = 'http://localhost:3000';
    if (photoUrl.startsWith('http')) {
      // URL assoluto
    } else {
      const path = photoUrl.startsWith('/') ? photoUrl : `/${photoUrl}`;
      photoUrl = `${baseUrl}${path}`;
    }

    // Wrapper principale
    const wrapper = document.createElement('div');
    wrapper.className = 'd-flex align-items-center flex-wrap';

    // Link prodotto
    const link = document.createElement('a');
    link.href = `/pages/detail.html?id=${item.id}`;
    link.className = 'd-flex align-items-center text-decoration-none text-dark flex-grow-1';

    const img = document.createElement('img');
    img.alt = item.title;
    img.className = 'rounded me-3';
    img.style.cssText = 'width: 60px; height: 60px; object-fit: cover;';
    img.onerror = function() { this.onerror = null; this.src = placeholderUrl; };
    img.src = photoUrl;

    const infoDiv = document.createElement('div');
    infoDiv.innerHTML = `
      <h6 class="mb-1">${item.title}</h6>
      <small class="text-muted">Ordinato il ${new Date(order.createdAt).toLocaleDateString()}</small>
      <div class="fw-bold text-primary">${new Intl.NumberFormat('it-IT', { style:'currency', currency:'EUR' }).format(order.amount/100)}</div>
    `;

    link.appendChild(img);
    link.appendChild(infoDiv);

    // Azioni
    const actionsDiv = document.createElement('div');
    actionsDiv.className = 'ms-auto mt-2 mt-md-0';
    
    // Logica migliorata per mostrare lo stato corretto e le azioni contestuali
    switch (order.status) {
      case 'paid':
        actionsDiv.innerHTML = `<span class="badge bg-info text-dark">In attesa di spedizione</span>`;
        break;
      case 'shipped':
        // Aggiungiamo il bottone per confermare la ricezione
        actionsDiv.innerHTML = `<button class="btn btn-success btn-sm receive-btn" data-order-id="${order.id}"><i class="bi bi-box-arrow-in-down"></i> Conferma ricezione</button>`;
        break;
      case 'delivered':
        // Ora che è consegnato, l'utente può recensire. Passiamo l'ID del venditore.
        actionsDiv.innerHTML = `<button class="btn btn-outline-warning btn-sm review-btn" data-listing-id="${item.id}" data-listing-title="${item.title}" data-seller-id="${order.sellerId}"><i class="bi bi-star"></i> Lascia Recensione</button>`;
        break;
      case 'completed':
        actionsDiv.innerHTML = `<span class="badge bg-success">Completato</span>`;
        break;
      default:
        // Fallback per stati non gestiti
        actionsDiv.innerHTML = `<span class="badge bg-secondary">${order.status}</span>`;
        break;
    }

    wrapper.appendChild(link);
    wrapper.appendChild(actionsDiv);
    el.appendChild(wrapper);
    listGroup.appendChild(el);
  });

  container.innerHTML = '';
  container.appendChild(listGroup);

  // Aggiungi event listener per i bottoni recensione
  container.querySelectorAll('.review-btn').forEach(btn => {
    btn.addEventListener('click', (e) => openReviewModal(e.target.closest('button').dataset));
  });

  // Aggiungi event listener per il nuovo bottone "Conferma ricezione"
  container.querySelectorAll('.receive-btn').forEach(btn => {
    btn.addEventListener('click', (e) => confirmReception(e.target.closest('button').dataset.orderId));
  });
}

function openReviewModal({ listingId, listingTitle, sellerId }) {
  // Crea un modal dinamico se non esiste
  let modalEl = document.getElementById('reviewModal');
  if (!modalEl) {
    modalEl = document.createElement('div');
    modalEl.id = 'reviewModal';
    modalEl.className = 'modal fade';
    modalEl.innerHTML = `
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Recensisci acquisto</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <p>Come ti sei trovato con: <strong id="reviewItemTitle"></strong>?</p>
            <form id="reviewForm">
              <input type="hidden" id="reviewListingId">
              <input type="hidden" id="reviewTargetId">
              <div class="mb-3">
                <label class="form-label">Valutazione</label>
                <select class="form-select" id="reviewRating" required>
                  <option value="5">⭐⭐⭐⭐⭐ Eccellente</option>
                  <option value="4">⭐⭐⭐⭐ Buono</option>
                  <option value="3">⭐⭐⭐ Sufficiente</option>
                  <option value="2">⭐⭐ Scarso</option>
                  <option value="1">⭐ Pessimo</option>
                </select>
              </div>
              <div class="mb-3">
                <label class="form-label">Commento</label>
                <textarea class="form-control" id="reviewComment" rows="3" required placeholder="Descrivi la tua esperienza..."></textarea>
              </div>
              <button type="submit" class="btn btn-primary w-100">Invia Recensione</button>
            </form>
          </div>
        </div>
      </div>`;
    document.body.appendChild(modalEl);

    // Gestione invio
    const form = modalEl.querySelector('#reviewForm');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = form.querySelector('button');
      btn.disabled = true;
      
      try {
        await window.API.createReview({
          targetId: document.getElementById('reviewTargetId').value, // Invia l'ID del venditore
          rating: parseInt(document.getElementById('reviewRating').value, 10),
          comment: document.getElementById('reviewComment').value
        });
        alert('Recensione inviata con successo!');
        bootstrap.Modal.getInstance(document.getElementById('reviewModal')).hide();
        window.location.reload();
      } catch (err) {
        alert('Errore: ' + err.message);
        btn.disabled = false;
      }
    });
  }

  // Popola e apri il modal
  document.getElementById('reviewItemTitle').textContent = listingTitle;
  document.getElementById('reviewListingId').value = listingId;
  document.getElementById('reviewTargetId').value = sellerId;
  document.getElementById('reviewComment').value = '';
  
  const bsModal = new bootstrap.Modal(modalEl);
  bsModal.show();
}

/**
 * Gestisce la conferma di ricezione di un ordine.
 * @param {string} orderId L'ID dell'ordine da confermare.
 */
async function confirmReception(orderId) {
  if (!orderId || orderId === 'undefined') {
    alert('Errore: ID ordine non valido. Ricarica la pagina e riprova.');
    return;
  }
  if (!confirm('Confermi di aver ricevuto questo articolo? Questa azione aggiornerà lo stato dell\'ordine.')) return;

  try {
    await window.API.confirmReception(orderId);
    alert('Grazie per la conferma! Ora puoi lasciare una recensione per questo acquisto.');
    window.location.reload(); // Ricarica la pagina per aggiornare lo stato
  } catch (error) {
    alert(`Errore durante la conferma: ${error.message}`);
  }
}

// --- Funzionalità Preferiti ---

async function initFavoritesSection() {
  const tabList = document.getElementById('myListingsTab');
  const tabContent = document.getElementById('myListingsTabContent');

  // Evita duplicati se la funzione viene chiamata più volte
  if (tabList && !document.getElementById('favorites-tab')) {
    const li = document.createElement('li');
    li.className = 'nav-item';
    li.role = 'presentation';
    li.innerHTML = `<button class="nav-link" id="favorites-tab" data-bs-toggle="tab" data-bs-target="#favorites" type="button">Preferiti</button>`;
    
    // Aggiungiamo il tab alla fine della lista
    tabList.appendChild(li);

    const div = document.createElement('div');
    div.className = 'tab-pane fade';
    div.id = 'favorites';
    div.role = 'tabpanel';
    div.innerHTML = `
      <div id="favorites-container" class="mt-3">
        <div class="text-center py-4"><div class="spinner-border text-primary"></div></div>
      </div>`;
    tabContent.appendChild(div);
  }

  try {
    const favorites = await window.API.getMyFavorites();
    // Riutilizziamo la funzione renderListings esistente che gestisce già le card e le immagini
    renderListings(favorites, 'favorites-container');
    
    const tabBtn = document.getElementById('favorites-tab');
    if (tabBtn) tabBtn.textContent = `Preferiti (${favorites.length || 0})`;
  } catch (error) {
    console.error('Errore caricamento preferiti:', error);
    const container = document.getElementById('favorites-container');
    if (container) container.innerHTML = '<div class="alert alert-danger">Impossibile caricare i preferiti.</div>';
  }
}