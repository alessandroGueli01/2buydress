// Attendiamo che la navbar sia pronta prima di eseguire lo script della pagina
window.navbarReady.then(async () => {
  const detailContainer = document.getElementById('detailContainer');
  const template = document.getElementById('detailTemplate');

  const params = new URLSearchParams(window.location.search);
  const listingId = params.get('id');

  if (!listingId) {
    detailContainer.innerHTML = '<div class="alert alert-danger">ID annuncio non trovato.</div>';
    return;
  }

  try {
    const listing = await window.API.getListing(listingId);
    let isFavorite = false;

    // Se l'utente è loggato, controlliamo se l'annuncio è tra i suoi preferiti.
    // Questo richiede una chiamata aggiuntiva.
    if (window.API && window.API.user) {
      const favorites = await window.API.getMyFavorites();
      isFavorite = favorites.some(fav => fav.id === listing.id);
    }

    const seller = listing.seller;

    // Clona e popola il template
    const clone = template.content.cloneNode(true);

    // Popola il carosello
    const carouselInner = clone.querySelector('.carousel-inner');
    const carouselIndicators = clone.querySelector('.carousel-indicators');
    
    let validPhotoCount = 0;

    (listing.photos || []).forEach((photo, index) => {
      // Controllo di sicurezza: se la foto non è una stringa valida, saltiamo
      if (!photo || typeof photo !== 'string') return;

      const carouselItem = document.createElement('div');
      // Assegna 'active' solo alla prima foto valida trovata
      carouselItem.className = `carousel-item ${validPhotoCount === 0 ? 'active' : ''}`;
      
      const img = document.createElement('img');
      img.className = 'd-block w-100';
      img.style.cssText = 'aspect-ratio: 1/1; object-fit: cover;';
      img.alt = `${listing.title} - Foto ${index + 1}`;
      img.onerror = function() {
        this.onerror = null;
        this.src = `https://placehold.co/800x800/e0e0e0/777?text=Immagine+non+disponibile`;
      };
      
      // Fix: Se il percorso è relativo (inizia con /), aggiungiamo l'URL del backend
      const baseUrl = 'http://localhost:3000';
      let photoUrl = photo;
      if (!photo.startsWith('http')) {
         const path = photo.startsWith('/') ? photo : `/${photo}`;
         photoUrl = `${baseUrl}${path}`;
      }
      img.src = photoUrl;

      carouselItem.appendChild(img);
      carouselInner.appendChild(carouselItem);

      const indicator = document.createElement('button');
      indicator.type = 'button';
      indicator.dataset.bsTarget = '#photoCarousel';
      indicator.dataset.bsSlideTo = validPhotoCount;
      if (validPhotoCount === 0) indicator.className = 'active';
      carouselIndicators.appendChild(indicator);
      
      validPhotoCount++;
    });

    // Se non ci sono foto valide, mostra un placeholder
    if (validPhotoCount === 0) {
       const carouselItem = document.createElement('div');
       carouselItem.className = 'carousel-item active';
       carouselItem.innerHTML = `<img src="https://placehold.co/800x800/e0e0e0/777?text=Nessuna+immagine" class="d-block w-100" style="aspect-ratio: 1/1; object-fit: cover;">`;
       carouselInner.appendChild(carouselItem);
    }

    // Popola i dettagli
    clone.getElementById('detailTitle').textContent = listing.title;
    
    // Popola i costi
    const price = listing.price;
    const shippingCost = listing.shippingCost;
    const totalPrice = price + shippingCost;
    
    const detailPriceEl = clone.getElementById('detailPrice');
    if (detailPriceEl) detailPriceEl.textContent = formatPrice(price);
    const detailShippingCostEl = clone.getElementById('detailShippingCost');
    if (detailShippingCostEl) detailShippingCostEl.textContent = formatPrice(shippingCost);
    const detailTotalPriceEl = clone.getElementById('detailTotalPrice');
    if (detailTotalPriceEl) detailTotalPriceEl.textContent = formatPrice(totalPrice);

    clone.getElementById('detailBrand').textContent = listing.brand || '-';
    clone.getElementById('detailSize').textContent = listing.size;
    clone.getElementById('detailCondition').textContent = listing.condition;
    clone.getElementById('detailViews').textContent = listing.views || 0;
    clone.getElementById('detailDescription').textContent = listing.description;

    // Status
    const statusBadge = clone.getElementById('detailStatus');
    const isAvailable = listing.status === 'active' || listing.status === 'available';
    statusBadge.textContent = isAvailable ? 'Disponibile' : 'Venduto';
    statusBadge.classList.add(isAvailable ? 'bg-success' : 'bg-secondary');

    // Popola info venditore
    const sellerInfo = clone.getElementById('sellerInfo');
    
    // Costruisci l'URL dell'avatar del venditore in modo sicuro
    const baseUrl = 'http://localhost:3000';
    let sellerAvatarUrl = '/assets/avatar_placeholder.png';
    if (seller.avatar) {
        const path = seller.avatar.startsWith('/') ? seller.avatar : `/${seller.avatar}`;
        sellerAvatarUrl = seller.avatar.startsWith('http') ? seller.avatar : `${baseUrl}${path}`;
    }

    sellerInfo.innerHTML = `
      <div class="card border-0 bg-light p-3">
        <div class="d-flex align-items-center">
          <a href="/pages/public-profile.html?id=${seller.id}" class="text-decoration-none text-dark d-flex align-items-center w-100">
            <img src="${sellerAvatarUrl}" class="rounded-circle" style="width: 50px; height: 50px; object-fit: cover;" alt="${seller.name}">
            <div class="ms-3">
              <h6 class="mb-0 hover-underline">${seller.name}</h6>
              <small class="text-muted">
                <i class="bi bi-star-fill text-warning"></i> ${seller.rating || 'N/A'} (${seller.reviewCount || 0} recensioni)
              </small>
            </div>
          </a>
        </div>
      </div>`;

    // Popola i bottoni di azione
    const actionsContainer = clone.getElementById('actionsContainer');
    // La funzione `getCurrentUser` si trova in `guards.js`, che non è caricato qui. La sua logica è stata integrata direttamente.
    const currentUser = (window.API && window.API.user) ? window.API.user : null;

    if (currentUser && currentUser.id === seller.id) {
      // L'utente è il venditore
      actionsContainer.innerHTML = `
        <a href="/pages/edit-listing.html?id=${listing.id}" class="btn btn-secondary btn-lg">
          <i class="bi bi-pencil"></i> Modifica annuncio
        </a>
      `;
    } else if (listing.status !== 'active') {
      actionsContainer.innerHTML = `
        <button class="btn btn-secondary btn-lg" disabled>
          <i class="bi bi-bag-check-fill"></i> Articolo venduto
        </a>
      `;
    } else {
      // L'utente è un potenziale acquirente
      actionsContainer.innerHTML = `
        <button id="contactBtn" class="btn btn-primary btn-lg">
          <i class="bi bi-chat-dots"></i> Contatta il venditore
        </button>
        <button id="buyBtn" class="btn btn-success btn-lg">
          <i class="bi bi-cart-check"></i> Acquista ora
        </button>
        <button id="favoriteBtn" class="btn btn-outline-primary btn-lg">
          <i class="bi ${isFavorite ? 'bi-heart-fill' : 'bi-heart'}"></i> ${isFavorite ? 'Rimuovi dai preferiti' : 'Aggiungi ai preferiti'}
        </button>
      `;

      // Logica per il bottone "Contatta"
      clone.getElementById('contactBtn').addEventListener('click', async () => {
        if (!currentUser) {
          window.location.href = '/pages/auth.html';
          return;
        }
        try {
          const conversation = await window.API.createConversation(listing.id, seller.id);
          window.location.href = `/pages/chat.html?conversationId=${conversation.id}`;
        } catch (error) {
          alert(`Errore nell'avviare la conversazione: ${error.message}`);
        }
      });

      // Logica per il bottone "Acquista"
      clone.getElementById('buyBtn').addEventListener('click', async () => {
        if (!currentUser) {
          window.location.href = '/pages/auth.html';
          return;
        }
        if (!currentUser.addressLine1 || !currentUser.city) {
          alert('Per favore, inserisci il tuo indirizzo di spedizione nel profilo prima di procedere con l\'acquisto.');
          window.location.href = '/pages/profile.html';
          return;
        }
        if (confirm(`Sei sicuro di voler acquistare "${listing.title}" per un totale di ${formatPrice(totalPrice)} (spedizione inclusa)?`)) {
          try {
            await window.API.simulatePayment(listing.id);
            alert('Acquisto simulato con successo! Troverai i dettagli nel tuo profilo.');
            window.location.reload();
          } catch (error) {
            alert(`Errore durante l'acquisto: ${error.message}`);
          }
        }
      });

      // Logica per il bottone "Preferiti"
      const favoriteBtn = clone.getElementById('favoriteBtn');
      favoriteBtn.addEventListener('click', async () => {
        if (!currentUser) {
          window.location.href = '/pages/auth.html';
          return;
        }
        try {
          if (isFavorite) {
            await window.API.removeFavorite(listing.id);
          } else {
            await window.API.addFavorite(listing.id);
          }
          isFavorite = !isFavorite; // Aggiorna lo stato localmente
          favoriteBtn.innerHTML = `<i class="bi ${isFavorite ? 'bi-heart-fill' : 'bi-heart'}"></i> ${isFavorite ? 'Rimuovi dai preferiti' : 'Aggiungi ai preferiti'}`;
        } catch (error) {
          alert(`Errore: ${error.message}`);
        }
      });
    }

    // Sostituisci lo spinner con il contenuto
    detailContainer.innerHTML = '';
    detailContainer.appendChild(clone);

  } catch (error) {
    console.error('Errore nel caricamento dell\'annuncio:', error);
    detailContainer.innerHTML = `<div class="alert alert-danger">Impossibile caricare l'annuncio. ${error.message}</div>`;
  }
}); // Chiusura di window.navbarReady.then()

// Aggiungiamo la funzione simulatePayment al client API se non esiste
if (window.API && !window.API.simulatePayment) {
  window.API.simulatePayment = async function(listingId) {
    return await this.request('/payments/pay', {
      method: 'POST',
      body: JSON.stringify({ listingId })
    });
  };
}

// Funzione per formattare il prezzo (puoi metterla in un file di utility)
function formatPrice(cents) {
  return new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR' }).format(cents / 100);
}