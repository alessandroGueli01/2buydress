window.navbarReady.then(async () => {
  const params = new URLSearchParams(window.location.search);
  const userId = params.get('id');
  
  const container = document.getElementById('profileContainer');
  const spinner = document.getElementById('loadingSpinner');

  if (!userId) {
    spinner.innerHTML = '<div class="alert alert-danger">Utente non specificato.</div>';
    return;
  }

  try {
    // 1. Carica info utente
    const user = await window.API.getUser(userId);
    
    // Costruisci l'URL dell'avatar in modo sicuro
    const baseUrl = 'http://localhost:3000';
    let avatarUrl = '/assets/avatar_placeholder.png';
    if (user.avatar) {
        const path = user.avatar.startsWith('/') ? user.avatar : `/${user.avatar}`;
        avatarUrl = user.avatar.startsWith('http') ? user.avatar : `${baseUrl}${path}`;
    }
    document.getElementById('sellerAvatar').src = avatarUrl;
    document.getElementById('sellerName').textContent = user.name;
    document.getElementById('sellerLocation').textContent = user.location || 'Nessuna posizione';
    document.getElementById('sellerRating').textContent = user.rating ? user.rating.toFixed(1) : 'N/A';
    document.getElementById('sellerReviewCount').textContent = user.reviewCount || 0;
    document.getElementById('sellerBio').textContent = user.bio || 'Nessuna biografia.';
    document.getElementById('sellerJoined').textContent = new Date(user.createdAt).toLocaleDateString();

    // 2. Carica annunci attivi (usiamo status 'active' per vedere solo quelli in vendita)
    // Nota: getUserListings restituisce un oggetto { listings: [], ... }
    const response = await window.API.getUserListings(userId, { status: 'active' });
    const listings = response.listings || [];
    
    const listingsGrid = document.getElementById('listingsGrid');
    if (listings.length === 0) {
      listingsGrid.innerHTML = '<div class="col-12 text-center text-muted py-4">Nessun annuncio attivo al momento.</div>';
    } else {
      listings.forEach(item => {
        // Riutilizziamo il componente card esistente
        listingsGrid.appendChild(window.Components.createCard(item));
      });
    }

    // 3. Carica recensioni
    const reviews = await window.API.getUserReviews(userId);
    const reviewsList = document.getElementById('reviewsList');
    
    if (reviews.length === 0) {
      reviewsList.innerHTML = '<div class="text-center text-muted py-4">Nessuna recensione ancora.</div>';
    } else {
      reviews.forEach(review => {
        const el = document.createElement('div');
        el.className = 'list-group-item';
        
        let stars = '';
        for (let i = 0; i < 5; i++) {
          stars += `<i class="bi ${i < review.rating ? 'bi-star-fill text-warning' : 'bi-star text-muted'}"></i>`;
        }

        el.innerHTML = `
          <div class="d-flex w-100 justify-content-between">
            <h6 class="mb-1">${review.author ? review.author.name : 'Utente eliminato'}</h6>
            <small class="text-muted">${new Date(review.createdAt).toLocaleDateString()}</small>
          </div>
          <div class="mb-2">${stars}</div>
          <p class="mb-1">${review.comment}</p>
        `;
        reviewsList.appendChild(el);
      });
    }

    // Mostra il contenuto
    spinner.classList.add('d-none');
    container.classList.remove('d-none');

  } catch (error) {
    console.error(error);
    spinner.innerHTML = `<div class="alert alert-danger">Errore nel caricamento del profilo: ${error.message}</div>`;
  }
});