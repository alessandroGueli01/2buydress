window.navbarReady.then(async () => {
  // Verifica autenticazione
  if (typeof requireAuth === 'function') {
    if (!requireAuth()) return;
  } else if (window.API && !window.API.user) {
    window.location.href = '/pages/auth.html';
    return;
  }

  const container = document.getElementById('notificationsContainer');
  const list = document.getElementById('notificationsList');
  const spinner = document.getElementById('loadingSpinner');
  const emptyState = document.getElementById('emptyState');
  const markAllBtn = document.getElementById('markAllReadBtn');

  // Estendi API client se i metodi non esistono
  if (!window.API.getNotifications) {
    window.API.getNotifications = async function() {
      return await this.request('/notifications');
    };
  }
  
  if (!window.API.markNotificationRead) {
    window.API.markNotificationRead = async function(id) {
      return await this.request(`/notifications/${id}/read`, { method: 'PUT' });
    };
  }

  if (!window.API.markAllNotificationsRead) {
    window.API.markAllNotificationsRead = async function() {
      return await this.request('/notifications/read-all', { method: 'PUT' });
    };
  }

  async function loadNotifications() {
    try {
      const notifications = await window.API.getNotifications();
      renderNotifications(notifications);
    } catch (error) {
      console.error(error);
      spinner.innerHTML = `<div class="alert alert-danger">Errore caricamento notifiche: ${error.message}</div>`;
    }
  }

  function renderNotifications(notifications) {
    spinner.classList.add('d-none');
    container.classList.remove('d-none');
    list.innerHTML = '';

    if (!notifications || notifications.length === 0) {
      emptyState.classList.remove('d-none');
      markAllBtn.classList.add('d-none');
      return;
    }

    emptyState.classList.add('d-none');
    markAllBtn.classList.remove('d-none');

    notifications.forEach(notif => {
      const el = document.createElement('a');
      el.href = getNotificationLink(notif);
      el.className = `list-group-item list-group-item-action d-flex align-items-center ${notif.isRead ? 'bg-light text-muted' : ''}`;
      
      // Icona e colore in base al tipo
      let icon = 'bi-bell';
      let color = 'text-primary';
      
      switch(notif.type) {
        case 'new_favorite':
          icon = 'bi-heart-fill';
          color = 'text-danger';
          break;
        case 'new_message':
          icon = 'bi-chat-dots-fill';
          color = 'text-success';
          break;
        case 'new_review':
          icon = 'bi-star-fill';
          color = 'text-warning';
          break;
        case 'order_update':
          icon = 'bi-box-seam';
          color = 'text-warning';
          break;
      }

      if (notif.isRead) color = 'text-secondary';

      el.innerHTML = `
        <div class="fs-4 me-3 ${color}"><i class="bi ${icon}"></i></div>
        <div class="flex-grow-1">
          <div class="d-flex w-100 justify-content-between">
            <h6 class="mb-1">${notif.content.message || 'Nuova notifica'}</h6>
            <small class="${notif.isRead ? 'text-muted' : 'text-primary fw-bold'}">
              ${new Date(notif.createdAt).toLocaleDateString()} ${new Date(notif.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
            </small>
          </div>
          ${!notif.isRead ? '<span class="badge bg-primary rounded-pill">Nuovo</span>' : ''}
        </div>
      `;

      el.addEventListener('click', async () => {
        if (!notif.isRead) {
          window.API.markNotificationRead(notif.id).catch(console.error);
        }
      });

      list.appendChild(el);
    });
  }

  function getNotificationLink(notif) {
    if (notif.listingId) return `/pages/detail.html?id=${notif.listingId}`;
    if (notif.type === 'new_message') return `/pages/chat.html`;
    if (notif.type === 'new_review') return '/pages/profile.html#reviews';
    return '#';
  }

  markAllBtn.addEventListener('click', async () => {
    await window.API.markAllNotificationsRead().catch(alert);
    loadNotifications();
  });

  loadNotifications();
});