// Funzione per formattare il prezzo da centesimi a stringa EUR
function formatPrice(cents) {
  return new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR' }).format(cents / 100);
}

/**
 * Crea una card di un prodotto per la griglia del catalogo.
 * @param {object} item - L'oggetto dell'annuncio proveniente dall'API.
 * @returns {HTMLElement} L'elemento del DOM della card.
 */
function createCard(item) {
  const cardWrapper = document.createElement('div');
  cardWrapper.className = 'col';

  // Usa LoremFlickr per foto realistiche di moda (stile Zalando/Vinted)
  const placeholderUrl = `https://loremflickr.com/500/500/fashion,clothes?lock=${item.id}`;
  let firstPhoto = (item.photos && item.photos.length > 0 && item.photos[0]) ? item.photos[0] : placeholderUrl;

  // Creiamo il link contenitore
  const link = document.createElement('a');
  link.href = `/pages/detail.html?id=${item.id}`;
  // Stile Zalando/Vinted: niente bordo, ombra leggera, sfondo bianco
  link.className = 'card h-100 text-decoration-none text-dark border-0 shadow-sm product-card';

  // Wrapper immagine: sfondo grigio così si vede il box anche se l'immagine fallisce
  const imgContainer = document.createElement('div');
  imgContainer.className = 'position-relative bg-light overflow-hidden';
  imgContainer.style.cssText = 'aspect-ratio: 1/1; width: 100%;';

  const img = document.createElement('img');
  img.className = 'w-100 h-100';
  img.style.cssText = 'object-fit: cover; transition: transform 0.3s ease;'; // Effetto zoom leggero
  img.alt = item.title;
  
  // Logica "Bulletproof" per Safari e immagini rotte
  img.onerror = function() {
    this.onerror = null;
    this.src = placeholderUrl;
  };
  
  // Fix: Se il percorso è relativo (inizia con /), aggiungiamo l'URL del backend
  const baseUrl = 'http://localhost:3000';
  let photoUrl = firstPhoto;
  if (firstPhoto && !firstPhoto.startsWith('http')) {
    const path = firstPhoto.startsWith('/') ? firstPhoto : `/${firstPhoto}`;
    photoUrl = `${baseUrl}${path}`;
  }
  img.src = photoUrl;

  imgContainer.appendChild(img);

  // Corpo della card stile e-commerce
  const body = document.createElement('div');
  body.className = 'card-body p-2'; // Padding ridotto per look moderno
  body.innerHTML = `
    <div class="d-flex justify-content-between align-items-start">
      <div>
        <p class="fw-bold mb-0 text-dark">${formatPrice(item.price)}</p>
        <small class="text-muted">${item.size}</small>
      </div>
    </div>
    <p class="card-text text-truncate mt-1 mb-0 text-secondary" style="font-size: 0.9rem;">${item.brand || 'Brand generico'}</p>
  `;

  link.appendChild(imgContainer);
  link.appendChild(body);
  cardWrapper.appendChild(link);
  
  return cardWrapper;
}

/**
 * Crea i controlli di paginazione.
 * @param {number} totalPages - Il numero totale di pagine.
 * @param {number} currentPage - La pagina corrente.
 * @param {string} baseUrl - La parte base dell'URL per i link.
 * @returns {string} La stringa HTML per la paginazione.
 */
function createPagination(totalPages, currentPage, baseUrl) {
  if (totalPages <= 1) return '';

  let paginationHTML = '<ul class="pagination">';
  
  // Determina il separatore corretto (& o ?)
  const separator = baseUrl === '?' ? '' : '&';

  // Bottone "Previous"
  paginationHTML += `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}">
    <a class="page-link" href="${baseUrl}${separator}page=${currentPage - 1}">Precedente</a>
  </li>`;

  // Pagine numerate
  for (let i = 1; i <= totalPages; i++) {
    paginationHTML += `<li class="page-item ${i === currentPage ? 'active' : ''}">
      <a class="page-link" href="${baseUrl}${separator}page=${i}">${i}</a>
    </li>`;
  }

  // Bottone "Next"
  paginationHTML += `<li class="page-item ${currentPage === totalPages ? 'disabled' : ''}">
    <a class="page-link" href="${baseUrl}${separator}page=${currentPage + 1}">Successivo</a>
  </li>`;

  paginationHTML += '</ul>';
  return paginationHTML;
}

// Esponiamo le funzioni globalmente per un facile accesso
window.Components = { createCard, createPagination };