// 2buydress - API Client per backend Express
const API_BASE_URL = 'http://localhost:3000/api';

class API {
  constructor() {
    this.user = JSON.parse(localStorage.getItem('user'));
    this.token = localStorage.getItem('token');
  }

  // Utility per le chiamate HTTP
  async request(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`;

    const headers = {
      ...(this.token && { Authorization: `Bearer ${this.token}` }),
      ...options.headers
    };

    // Se il body è FormData, non impostare Content-Type, il browser lo fa per noi
    if (!(options.body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
    }

    const config = {
      headers,
      ...options
    };

    try {
      const response = await fetch(url, config);

      // Gestione di errori non-JSON (es. 502 Bad Gateway, crash del server)
      const contentType = response.headers.get('content-type');
      if (!response.ok && (!contentType || !contentType.includes('application/json'))) {
        throw new Error(`Errore del server (${response.status}): ${response.statusText}`);
      }

      const data = await response.json().catch(() => {
        // Se il body è vuoto ma lo status è OK (es. 204 No Content), restituisce null
        if (response.ok) return null;
        // Altrimenti, l'errore è che il JSON non è valido
        throw new Error(`La risposta del server non è un JSON valido (status: ${response.status})`);
      });

      if (!response.ok) {
        // Gestione specifica per errori di autenticazione
        if (response.status === 401 || response.status === 403) {
          console.warn('Errore di autenticazione. Logout in corso.');
          this.logout();
          sessionStorage.setItem('returnUrl', window.location.pathname + window.location.search);
          window.location.href = '/pages/auth.html';
          throw new Error(data.message || 'Sessione scaduta o non valida. Effettua nuovamente il login.');
        }
        throw new Error(data.message || 'Errore API sconosciuto.');
      }

      return data;
    } catch (error) {
      console.error('API Error:', error);
      if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
        throw new Error('Impossibile connettersi al server. Verifica la tua connessione o che il server sia attivo.');
      }
      throw error;
    }
  }

  // Autenticazione
  async register(userData) {
    const response = await this.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData)
    });
    
    if (response.token) {
      this.token = response.token;
      localStorage.setItem('token', response.token);
      this.user = response.user;
      localStorage.setItem('user', JSON.stringify(response.user));
    }
    
    return response;
  }

  async login(credentials) {
    const response = await this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials)
    });
    
    if (response.token) {
      this.token = response.token;
      localStorage.setItem('token', response.token);
      this.user = response.user;
      localStorage.setItem('user', JSON.stringify(response.user));
    }
    
    return response;
  }

  async getCurrentUser() {
    return await this.request('/auth/me');
  }

  logout() {
    this.token = null;
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  }

  // Listing (Annunci)
  async getListings(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return await this.request(`/listings?${queryString}`);
  }

  async getBrands() {
    return await this.request('/listings/brands');
  }

  async getListing(id) {
    return await this.request(`/listings/${id}`);
  }

  async createListing(listingData) {
    return await this.request('/listings', {
      method: 'POST',
      // listingData deve essere un oggetto FormData per l'upload di file
      body: listingData
    });
  }

  async updateListing(id, listingData) {
    return await this.request(`/listings/${id}`, {
      method: 'PUT',
      // Non usiamo JSON.stringify perché listingData è un oggetto FormData
      body: listingData
    });
  }

  async deleteListing(id) {
    return await this.request(`/listings/${id}`, {
      method: 'DELETE'
    });
  }

  async updateListingStatus(id, status) {
    return await this.request(`/listings/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  }

  // Favorites
  async getMyFavorites() {
    return await this.request('/users/me/favorites');
  }

  async addFavorite(listingId) {
    return await this.request(`/listings/${listingId}/favorite`, {
      method: 'POST'
    });
  }

  async removeFavorite(listingId) {
    return await this.request(`/listings/${listingId}/favorite`, {
      method: 'DELETE'
    });
  }

  // Utenti
  async getUser(id) {
    return await this.request(`/users/${id}`);
  }

  async updateProfile(profileData) {
    const updatedUser = await this.request('/users/profile', {
      method: 'PUT',
      body: JSON.stringify(profileData)
    });

    // Aggiorno l'utente nel client e nel localStorage per mantenere la coerenza
    this.user = updatedUser;
    localStorage.setItem('user', JSON.stringify(updatedUser));

    return updatedUser;
  }

  async updateAvatar(formData) {
    const updatedUser = await this.request('/users/avatar', {
      method: 'PUT',
      body: formData, // FormData viene inviato direttamente
    });

    // Aggiorno l'utente nel client e nel localStorage
    this.user = updatedUser;
    localStorage.setItem('user', JSON.stringify(updatedUser));

    return updatedUser;
  }

  async getUserListings(userId, params = {}) {
    const queryString = new URLSearchParams(params).toString();
    return await this.request(`/users/${userId}/listings?${queryString}`);
  }

  // Ordini
  async getMyOrders() {
    return await this.request('/users/me/orders');
  }

  async confirmReception(orderId) {
    // Metodo per confermare la ricezione di un ordine
    return await this.request(`/orders/${orderId}/receive`, {
      method: 'PUT'
    });
  }

  // Recensioni
  async getUserReviews(userId) {
    return await this.request(`/reviews/user/${userId}`);
  }

  async createReview(reviewData) {
    // reviewData = { listingId, rating, comment }
    return await this.request('/reviews', {
      method: 'POST',
      body: JSON.stringify(reviewData)
    });
  }

  // Chat
  async getConversations() {
    return await this.request('/chat/conversations');
  }

  async createConversation(listingId, otherUserId) {
    return await this.request('/chat/conversations', {
      method: 'POST',
      body: JSON.stringify({ listingId, otherUserId })
    });
  }

  async getMessages(conversationId) {
    return await this.request(`/chat/conversations/${conversationId}/messages`);
  }

  async sendMessage(conversationId, content, type = 'text') {
    return await this.request(`/chat/conversations/${conversationId}/messages`, {
      method: 'POST',
      body: JSON.stringify({ content, type })
    });
  }
}

// Istanza globale dell'API
window.API = new API();
