// Verifica che l'utente sia loggato e abbia un token
const token = localStorage.getItem('token');
const user = JSON.parse(localStorage.getItem('user') || '{}');

// Redirect se non è admin (controllo lato client veloce, il vero controllo è lato server)
if (!token || !user.is_admin) {
    alert('Accesso negato. Area riservata agli amministratori.');
    window.location.href = '/';
}

// --- Funzioni API ---

async function fetchStats() {
    try {
        const res = await fetch('/api/admin/stats', {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (!res.ok) throw new Error('Errore nel caricamento statistiche');
        const data = await res.json();
        
        const statsHtml = `
            <div class="col-md-4">
                <div class="card card-stat text-white bg-primary mb-3 shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title text-white-50">Utenti Registrati</h6>
                                <h2 class="card-text fw-bold">${data.users}</h2>
                            </div>
                            <i class="bi bi-people fs-1 opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-stat text-white bg-success mb-3 shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title text-white-50">Annunci Attivi</h6>
                                <h2 class="card-text fw-bold">${data.listings.active} <span class="fs-6 fw-normal opacity-75">/ ${data.listings.total}</span></h2>
                            </div>
                            <i class="bi bi-tags fs-1 opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-stat text-white bg-warning mb-3 shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="card-title text-white-50">Ordini Totali</h6>
                                <h2 class="card-text fw-bold">${data.orders}</h2>
                            </div>
                            <i class="bi bi-bag-check fs-1 opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.getElementById('stats-container').innerHTML = statsHtml;
    } catch (err) {
        console.error(err);
        document.getElementById('stats-container').innerHTML = '<div class="alert alert-danger">Impossibile caricare le statistiche.</div>';
    }
}

async function fetchReports() {
    try {
        const res = await fetch('/api/reports?status=pending', {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        const reports = await res.json();
        
        const tbody = document.getElementById('reports-table-body');
        
        if (reports.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center py-4 text-muted">Nessuna segnalazione in attesa 🎉</td></tr>';
            return;
        }

        tbody.innerHTML = reports.map(report => `
            <tr>
                <td class="ps-4">${new Date(report.createdAt).toLocaleDateString()}</td>
                <td><span class="badge bg-secondary">${report.targetType.toUpperCase()}</span></td>
                <td>${report.reason}</td>
                <td>${report.reporter ? report.reporter.name : 'Utente eliminato'}</td>
                <td>
                    <button class="btn btn-sm btn-success me-1" onclick="resolveReport(${report.id}, 'resolved')" title="Accetta segnalazione"><i class="bi bi-check-lg"></i></button>
                    <button class="btn btn-sm btn-outline-danger me-1" onclick="resolveReport(${report.id}, 'rejected')" title="Rifiuta (falso positivo)"><i class="bi bi-x-lg"></i></button>
                    ${report.targetType === 'user' ? `<button class="btn btn-sm btn-dark" onclick="suspendUser(${report.targetId})" title="Sospendi Utente"><i class="bi bi-slash-circle"></i> Ban</button>` : ''}
                </td>
            </tr>
        `).join('');
    } catch (err) {
        console.error(err);
    }
}

async function resolveReport(id, status) {
    if(!confirm(`Confermi di voler segnare questa segnalazione come ${status === 'resolved' ? 'RISOLTA' : 'RIFIUTATA'}?`)) return;
    
    await fetch(`/api/reports/${id}`, {
        method: 'PUT',
        headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}` 
        },
        body: JSON.stringify({ status })
    });
    fetchReports(); // Ricarica la tabella
}

async function suspendUser(userId) {
    if(!confirm('ATTENZIONE: Sei sicuro di voler sospendere questo utente? Non potrà più accedere.')) return;
    
    const res = await fetch(`/api/admin/users/${userId}/suspend`, {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${token}` }
    });
    
    const data = await res.json();
    alert(data.message);
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/';
}

// Inizializzazione
fetchStats();
fetchReports();