/**
 * Funzioni "guardia" per proteggere le pagine che richiedono autenticazione.
 */

function requireAuth() {
  const isUserLoggedIn = !!(window.API && window.API.token);

  if (!isUserLoggedIn) {
    // Se non c'è, reindirizza l'utente alla pagina di login
    // Salviamo la pagina corrente per reindirizzare l'utente dopo il login
    const returnUrl = window.location.pathname + window.location.search;
    sessionStorage.setItem('returnUrl', returnUrl);

    console.warn('Accesso non autorizzato, reindirizzamento al login.');
    window.location.href = `/pages/auth.html`;
    return false; // Indica che il controllo non è passato
  }
  return true; // Indica che l'utente è autenticato
}

// Una funzione helper per ottenere l'utente corrente in modo sicuro
function getCurrentUser() {
  if (!window.API || !window.API.token) return null;
  return window.API.user; // Assumendo che window.API.user venga popolato al login
}