window.navbarReady.then(async () => {
    // Verifica permessi admin (opzionale lato frontend, gestito dal backend)
    const user = window.API.user;
    if (!user) {
        window.location.href = '/pages/auth.html';
        return;
    }

    // Estensione API per analytics
    if (!window.API.getAdminAnalytics) {
        window.API.getAdminAnalytics = async function() {
            // Tenta la chiamata al backend
            try {
                return await this.request('/admin/analytics');
            } catch (error) {
                console.warn('Endpoint analytics non trovato, uso dati demo.');
                // Dati Mock per dimostrazione se il backend non è pronto
                return {
                    totalUsers: 124,
                    totalRevenue: 450000, // in centesimi
                    activeListings: 85,
                    completedOrders: 42,
                    revenueHistory: {
                        labels: ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu'],
                        data: [500, 1200, 900, 1500, 2000, 2800]
                    },
                    categoryDistribution: {
                        labels: ['Uomo', 'Donna', 'Bambino', 'Accessori', 'Scarpe'],
                        data: [30, 45, 15, 10, 20]
                    }
                };
            }
        };
    }

    async function initDashboard() {
        try {
            const data = await window.API.getAdminAnalytics();
            renderStats(data);
            renderCharts(data);
        } catch (error) {
            console.error('Errore caricamento dashboard:', error);
            alert('Impossibile caricare i dati della dashboard.');
        }
    }

    function renderStats(data) {
        document.getElementById('totalUsers').textContent = data.totalUsers;
        // Formatta valuta (ricorda: backend invia centesimi)
        document.getElementById('totalRevenue').textContent = new Intl.NumberFormat('it-IT', { 
            style: 'currency', 
            currency: 'EUR',
            maximumFractionDigits: 0 
        }).format(data.totalRevenue / 100);
        document.getElementById('activeListings').textContent = data.activeListings;
        document.getElementById('completedOrders').textContent = data.completedOrders;
    }

    function renderCharts(data) {
        // Grafico Linea - Ricavi
        const ctxRevenue = document.getElementById('revenueChart').getContext('2d');
        new Chart(ctxRevenue, {
            type: 'line',
            data: {
                labels: data.revenueHistory.labels,
                datasets: [{
                    label: 'Ricavi (€)',
                    data: data.revenueHistory.data,
                    borderColor: '#0d6efd', // Bootstrap primary
                    backgroundColor: 'rgba(13, 110, 253, 0.1)',
                    fill: true,
                    tension: 0.3
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });

        // Grafico Ciambella - Categorie
        const ctxCategory = document.getElementById('categoryChart').getContext('2d');
        new Chart(ctxCategory, {
            type: 'doughnut',
            data: {
                labels: data.categoryDistribution.labels,
                datasets: [{
                    data: data.categoryDistribution.data,
                    backgroundColor: ['#0d6efd', '#198754', '#ffc107', '#0dcaf0', '#6c757d'],
                    hoverOffset: 4
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }

    initDashboard();
});