// Attendiamo che la navbar sia pronta prima di eseguire lo script della pagina
window.navbarReady.then(() => {
  const filterForm = document.getElementById('filterForm');
  const catalogGrid = document.getElementById('catalogGrid');
  const paginationContainer = document.getElementById('paginationContainer');
  const resultsCount = document.getElementById('resultsCount');

  // Funzione per popolare il form dei filtri basandosi sull'URL
  function populateFilters() {
    const params = new URLSearchParams(window.location.search);
    document.getElementById('searchInput').value = params.get('search') || '';
    document.getElementById('categorySelect').value = params.get('category') || '';
    document.getElementById('conditionSelect').value = params.get('condition') || '';
    document.getElementById('minPriceInput').value = params.get('minPrice') || '';
    document.getElementById('maxPriceInput').value = params.get('maxPrice') || '';
  }

  // Funzione per caricare gli annunci
  async function loadListings() {
    catalogGrid.innerHTML = '<div class="text-center w-100"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Caricamento...</span></div></div>';

    const currentParams = new URLSearchParams(window.location.search);
    const query = Object.fromEntries(currentParams.entries());

    try {
      const response = await window.API.getListings(query);
      const { listings, pagination } = response;
      const { totalItems: total, totalPages, currentPage } = pagination || { totalItems: 0, totalPages: 0, currentPage: 1 };

      // Mostra il numero di risultati
      resultsCount.textContent = `Trovati ${total} articoli`;

      // Pulisci e popola la griglia
      catalogGrid.innerHTML = '';
      if (listings.length === 0) {
        // Se non ci sono risultati, prova a caricare i brand suggeriti
        try {
          const brands = await window.API.getBrands();
          const brandBadges = brands.map(b => 
            `<a href="?search=${encodeURIComponent(b)}" class="badge bg-secondary text-decoration-none me-1 mb-1 fs-6 p-2">${b}</a>`
          ).join('');
          
          catalogGrid.innerHTML = `
            <div class="text-center w-100 py-5">
              <h4 class="text-muted mb-3">Nessun articolo trovato per "${query.search || query.q || ''}" 😔</h4>
              <p class="mb-3">Prova a dare un'occhiata a questi brand popolari:</p>
              <div class="d-flex flex-wrap justify-content-center gap-2" style="max-width: 600px; margin: 0 auto;">${brandBadges}</div>
            </div>`;
        } catch (e) {
          catalogGrid.innerHTML = '<p class="text-center text-muted w-100">Nessun articolo corrisponde alla tua ricerca.</p>';
        }
      } else {
        listings.forEach(item => { // Usiamo il nostro component!
          catalogGrid.appendChild(window.Components.createCard(item));
        });
      }

      // Crea la paginazione
      // Rimuoviamo 'page' dai parametri per creare la base URL corretta
      currentParams.delete('page');
      const baseUrl = `?${currentParams.toString()}`;
      paginationContainer.innerHTML = window.Components.createPagination(totalPages, parseInt(currentPage), baseUrl);

    } catch (error) {
      console.error('Errore nel caricamento del catalogo:', error);
      catalogGrid.innerHTML = `<div class="alert alert-danger w-100">Si è verificato un errore. Riprova più tardi.</div>`;
    }
  }

  // Gestione submit del form dei filtri per aggiornare l'URL e ricaricare i dati
  filterForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const formData = new FormData(filterForm);
    const newParams = new URLSearchParams();

    formData.forEach((value, key) => {
      if (value) newParams.append(key, value);
    });

    window.history.pushState({}, '', `${window.location.pathname}?${newParams.toString()}`);
    loadListings();
  });

  // Popola i filtri e carica i dati al primo accesso alla pagina
  populateFilters();
  loadListings();
});