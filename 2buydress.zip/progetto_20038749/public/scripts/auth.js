// scripts/auth.js

document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');

  // Se l'utente è già loggato, reindirizzalo alla home
  if (window.API && window.API.token) {
    window.location.href = '../index.html';
    return;
  }

  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('loginEmail').value;
      const password = document.getElementById('loginPassword').value;

      try {
        await window.API.login({ email, password });
        showResult('✓ Login effettuato con successo! Sarai reindirizzato...', 'success');
        setTimeout(() => {
          // Controlla se c'è un URL di ritorno salvato dalla guardia
          const returnUrl = sessionStorage.getItem('returnUrl');
          if (returnUrl) {
            sessionStorage.removeItem('returnUrl'); // Pulisci dopo l'uso
            window.location.href = returnUrl;
          } else {
            window.location.href = '../index.html'; // Fallback alla homepage
          }
        }, 1500);
      } catch (error) {
        showResult(`Errore: ${error.message}`, 'danger');
      }
    });
  }

  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('registerName').value;
      const email = document.getElementById('registerEmail').value;
      const password = document.getElementById('registerPassword').value;
      const confirmPassword = document.getElementById('confirmPassword').value;

      if (password !== confirmPassword) {
        showResult('Le password non coincidono', 'danger');
        return;
      }

      try {
        await window.API.register({ name, email, password });
        showResult('✓ Registrazione completata! Reindirizzamento...', 'success');

        setTimeout(() => {
          const returnUrl = sessionStorage.getItem('returnUrl');
          if (returnUrl) {
            sessionStorage.removeItem('returnUrl');
            window.location.href = returnUrl;
          } else {
            window.location.href = '../index.html';
          }
        }, 1500);
      } catch (error) {
        showResult(`Errore: ${error.message}`, 'danger');
      }
    });
  }

  function showResult(msg, type) {
    const resultEl = document.getElementById('authResult');
    resultEl.textContent = msg;
    resultEl.className = `alert alert-${type} mt-3`;
    resultEl.classList.remove('d-none');
  }
});