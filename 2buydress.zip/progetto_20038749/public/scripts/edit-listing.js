// Attendiamo che la navbar sia pronta prima di eseguire lo script della pagina
window.navbarReady.then(async () => {
  // Proteggi la pagina
  if (!requireAuth()) return;

  const listingForm = document.getElementById('listingForm');
  const resultDiv = document.getElementById('result');
  const updateBtn = document.getElementById('updateBtn');
  const deleteBtn = document.getElementById('deleteBtn');
  const markAsSoldBtn = document.getElementById('markAsSoldBtn');
  const loadingSpinner = document.getElementById('loadingSpinner');
  const editFormContainer = document.getElementById('editFormContainer');

  const params = new URLSearchParams(window.location.search);
  const listingId = params.get('id');

  if (!listingId) {
    document.querySelector('main').innerHTML = '<div class="alert alert-danger">ID annuncio non fornito.</div>';
    return;
  }

  // Elementi del form
  const titleInput = document.getElementById('title');
  const descriptionInput = document.getElementById('description');
  const categoryInput = document.getElementById('category');
  const brandInput = document.getElementById('brand');
  const sizeInput = document.getElementById('size');
  const conditionInput = document.getElementById('condition');
  const priceInput = document.getElementById('price');
  const shippingCostInput = document.getElementById('shippingCost'); // Riferimento al nuovo campo
  const photoPreview = document.getElementById('photoPreview');
  const photoInput = document.getElementById('photos'); // Aggiungi riferimento all'input file

  try {
    // 1. Carica i dati dell'annuncio esistente
    const listing = await window.API.getListing(listingId);
    // Controlla che l'utente sia il proprietario
    if (window.API.user.id !== listing.seller.id) {
      document.querySelector('main').innerHTML = '<div class="alert alert-danger">Non sei autorizzato a modificare questo annuncio.</div>';
      return;
    }

    // 2. Popola il form con i dati
    titleInput.value = listing.title;
    descriptionInput.value = listing.description;
    categoryInput.value = listing.category;
    brandInput.value = listing.brand || '';
    sizeInput.value = listing.size;
    conditionInput.value = listing.condition;
    priceInput.value = (listing.price / 100).toFixed(2); // Converti da centesimi a euro
    shippingCostInput.value = (listing.shippingCost / 100).toFixed(2); // Popola il costo di spedizione

    // Mostra le foto esistenti
    (listing.photos || []).forEach((photo, index) => {
      // Controllo di sicurezza
      if (!photo || typeof photo !== 'string') return;

      // Fix: Se il percorso è relativo (inizia con /), aggiungiamo l'URL del backend per la visualizzazione
      const baseUrl = 'http://localhost:3000';
      const path = photo.startsWith('/') ? photo : `/${photo}`;
      const displayUrl = photo.startsWith('http') ? photo : `${baseUrl}${path}`;

      const imgContainer = document.createElement('div');
      imgContainer.className = 'position-relative d-inline-block me-2 mb-2';
      imgContainer.dataset.photoUrl = photo; // Salviamo l'URL originale (relativo) per la rimozione
      imgContainer.innerHTML = `
        <img src="${displayUrl}" class="img-thumbnail" style="width: 100px; height: 100px; object-fit: cover;">
        <button type="button" class="btn btn-danger btn-sm position-absolute top-0 end-0 remove-photo-btn" style="line-height: 1; padding: .2rem .4rem;">
          <i class="bi bi-x"></i>
        </button>
      `;
      photoPreview.appendChild(imgContainer);
    });

    // Aggiungi gestione preview per nuove foto
    photoInput.addEventListener('change', (e) => {
      Array.from(e.target.files).forEach(file => {
        const reader = new FileReader();
        reader.onload = (event) => {
          const imgContainer = document.createElement('div');
          // Aggiungiamo un bordo diverso per distinguere le nuove foto
          imgContainer.className = 'position-relative d-inline-block me-2 mb-2';
          imgContainer.innerHTML = `
            <img src="${event.target.result}" class="img-thumbnail border-primary" style="width: 100px; height: 100px; object-fit: cover;" title="Nuova foto (non ancora salvata)">
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-primary">+</span>
          `;
          photoPreview.appendChild(imgContainer);
        };
        reader.readAsDataURL(file);
      });
    });

    // Mostra il form e nascondi lo spinner
    loadingSpinner.classList.add('d-none');
    editFormContainer.classList.remove('d-none');

    // Se l'annuncio è già venduto, nascondi i bottoni di azione
    if (listing.status === 'sold') {
      updateBtn.style.display = 'none';
      markAsSoldBtn.style.display = 'none';
    }

  } catch (error) {
    document.querySelector('main').innerHTML = `<div class="alert alert-danger">Errore nel caricamento dei dati: ${error.message}</div>`;
    return;
  }

  // 3. Gestione submit per l'aggiornamento
  listingForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    updateBtn.disabled = true;
    updateBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Aggiornamento...';

    const formData = new FormData();
    formData.append('title', titleInput.value);
    formData.append('description', descriptionInput.value);
    formData.append('category', categoryInput.value);
    formData.append('brand', brandInput.value);
    formData.append('size', sizeInput.value);
    formData.append('condition', conditionInput.value);
    formData.append('price', parseFloat(priceInput.value));
    formData.append('shippingCost', parseFloat(shippingCostInput.value));

    // Aggiungi le nuove foto
    Array.from(photoInput.files).forEach(file => {
      formData.append('photos', file);
    });

    // Aggiungi le foto da rimuovere
    const photosToRemove = Array.from(photoPreview.querySelectorAll('.to-remove')).map(el => el.dataset.photoUrl);
    if (photosToRemove.length > 0) {
      formData.append('photosToRemove', JSON.stringify(photosToRemove));
    }

    try {
      // Dovrai modificare window.API.updateListing per accettare FormData
      await window.API.updateListing(listingId, formData);
      showResult('✓ Annuncio aggiornato con successo!', 'success');
      setTimeout(() => {
        window.location.href = `/pages/detail.html?id=${listingId}`;
      }, 1500);
    } catch (error) {
      showResult(`Errore: ${error.message}`, 'danger');
      updateBtn.disabled = false;
      updateBtn.innerHTML = '<i class="bi bi-check-circle"></i> Salva modifiche';
    }
  });

  // Logica per marcare una foto per la rimozione
  photoPreview.addEventListener('click', (e) => {
    if (e.target.closest('.remove-photo-btn')) {
      const container = e.target.closest('.position-relative');
      container.style.display = 'none'; // Nascondi la foto
      container.classList.add('to-remove'); // Aggiungi una classe per identificarla al submit
    }
  });

  // 4. Gestione eliminazione
  deleteBtn.addEventListener('click', async () => {
    if (confirm('Sei sicuro di voler eliminare questo annuncio? L\'azione è irreversibile.')) {
      try {
        await window.API.deleteListing(listingId);
        alert('Annuncio eliminato con successo.');
        window.location.href = '/pages/profile.html';
      } catch (error) {
        showResult(`Errore durante l'eliminazione: ${error.message}`, 'danger');
      }
    }
  });

  // 5. Gestione "Segna come venduto"
  markAsSoldBtn.addEventListener('click', async () => {
    if (confirm('Sei sicuro di voler segnare questo articolo come venduto?')) {
      try {
        await window.API.updateListingStatus(listingId, 'sold');
        showResult('✓ Annuncio segnato come venduto!', 'success');
        // Disabilita i bottoni dopo l'azione
        updateBtn.style.display = 'none';
        markAsSoldBtn.style.display = 'none';
        deleteBtn.textContent = 'Archivia annuncio'; // Cambia testo per chiarezza
      } catch (error) {
        showResult(`Errore: ${error.message}`, 'danger');
      }
    }
  });

  function showResult(msg, type) {
    resultDiv.textContent = msg;
    resultDiv.className = `alert alert-${type} mt-3`;
    resultDiv.classList.remove('d-none');
  }
}); // Chiusura di window.navbarReady.then()