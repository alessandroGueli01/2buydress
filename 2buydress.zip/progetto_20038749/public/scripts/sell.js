// Attendiamo che la navbar (e gli altri script principali) sia pronta
window.navbarReady.then(() => {
  // Usa la nostra funzione guardia per proteggere la pagina
  if (!requireAuth()) return;

  const listingForm = document.getElementById('listingForm');
  const photoInput = document.getElementById('photos');
  const photoPreview = document.getElementById('photoPreview');
  const resultDiv = document.getElementById('result');
  const publishBtn = document.getElementById('publish');

  // Gestione preview foto
  photoInput.addEventListener('change', function (e) {
    photoPreview.innerHTML = '';

    Array.from(e.target.files).forEach((file, index) => {
      if (index < 10) { // Mostra max 10 preview
        const reader = new FileReader();
        reader.onload = function (event) {
          const imgContainer = document.createElement('div');
          imgContainer.className = 'position-relative d-inline-block';
          imgContainer.innerHTML = `
            <img src="${event.target.result}" 
                 class="img-thumbnail me-2 mb-2" 
                 style="width: 100px; height: 100px; object-fit: cover;" 
                 alt="Preview ${index + 1}">
          `;
          photoPreview.appendChild(imgContainer);
        };
        reader.readAsDataURL(file);
      }
    });
  });

  // Gestione submit del form
  listingForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    publishBtn.disabled = true;
    publishBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Pubblicazione...';

    try {
      const formData = new FormData();
      formData.append('title', document.getElementById('title').value.trim());
      formData.append('description', document.getElementById('description').value.trim());
      formData.append('category', document.getElementById('category').value);
      formData.append('brand', document.getElementById('brand').value.trim());
      formData.append('size', document.getElementById('size').value.trim());
      formData.append('condition', document.getElementById('condition').value);
      
      // Sostituiamo la virgola con il punto per la conversione e validiamo
      // Aggiungiamo controlli di sicurezza nel caso gli elementi non esistano
      const priceEl = document.getElementById('price');
      const shippingEl = document.getElementById('shippingCost');
      const priceValue = priceEl ? priceEl.value.replace(',', '.') : '0';
      const shippingValue = shippingEl ? shippingEl.value.replace(',', '.') : '0';

      const priceInEuro = parseFloat(priceValue || '0');
      const shippingCostInEuro = parseFloat(shippingValue || '0');

      // Validazione robusta dei campi numerici prima dell'invio
      if (isNaN(priceInEuro) || priceInEuro <= 0) {
        showResult('Il prezzo deve essere un numero maggiore di zero.', 'danger');
        resetButton();
        return;
      }
      if (isNaN(shippingCostInEuro) || shippingCostInEuro < 0) {
        showResult('Il costo di spedizione non è un numero valido.', 'danger');
        resetButton();
        return;
      }

      formData.append('price', priceInEuro);
      formData.append('shippingCost', shippingCostInEuro);

      const photos = Array.from(photoInput.files);

      // Validazione foto
      if (photos.length === 0) {
        showResult('Seleziona almeno una foto.', 'danger');
        resetButton();
        return;
      }
      if (photos.length > 10) {
        showResult('Puoi caricare un massimo di 10 foto.', 'danger');
        resetButton();
        return;
      }

      photos.forEach(photo => {
        formData.append('photos', photo);
      });

      const res = await window.API.createListing(formData);

      // Controllo difensivo: se la risposta non è un oggetto valido con un ID,
      // qualcosa è andato storto anche se l'API non ha restituito un errore formale.
      if (!res || !res.id) {
        throw new Error('La risposta del server non è valida dopo la creazione dell\'annuncio.');
      }
      
      // Mostra il risultato visivo immediato
      showResult(`✓ Annuncio "${res.title}" creato con successo!`, 'success');

      // Tenta di mostrare la notifica toast solo se la funzione esiste
      if (typeof window.showNotification === 'function') {
        window.showNotification(`Annuncio "${res.title}" creato con successo!`, 'success', 3000);
      }

      setTimeout(() => {
        window.location.href = `/pages/detail.html?id=${res.id}`;
      }, 2000);
    } catch (error) {
      console.error('Errore creazione annuncio:', error);
      const errorMessage = error.message || 'Si è verificato un errore sconosciuto durante la creazione dell\'annuncio.';
      showResult(`Errore: ${errorMessage}`, 'danger');
      // In caso di errore, riabilitiamo il bottone per permettere un nuovo tentativo.
      resetButton();
    }
  });

  function showResult(msg, type) {
    resultDiv.textContent = msg;
    resultDiv.className = `alert alert-${type} mt-3`;
    resultDiv.classList.remove('d-none');
  }

  function resetButton() {
    publishBtn.disabled = false;
    publishBtn.innerHTML = '<i class="bi bi-check-circle"></i> Pubblica annuncio';
  }
}); // Chiusura di window.navbarReady.then()