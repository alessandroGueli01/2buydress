// Definizione globale di showNotification per i messaggi Toast
if (!window.showNotification) {
  window.showNotification = (message, type = 'success', duration = 3000) => {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type} position-fixed top-0 end-0 m-3 shadow`;
    toast.style.zIndex = '1050'; // Assicura che sia sopra tutto
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), duration);
  };
}

// Attendiamo che la navbar (e gli altri script principali) sia pronta
window.navbarReady.then(() => {
  const initHomepage = async () => {
    const yearEl = document.getElementById('year');
    if (yearEl) yearEl.textContent = new Date().getFullYear().toString();

    const grid = document.getElementById('catalogGrid');
    if (!grid) return;

    try {
      grid.innerHTML = '<div class="text-center w-100"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Caricamento...</span></div></div>';
      const response = await window.API.getListings({ limit: 8, sort: 'createdAt:desc' });
      const listings = response.listings || [];

      grid.innerHTML = ''; // Pulisci la griglia
      if (listings.length === 0) {
        grid.innerHTML = '<p class="text-center text-muted">Nessun articolo trovato. Sii il primo a metterne in vendita uno!</p>';
        return;
      }

      listings.forEach((item) => grid.appendChild(window.Components.createCard(item)));
    } catch (error) {
      console.error('Errore caricamento listing:', error);
      grid.innerHTML = `<div class="alert alert-danger">Si è verificato un errore nel caricare gli articoli. Riprova più tardi.</div>`;
    }
  };

  initHomepage();
});
