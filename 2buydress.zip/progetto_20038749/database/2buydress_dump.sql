--
-- PostgreSQL database dump
--

-- Dumped from database version 14.17 (Homebrew)
-- Dumped by pg_dump version 14.17 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ConversationParticipants; Type: TABLE; Schema: public; Owner: alessandrogueli
--

CREATE TABLE public."ConversationParticipants" (
    "UserId" integer NOT NULL,
    "ConversationId" integer NOT NULL
);


ALTER TABLE public."ConversationParticipants" OWNER TO alessandrogueli;

--
-- Name: Conversations; Type: TABLE; Schema: public; Owner: alessandrogueli
--

CREATE TABLE public."Conversations" (
    id integer NOT NULL,
    "listingId" integer NOT NULL,
    status character varying(255) DEFAULT 'active'::character varying,
    "lastMessageAt" timestamp with time zone,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Conversations" OWNER TO alessandrogueli;

--
-- Name: Conversations_id_seq; Type: SEQUENCE; Schema: public; Owner: alessandrogueli
--

CREATE SEQUENCE public."Conversations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Conversations_id_seq" OWNER TO alessandrogueli;

--
-- Name: Conversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alessandrogueli
--

ALTER SEQUENCE public."Conversations_id_seq" OWNED BY public."Conversations".id;


--
-- Name: Favorites; Type: TABLE; Schema: public; Owner: alessandrogueli
--

CREATE TABLE public."Favorites" (
    "createdAt" timestamp with time zone NOT NULL,
    "UserId" integer NOT NULL,
    "ListingId" integer NOT NULL
);


ALTER TABLE public."Favorites" OWNER TO alessandrogueli;

--
-- Name: Listings; Type: TABLE; Schema: public; Owner: alessandrogueli
--

CREATE TABLE public."Listings" (
    id integer NOT NULL,
    title character varying(100) NOT NULL,
    description text NOT NULL,
    price integer NOT NULL,
    currency character varying(3) DEFAULT 'EUR'::character varying,
    category character varying(255) NOT NULL,
    brand character varying(255),
    size character varying(255) NOT NULL,
    condition character varying(255) NOT NULL,
    photos json DEFAULT '[]'::json NOT NULL,
    status character varying(255) DEFAULT 'active'::character varying,
    views integer DEFAULT 0,
    "shippingCost" integer DEFAULT 0 NOT NULL,
    attributes json DEFAULT '{}'::json,
    "sellerId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Listings" OWNER TO alessandrogueli;

--
-- Name: Listings_id_seq; Type: SEQUENCE; Schema: public; Owner: alessandrogueli
--

CREATE SEQUENCE public."Listings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Listings_id_seq" OWNER TO alessandrogueli;

--
-- Name: Listings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alessandrogueli
--

ALTER SEQUENCE public."Listings_id_seq" OWNED BY public."Listings".id;


--
-- Name: Messages; Type: TABLE; Schema: public; Owner: alessandrogueli
--

CREATE TABLE public."Messages" (
    id integer NOT NULL,
    content text NOT NULL,
    type character varying(255) DEFAULT 'text'::character varying,
    "isRead" boolean DEFAULT false,
    "readAt" timestamp with time zone,
    "conversationId" integer NOT NULL,
    "senderId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Messages" OWNER TO alessandrogueli;

--
-- Name: Messages_id_seq; Type: SEQUENCE; Schema: public; Owner: alessandrogueli
--

CREATE SEQUENCE public."Messages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Messages_id_seq" OWNER TO alessandrogueli;

--
-- Name: Messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alessandrogueli
--

ALTER SEQUENCE public."Messages_id_seq" OWNED BY public."Messages".id;


--
-- Name: Notifications; Type: TABLE; Schema: public; Owner: alessandrogueli
--

CREATE TABLE public."Notifications" (
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    content json,
    "isRead" boolean DEFAULT false,
    "readAt" timestamp with time zone,
    "recipientId" integer NOT NULL,
    "senderId" integer,
    "listingId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Notifications" OWNER TO alessandrogueli;

--
-- Name: Notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: alessandrogueli
--

CREATE SEQUENCE public."Notifications_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Notifications_id_seq" OWNER TO alessandrogueli;

--
-- Name: Notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alessandrogueli
--

ALTER SEQUENCE public."Notifications_id_seq" OWNED BY public."Notifications".id;


--
-- Name: Reviews; Type: TABLE; Schema: public; Owner: alessandrogueli
--

CREATE TABLE public."Reviews" (
    id integer NOT NULL,
    rating integer NOT NULL,
    comment text,
    "authorId" integer NOT NULL,
    "targetId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Reviews" OWNER TO alessandrogueli;

--
-- Name: Reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: alessandrogueli
--

CREATE SEQUENCE public."Reviews_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Reviews_id_seq" OWNER TO alessandrogueli;

--
-- Name: Reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alessandrogueli
--

ALTER SEQUENCE public."Reviews_id_seq" OWNED BY public."Reviews".id;


--
-- Name: Users; Type: TABLE; Schema: public; Owner: alessandrogueli
--

CREATE TABLE public."Users" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    avatar character varying(255),
    bio text,
    location character varying(255),
    "addressLine1" character varying(255),
    city character varying(255),
    "postalCode" character varying(255),
    country character varying(255),
    rating double precision DEFAULT '0'::double precision,
    "reviewCount" integer DEFAULT 0,
    "salesCount" integer DEFAULT 0 NOT NULL,
    "purchasesCount" integer DEFAULT 0 NOT NULL,
    is_admin boolean DEFAULT false,
    is_suspended boolean DEFAULT false,
    "passwordResetToken" character varying(255),
    "passwordResetExpires" timestamp with time zone,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Users" OWNER TO alessandrogueli;

--
-- Name: Users_id_seq; Type: SEQUENCE; Schema: public; Owner: alessandrogueli
--

CREATE SEQUENCE public."Users_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Users_id_seq" OWNER TO alessandrogueli;

--
-- Name: Users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alessandrogueli
--

ALTER SEQUENCE public."Users_id_seq" OWNED BY public."Users".id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: alessandrogueli
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    "listingId" integer NOT NULL,
    "buyerId" integer NOT NULL,
    "sellerId" integer NOT NULL,
    amount integer NOT NULL,
    "shippingCost" integer DEFAULT 0 NOT NULL,
    "shippingAddress" json,
    status character varying(255) DEFAULT 'paid'::character varying NOT NULL,
    "trackingCode" character varying(255),
    courier character varying(255),
    "transactionId" character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.orders OWNER TO alessandrogueli;

--
-- Name: COLUMN orders.courier; Type: COMMENT; Schema: public; Owner: alessandrogueli
--

COMMENT ON COLUMN public.orders.courier IS 'Es. DHL, Bartolini, Poste Italiane';


--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: alessandrogueli
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.orders_id_seq OWNER TO alessandrogueli;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: alessandrogueli
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: Conversations id; Type: DEFAULT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Conversations" ALTER COLUMN id SET DEFAULT nextval('public."Conversations_id_seq"'::regclass);


--
-- Name: Listings id; Type: DEFAULT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Listings" ALTER COLUMN id SET DEFAULT nextval('public."Listings_id_seq"'::regclass);


--
-- Name: Messages id; Type: DEFAULT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Messages" ALTER COLUMN id SET DEFAULT nextval('public."Messages_id_seq"'::regclass);


--
-- Name: Notifications id; Type: DEFAULT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Notifications" ALTER COLUMN id SET DEFAULT nextval('public."Notifications_id_seq"'::regclass);


--
-- Name: Reviews id; Type: DEFAULT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Reviews" ALTER COLUMN id SET DEFAULT nextval('public."Reviews_id_seq"'::regclass);


--
-- Name: Users id; Type: DEFAULT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Users" ALTER COLUMN id SET DEFAULT nextval('public."Users_id_seq"'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Data for Name: ConversationParticipants; Type: TABLE DATA; Schema: public; Owner: alessandrogueli
--

COPY public."ConversationParticipants" ("UserId", "ConversationId") FROM stdin;
\.


--
-- Data for Name: Conversations; Type: TABLE DATA; Schema: public; Owner: alessandrogueli
--

COPY public."Conversations" (id, "listingId", status, "lastMessageAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Favorites; Type: TABLE DATA; Schema: public; Owner: alessandrogueli
--

COPY public."Favorites" ("createdAt", "UserId", "ListingId") FROM stdin;
\.


--
-- Data for Name: Listings; Type: TABLE DATA; Schema: public; Owner: alessandrogueli
--

COPY public."Listings" (id, title, description, price, currency, category, brand, size, condition, photos, status, views, "shippingCost", attributes, "sellerId", "createdAt", "updatedAt") FROM stdin;
1	Giacca di Jeans di Prova	Questa è una giacca di prova per testare il seeding del database.	5000	EUR	Abbigliamento	SeedBrand	L	Come nuovo	["https://loremflickr.com/600/600/fashion,denim,jacket?lock=100"]	active	0	500	{}	1	2026-07-16 13:55:55.747+02	2026-07-16 13:55:55.747+02
2	Pantaloni Sportivi Neri (Ottimo)	Descrizione generata automaticamente per Pantaloni Sportivi Neri. Ottima occasione, in condizione ottimo.	6755	EUR	Abbigliamento	Adidas	XL	Ottimo	["https://loremflickr.com/600/600/fashion,clothing,black,sport,pants?lock=0"]	active	0	500	{}	1	2026-07-16 13:55:55.769+02	2026-07-16 13:55:55.769+02
3	Giacca di Jeans Vintage (Ottimo)	Descrizione generata automaticamente per Giacca di Jeans Vintage. Ottima occasione, in condizione ottimo.	9865	EUR	Abbigliamento	Lee	L	Ottimo	["https://loremflickr.com/600/600/fashion,clothing,vintage,denim,jacket?lock=10"]	active	0	500	{}	1	2026-07-16 13:55:55.781+02	2026-07-16 13:55:55.781+02
4	T-shirt Bianca in Cotone (Ottimo)	Descrizione generata automaticamente per T-shirt Bianca in Cotone. Ottima occasione, in condizione ottimo.	17349	EUR	Abbigliamento	Uniqlo	M	Ottimo	["https://loremflickr.com/600/600/fashion,clothing,white,t-shirt?lock=20","https://loremflickr.com/600/600/fashion,clothing,white,t-shirt?lock=21"]	active	1	500	{}	1	2026-07-16 13:55:55.79+02	2026-07-16 14:01:32.2+02
5	Maglione in Lana a Collo Alto (Buono)	Descrizione generata automaticamente per Maglione in Lana a Collo Alto. Ottima occasione, in condizione buono.	5201	EUR	Abbigliamento	Benetton	L	Buono	["https://loremflickr.com/600/600/fashion,clothing,wool,turtleneck,sweater?lock=30"]	active	2	500	{}	1	2026-07-16 13:55:55.923+02	2026-07-16 14:01:52.285+02
6	scarpe air force	air force bianche	5000	EUR	Scarpe	Nike	44	Ottimo	["/uploads/listings/listing-new-1784203525563-541796516.webp"]	sold	6	0	{}	1	2026-07-16 14:05:26.002+02	2026-07-16 14:22:33.689+02
\.


--
-- Data for Name: Messages; Type: TABLE DATA; Schema: public; Owner: alessandrogueli
--

COPY public."Messages" (id, content, type, "isRead", "readAt", "conversationId", "senderId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Notifications; Type: TABLE DATA; Schema: public; Owner: alessandrogueli
--

COPY public."Notifications" (id, type, content, "isRead", "readAt", "recipientId", "senderId", "listingId", "createdAt", "updatedAt") FROM stdin;
1	item_sold	{"message":"Il tuo articolo \\"scarpe air force\\" è stato venduto!"}	f	\N	1	3	6	2026-07-16 14:06:45.379+02	2026-07-16 14:06:45.379+02
2	order_delivered	{"message":"L'articolo \\"scarpe air force\\" è stato consegnato all'acquirente. Il pagamento sarà presto elaborato."}	f	\N	1	3	6	2026-07-16 14:07:03.242+02	2026-07-16 14:07:03.242+02
\.


--
-- Data for Name: Reviews; Type: TABLE DATA; Schema: public; Owner: alessandrogueli
--

COPY public."Reviews" (id, rating, comment, "authorId", "targetId", "createdAt", "updatedAt") FROM stdin;
1	5	Venditore eccellente! Spedizione veloce e oggetto come da descrizione.	2	1	2026-07-16 13:55:55.992+02	2026-07-16 13:55:55.992+02
2	5	perfetto	3	1	2026-07-16 14:07:16.098+02	2026-07-16 14:07:16.098+02
\.


--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: alessandrogueli
--

COPY public."Users" (id, name, email, password, avatar, bio, location, "addressLine1", city, "postalCode", country, rating, "reviewCount", "salesCount", "purchasesCount", is_admin, is_suspended, "passwordResetToken", "passwordResetExpires", "createdAt", "updatedAt") FROM stdin;
2	Mario Rossi	buyer@example.com	$2a$10$6r/8T32sVy6ahjE1aUyW5OxDO63KPSFk5xaqia5UPI/UEzIufnsgq	\N	Amo la moda vintage!	Roma, IT	Via Roma 1	Roma	00100	IT	0	0	0	0	f	f	\N	\N	2026-07-16 13:55:54.681+02	2026-07-16 13:55:54.681+02
3	Mario Rossi	mario.rossi@example.com	$2a$10$SlUALHp4l.gFyBecaUXQ0uJmPvbzfuTAVM4zoSiHrfTKvPbtd9SX6	\N		torino	via tori	torino	12345	italia	0	0	0	1	f	f	\N	\N	2026-07-16 13:57:24.226+02	2026-07-16 14:06:45.352+02
1	Test User 1	testuser1@example.com	$2a$10$ue3gPPpSLL0ZqNLbofqs4.IkEfa2x7h5L6D6PqecrEg2xjzmXoopK	\N	Sono un utente di prova per testare la piattaforma 2buydress.	Milano, IT	\N	\N	\N	\N	5	2	1	0	t	f	\N	\N	2026-07-16 13:55:53.371+02	2026-07-16 14:07:16.117+02
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: alessandrogueli
--

COPY public.orders (id, "listingId", "buyerId", "sellerId", amount, "shippingCost", "shippingAddress", status, "trackingCode", courier, "transactionId", "createdAt", "updatedAt") FROM stdin;
1	6	3	1	5000	0	{"addressLine1":"via tori","city":"torino","postalCode":"12345","country":"italia"}	delivered	TRK-DI0AIC1Y8	Corriere 2BuyDress (Simulato)	SIM-1784203605339-586	2026-07-16 14:06:45.341+02	2026-07-16 14:07:03.231+02
\.


--
-- Name: Conversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alessandrogueli
--

SELECT pg_catalog.setval('public."Conversations_id_seq"', 1, false);


--
-- Name: Listings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alessandrogueli
--

SELECT pg_catalog.setval('public."Listings_id_seq"', 6, true);


--
-- Name: Messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alessandrogueli
--

SELECT pg_catalog.setval('public."Messages_id_seq"', 1, false);


--
-- Name: Notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alessandrogueli
--

SELECT pg_catalog.setval('public."Notifications_id_seq"', 2, true);


--
-- Name: Reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alessandrogueli
--

SELECT pg_catalog.setval('public."Reviews_id_seq"', 2, true);


--
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alessandrogueli
--

SELECT pg_catalog.setval('public."Users_id_seq"', 3, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: alessandrogueli
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, true);


--
-- Name: ConversationParticipants ConversationParticipants_pkey; Type: CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."ConversationParticipants"
    ADD CONSTRAINT "ConversationParticipants_pkey" PRIMARY KEY ("UserId", "ConversationId");


--
-- Name: Conversations Conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Conversations"
    ADD CONSTRAINT "Conversations_pkey" PRIMARY KEY (id);


--
-- Name: Favorites Favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Favorites"
    ADD CONSTRAINT "Favorites_pkey" PRIMARY KEY ("UserId", "ListingId");


--
-- Name: Listings Listings_pkey; Type: CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Listings"
    ADD CONSTRAINT "Listings_pkey" PRIMARY KEY (id);


--
-- Name: Messages Messages_pkey; Type: CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_pkey" PRIMARY KEY (id);


--
-- Name: Notifications Notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Notifications"
    ADD CONSTRAINT "Notifications_pkey" PRIMARY KEY (id);


--
-- Name: Reviews Reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Reviews"
    ADD CONSTRAINT "Reviews_pkey" PRIMARY KEY (id);


--
-- Name: Users Users_email_key; Type: CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key" UNIQUE (email);


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: orders orders_transactionId_key; Type: CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_transactionId_key" UNIQUE ("transactionId");


--
-- Name: listings_category; Type: INDEX; Schema: public; Owner: alessandrogueli
--

CREATE INDEX listings_category ON public."Listings" USING btree (category);


--
-- Name: listings_price; Type: INDEX; Schema: public; Owner: alessandrogueli
--

CREATE INDEX listings_price ON public."Listings" USING btree (price);


--
-- Name: listings_seller_id_status; Type: INDEX; Schema: public; Owner: alessandrogueli
--

CREATE INDEX listings_seller_id_status ON public."Listings" USING btree ("sellerId", status);


--
-- Name: ConversationParticipants ConversationParticipants_ConversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."ConversationParticipants"
    ADD CONSTRAINT "ConversationParticipants_ConversationId_fkey" FOREIGN KEY ("ConversationId") REFERENCES public."Conversations"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ConversationParticipants ConversationParticipants_UserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."ConversationParticipants"
    ADD CONSTRAINT "ConversationParticipants_UserId_fkey" FOREIGN KEY ("UserId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Conversations Conversations_listingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Conversations"
    ADD CONSTRAINT "Conversations_listingId_fkey" FOREIGN KEY ("listingId") REFERENCES public."Listings"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Favorites Favorites_ListingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Favorites"
    ADD CONSTRAINT "Favorites_ListingId_fkey" FOREIGN KEY ("ListingId") REFERENCES public."Listings"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Favorites Favorites_UserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Favorites"
    ADD CONSTRAINT "Favorites_UserId_fkey" FOREIGN KEY ("UserId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Listings Listings_sellerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Listings"
    ADD CONSTRAINT "Listings_sellerId_fkey" FOREIGN KEY ("sellerId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Messages Messages_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."Conversations"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Messages Messages_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Notifications Notifications_listingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Notifications"
    ADD CONSTRAINT "Notifications_listingId_fkey" FOREIGN KEY ("listingId") REFERENCES public."Listings"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Notifications Notifications_recipientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Notifications"
    ADD CONSTRAINT "Notifications_recipientId_fkey" FOREIGN KEY ("recipientId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Notifications Notifications_senderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Notifications"
    ADD CONSTRAINT "Notifications_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Reviews Reviews_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Reviews"
    ADD CONSTRAINT "Reviews_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Reviews Reviews_targetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public."Reviews"
    ADD CONSTRAINT "Reviews_targetId_fkey" FOREIGN KEY ("targetId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_buyerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_buyerId_fkey" FOREIGN KEY ("buyerId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_listingId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_listingId_fkey" FOREIGN KEY ("listingId") REFERENCES public."Listings"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders orders_sellerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: alessandrogueli
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "orders_sellerId_fkey" FOREIGN KEY ("sellerId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

